﻿#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
SetTitleMatchMode(2)
SendMode("Input")
CoordMode("Mouse", "Screen") ; 以下保存/点击的都是屏幕绝对坐标

; Windows AutoHotkey v2 | ChatGPT 桌面端多 PDF 顺序上传与逐题发送
; 不调用 API，不读取 PDF 题目内容。使用桌面窗口坐标定位附件按钮、上传菜单、输入框。
; 暂停/恢复依靠进度.ini；允许新对话首发，也允许按每对话PDF数自动/手动切换。
; 若 ChatGPT 不是独立 exe，而是 Chrome/Edge 安装的桌面应用，可先按 Ctrl+Alt+0 绑定当前 ChatGPT 窗口。
; 仅当附件按钮能调出 Windows 文件选择对话框时上传流程可用。

baseDir := A_ScriptDir
global TaskPath := baseDir "\PDF任务清单.txt"
; V4.4：设置不再存放在脚本所在目录，避免每次下载到不同文件夹被误认为重置。
; 首次启用会自动导入当前脚本文件夹的旧设置（如存在）。任务/进度仍沿用 V3/V4 原文件夹，不做清空。
global PrefDir := A_AppData "\ChatGPT_MultiPDF_AutoSend"
DirCreate(PrefDir)
legacyPrefPath := baseDir "\设置.ini"
global PrefPath := PrefDir "\ChatGPT_设置.ini"
if !FileExist(PrefPath) {
    if FileExist(legacyPrefPath)
        FileCopy(legacyPrefPath, PrefPath)
    else if FileExist(baseDir "\ChatGPT_设置.ini")
        FileCopy(baseDir "\ChatGPT_设置.ini", PrefPath)
}
global StatePath := baseDir "\多PDF进度.ini"
global LogPath := baseDir "\运行日志.txt"
; V4 新增固定话语与每PDF自定义模式，仅在选中模式时启用，原逐题逻辑和旧任务文件保留。
global Mode := "questions"
global SendMsg1 := ""
global OriginalTaskPath := TaskPath
global OriginalStatePath := StatePath
global FixedTaskPath := baseDir "\固定话语任务清单.txt"
global FixedStatePath := baseDir "\固定话语进度.ini"
global CustomTaskPath := baseDir "\自定义话语任务清单.txt"
global CustomStatePath := baseDir "\自定义话语进度.ini"
global ManagerGui := 0
global ManagerList := 0
global EditorOpen := false
global Jobs := []
global Signature := ""
global JobIndex := 1
global QuestionIndex := 1
global Stage := "upload"   ; upload / upload_wait / question / question_wait / pdf_wait / done
global WaitUntil := ""
global Running := false
global Busy := false
global ChatHwnd := 0
global PlusX := IniRead(PrefPath, "coords", "plusX", "")
global PlusY := IniRead(PrefPath, "coords", "plusY", "")
global UploadX := IniRead(PrefPath, "coords", "uploadX", "")
global UploadY := IniRead(PrefPath, "coords", "uploadY", "")
global InputX := IniRead(PrefPath, "coords", "inputX", "")
global InputY := IniRead(PrefPath, "coords", "inputY", "")
; ChatGPT附加PDF后可选单独校准输入框位置；未校准时使用原版普通输入框坐标。
; Ctrl+Alt+4 可为已有消息对话校准带PDF时的输入框。
global AttachedInputX := IniRead(PrefPath, "coords", "attachedInputX", "")
global AttachedInputY := IniRead(PrefPath, "coords", "attachedInputY", "")
global QWait := 30  ; 分钟
global PDFWait := 60 ; 分钟
global UploadWait := 30 ; 秒：PDF消息发送完到首题之间
; V4.4：旧对话坐标不变，新增空白新对话独立坐标；都持久保存在 AppData 的 ChatGPT_设置.ini。
global FreshPlusX := IniRead(PrefPath, "coords", "freshPlusX", "")
global FreshPlusY := IniRead(PrefPath, "coords", "freshPlusY", "")
global FreshUploadX := IniRead(PrefPath, "coords", "freshUploadX", "")
global FreshUploadY := IniRead(PrefPath, "coords", "freshUploadY", "")
global FreshInputX := IniRead(PrefPath, "coords", "freshInputX", "")
global FreshInputY := IniRead(PrefPath, "coords", "freshInputY", "")
global FreshAttachedX := IniRead(PrefPath, "coords", "freshAttachedX", "")
global FreshAttachedY := IniRead(PrefPath, "coords", "freshAttachedY", "")
global NewChatX := IniRead(PrefPath, "coords", "newChatX", "")
global NewChatY := IniRead(PrefPath, "coords", "newChatY", "")
global InFreshComposer := false
; 当前模式进度分别保存这些字段，不会改动V3的原有任务清单字段。
global ChatGroupStartJob := 1
; 需要手动新建对话时，不会发送下一份PDF，直到用户确认后按F8。
global NeedManualNewChat := false


if !FileExist(TaskPath)
    FileAppend("# 每行格式：PDF完整路径|题号，例如：D:\资料\第一讲.pdf|8-10,12,16-18`r`n# 可点脚本窗口里的【添加 PDF 任务】，无须手工写路径。`r`n", TaskPath, "UTF-8")

; V4.3：主窗口缩小为紧凑可调整大小的界面；高级设置独立弹窗。
; 不改动上传、发送、任务、等待、校准和进度的实际处理函数。
global MainGui := Gui("+AlwaysOnTop +Resize +MinSize590x395", "ChatGPT 多PDF自动发送 · V4.4 设置永久保存版")
MainGui.SetFont("s9", "Microsoft YaHei")
MainGui.MarginX := 12
MainGui.MarginY := 10
global CountText := MainGui.AddText("xm w650 h26", "正在载入任务……")
MainGui.AddText("xm y+8", "每条话语间隔(分)：")
global QBox := MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(PrefPath, "timing", "question_minutes", "30"))
MainGui.AddText("x+14 yp+3", "每份PDF间隔(分)：")
global PBox := MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(PrefPath, "timing", "pdf_minutes", "60"))
MainGui.AddText("x+14 yp+3", "上传后等待(秒)：")
global UBox := MainGui.AddEdit("x+5 yp-3 w60 Number", IniRead(PrefPath, "timing", "upload_seconds", "30"))
QBox.OnEvent("Change", SaveTimersOnEdit)
PBox.OnEvent("Change", SaveTimersOnEdit)
UBox.OnEvent("Change", SaveTimersOnEdit)
MainGui.AddText("xm y+12", "首次使用的 ChatGPT 对话：")
global StartProfileBox := MainGui.AddDropDownList("x+7 yp-4 w215", ["已有消息的旧对话", "空白新对话（首发PDF）"])
StartProfileBox.Choose(Number(IniRead(PrefPath, "chat", "start_profile", "1")))
StartProfileBox.OnEvent("Change", SaveStartProfile)
global AdvBtn := MainGui.AddButton("x+17 yp-1 w137 h27", "高级设置 / 定位")
AdvBtn.OnEvent("Click", ShowAdvancedSettings)
global SavePrefsBtn := MainGui.AddButton("x+8 yp w105 h27", "保存全部设置")
SavePrefsBtn.OnEvent("Click", (*) => SaveAllSettings(true))
MainGui.AddText("xm y+12", "发送模式：")
global ModeBox := MainGui.AddDropDownList("x+6 yp-4 w565", ["原版：PDF逐题提问", "功能一：所有PDF共用一条固定话语", "功能二：每份PDF自定义1~多条话语"])
ModeBox.Choose(Number(IniRead(PrefPath, "messages", "mode_index", "1")))
ModeBox.OnEvent("Change", SwitchMode)
global Msg1Label := MainGui.AddText("xm y+9 w650", "功能一专用：所有PDF共用的固定话语（可修改）：")
global Msg1Box := MainGui.AddEdit("xm y+4 w650", IniRead(PrefPath, "messages", "first", "请帮我整理申论，生成word"))
Msg1Box.OnEvent("Change", SaveMessageSettings)
addBtn := MainGui.AddButton("xm y+11 w142 h29", "添加 PDF 任务")
addBtn.OnEvent("Click", AddPdfJob)
editBtn := MainGui.AddButton("x+7 yp w142 h29", "编辑任务清单")
editBtn.OnEvent("Click", EditJobs)
reloadBtn := MainGui.AddButton("x+7 yp w142 h29", "重新载入任务")
reloadBtn.OnEvent("Click", ClearTaskList)
resetBtn := MainGui.AddButton("x+7 yp w142 h29", "重置发送进度")
resetBtn.OnEvent("Click", ResetProgress)
noPdfBtn := MainGui.AddButton("xm y+7 w250 h29", "只发话语（不重新上传PDF）")
noPdfBtn.OnEvent("Click", AddTextOnlyJob)
global NoPdfBtn := noPdfBtn
global CustomManageBtn := MainGui.AddButton("x+8 yp w250 h29", "管理每份PDF的话语")
CustomManageBtn.OnEvent("Click", OpenCustomManager)
MainGui.AddText("xm y+10 w650", "F8 开始/继续　F9 暂停　F10 跳过等待　F12 退出")
global StatusText := MainGui.AddText("xm y+8 w650 h83", "添加PDF任务，校准 ChatGPT 窗口后按 F8。")
MainGui.OnEvent("Size", CompactWindowResized)
MainGui.OnEvent("Close", SafeExit)

; 以下设置被移入弹出的高级窗口，仍沿用原变量和原保存逻辑。
global AdvancedGui := Gui("+AlwaysOnTop", "ChatGPT · 高级设置与坐标定位")
AdvancedGui.SetFont("s9", "Microsoft YaHei")
AdvancedGui.MarginX := 14
AdvancedGui.MarginY := 13
AdvancedGui.AddText("xm w640", "快捷键校准：把鼠标放到 ChatGPT 目标位置后按组合键，位置自动保存。")
AdvancedGui.AddText("xm y+9 w670", "Ctrl+Alt+0 绑定窗口； 1 附件＋； 2 上传菜单； 3 普通输入框； 4 附件后输入框")
AdvancedGui.AddText("xm y+6 w670", "新对话专用：Ctrl+Alt+5 附件＋； 6 上传菜单； 7 普通输入框； 8 附件后输入框")
AdvancedGui.AddText("xm y+6 w670", "Ctrl+Alt+9：新建聊天按钮（若需自动切换对话，必须先校准）")
global CalText := AdvancedGui.AddText("xm y+12 w665 h56", "正在读取定位状态……")
AdvancedGui.AddText("xm y+12", "每个对话最多处理PDF数量（0 = 不换）：")
global MaxPDFBox := AdvancedGui.AddEdit("x+8 yp-3 w64 Number", IniRead(PrefPath, "chat", "max_pdfs", "0"))
MaxPDFBox.OnEvent("Change", SaveConversationOptions)
global AutoSwitchBox := AdvancedGui.AddCheckBox("xm y+13", "到上限自动点击【新建聊天】（需要 Ctrl+Alt+9 已校准）")
AutoSwitchBox.Value := Number(IniRead(PrefPath, "chat", "auto_switch", "0"))
AutoSwitchBox.OnEvent("Click", SaveConversationOptions)
AdvancedGui.AddText("xm y+12 w670", "不勾选时到上限将安全暂停，手动打开新聊天并按 Ctrl+Alt+0、F8 继续。")
AdvancedGui.AddText("xm y+9 w670", "V4.4：设置保存在 Windows AppData，移动或升级脚本也不会重置。")
AdvancedGui.AddText("xm y+5 w670", "设置文件：" PrefPath)
AdvancedGui.AddButton("xm y+12 w125 h28", "保存全部设置").OnEvent("Click", (*) => SaveAllSettings(true))
AdvancedGui.AddButton("x+8 yp w125 h28", "导入旧设置").OnEvent("Click", ImportLegacySettings)
AdvancedGui.AddButton("x+8 yp w125 h28", "打开设置文件夹").OnEvent("Click", OpenPrefsFolder)
AdvancedGui.AddButton("x+8 yp w125 h28", "关闭高级设置").OnEvent("Click", HideAdvancedSettings)
AdvancedGui.OnEvent("Close", HideAdvancedSettings)
MainGui.Show("w700 h430")

F8::StartRun()
F9::PauseRun()
F10::FastForward()
F12::SafeExit()
^!0::BindChatGPTWindow()
^!1::Calibrate("plus")
^!2::Calibrate("upload")
^!3::Calibrate("input")
^!4::Calibrate("attached_input")
^!5::CalibrateFresh("plus")
^!6::CalibrateFresh("upload")
^!7::CalibrateFresh("input")
^!8::CalibrateFresh("attached_input")
^!9::CalibrateFresh("new_chat")
SetTimer(Tick, 1000)
InitSelectedMode()
try ReloadJobs()
catch as e
    SetStatus("载入任务失败：" e.Message)
UpdateCalibration()
OnExit(OnScriptExit)


; 紧凑窗口支持拖动四角改变大小，正文和状态栏自动随宽度扩展。
CompactWindowResized(guiObj, minMax, width, height) {
    global CountText, ModeBox, Msg1Label, Msg1Box, StatusText
    if minMax = -1
        return
    contentWidth := Max(555, width - 27)
    try {
        CountText.Move(, , contentWidth)
        ModeBox.Move(, , Max(430, contentWidth - 89))
        Msg1Label.Move(, , contentWidth)
        Msg1Box.Move(, , contentWidth)
        StatusText.GetPos(&sx, &sy, &sw, &sh)
        StatusText.Move(, , contentWidth, Max(58, height - sy - 16))
    }
}

ShowAdvancedSettings(*) {
    global AdvancedGui
    AdvancedGui.Show("w730 h370")
}

HideAdvancedSettings(*) {
    global AdvancedGui
    try SaveConversationOptions()
    AdvancedGui.Hide()
}

; ===== V4：三个独立模式。原版模式仍使用 V3 原始的文件和完整调度。 =====
SaveTimersOnEdit(*) {
    ; 修改后立即保存，F12和右上角关闭也会再保存一次，避免退出重置。
    global QBox, PBox, UBox, PrefPath
    for t in [["question_minutes", QBox.Value, 1, 120], ["pdf_minutes", PBox.Value, 1, 120], ["upload_seconds", UBox.Value, 15, 3600]] {
        v := Trim(t[2])
        if RegExMatch(v, "^\d+$") && Number(v) >= t[3] && Number(v) <= t[4]
            IniWrite(String(Number(v)), PrefPath, "timing", t[1])
    }
}

SaveConversationOptions(*) {
    global PrefPath, MaxPDFBox, AutoSwitchBox
    n := Trim(MaxPDFBox.Value)
    if RegExMatch(n, "^\d+$") && Number(n) <= 1000
        IniWrite(String(Number(n)), PrefPath, "chat", "max_pdfs")
    IniWrite(String(AutoSwitchBox.Value), PrefPath, "chat", "auto_switch")
}

SaveStartProfile(*) {
    global StartProfileBox, PrefPath, JobIndex, Stage, InFreshComposer, Running
    IniWrite(String(StartProfileBox.Value), PrefPath, "chat", "start_profile")
    ; 仅尚未开始的第一份任务可切换开场界面，防止中途误覆盖现场状态。
    if !Running && JobIndex = 1 && Stage = "upload" {
        InFreshComposer := StartProfileBox.Value = 2
        SaveProgress()
    }
}

; 下面的统一保存也会在按 F12 和点窗口 X 时执行；不会清空任务或进度。
SafeExit(*) {
    SaveAllSettings(false)
    ExitApp()
}

; OnExit回调必须返回0，否则返回true会阻止程序退出。
OnScriptExit(*) {
    SaveAllSettings(false)
    return 0
}

; 手动保存：先检查三个间隔及PDF上限，再写入同一个 AppData 配置文件并读回确认。
SaveAllSettings(showNotice := true) {
    global PrefPath, QBox, PBox, UBox, MaxPDFBox, AutoSwitchBox, StartProfileBox, ModeBox, Msg1Box
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY, FreshInputX, FreshInputY
    global FreshAttachedX, FreshAttachedY, NewChatX, NewChatY
    try {
        ValidateTimers()
        n := Trim(MaxPDFBox.Value)
        if !RegExMatch(n, "^\d+$") || Number(n) > 1000
            throw Error("每个对话的PDF数量必须是0～1000之间的整数")
        SaveConversationOptions()
        SaveMessageSettings()
        IniWrite(String(StartProfileBox.Value), PrefPath, "chat", "start_profile")
        IniWrite(String(ModeBox.Value), PrefPath, "messages", "mode_index")
        values := Map(
            "plusX", PlusX, "plusY", PlusY, "uploadX", UploadX, "uploadY", UploadY,
            "inputX", InputX, "inputY", InputY,
            "attachedInputX", AttachedInputX, "attachedInputY", AttachedInputY,
            "freshPlusX", FreshPlusX, "freshPlusY", FreshPlusY,
            "freshUploadX", FreshUploadX, "freshUploadY", FreshUploadY,
            "freshInputX", FreshInputX, "freshInputY", FreshInputY,
            "freshAttachedX", FreshAttachedX, "freshAttachedY", FreshAttachedY,
            "newChatX", NewChatX, "newChatY", NewChatY)
        for key, value in values {
            if value != ""
                IniWrite(String(value), PrefPath, "coords", key)
        }
        if IniRead(PrefPath, "timing", "question_minutes", "") != String(Number(Trim(QBox.Value)))
            throw Error("每条话语间隔未能读回，请检查写入权限")
        if IniRead(PrefPath, "timing", "pdf_minutes", "") != String(Number(Trim(PBox.Value)))
            throw Error("每份PDF间隔未能读回，请检查写入权限")
        if IniRead(PrefPath, "timing", "upload_seconds", "") != String(Number(Trim(UBox.Value)))
            throw Error("上传后等待时间未能读回，请检查写入权限")
        if IniRead(PrefPath, "chat", "max_pdfs", "") != String(Number(n))
            throw Error("每个对话PDF数量未能读回，请检查写入权限")
        for key, value in values {
            if value != "" && IniRead(PrefPath, "coords", key, "") != String(value)
                throw Error("定位设置 " key " 未能读回，请检查写入权限")
        }
        if showNotice
            MsgBox("已保存并核对成功！`n`n间隔：" QBox.Value " 分钟 / " PBox.Value " 分钟 / " UBox.Value " 秒"
                . "`n每对话上限：" n " 份PDF`n`n坐标：所有已校准的位置`n`n设置文件：`n" PrefPath,
                "设置保存成功", "Iconi")
        return true
    } catch as e {
        if showNotice
            MsgBox("保存未完成：" e.Message "`n请不要退出，先检查填写和目录权限。`n" PrefPath, "保存失败", "Iconx")
        return false
    }
}

; 旧版本的ini往往存放于各个下载文件夹。可选择其中一份导入，当前配置先备份。
ImportLegacySettings(*) {
    global PrefPath, Running, Busy, QBox, PBox, UBox, MaxPDFBox, AutoSwitchBox
    global StartProfileBox, Msg1Box, ModeBox, PrefDir
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY, FreshInputX, FreshInputY
    global FreshAttachedX, FreshAttachedY, NewChatX, NewChatY
    if Running || Busy {
        MsgBox("请先按 F9 暂停任务，再导入旧设置。")
        return
    }
    selected := FileSelect(1, A_ScriptDir, "选择旧版 ChatGPT_设置.ini", "INI 设置文件 (*.ini)")
    if selected = ""
        return
    if StrLower(selected) = StrLower(PrefPath) {
        MsgBox("你选的就是当前设置文件，不需要重复导入。")
        return
    }
    if MsgBox("将读取所选旧设置，替换当前的间隔、定位坐标和模式设置。`n当前设置会先自动备份；PDF任务和发送进度不删除。`n`n继续？", "确认导入", "YesNo Icon?") != "Yes"
        return
    try {
        if FileExist(PrefPath)
            FileCopy(PrefPath, PrefDir "\ChatGPT_设置_导入前备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") ".ini")
        FileCopy(selected, PrefPath, true)
        QBox.Value := IniRead(PrefPath, "timing", "question_minutes", "30")
        PBox.Value := IniRead(PrefPath, "timing", "pdf_minutes", "60")
        UBox.Value := IniRead(PrefPath, "timing", "upload_seconds", "30")
        MaxPDFBox.Value := IniRead(PrefPath, "chat", "max_pdfs", "0")
        AutoSwitchBox.Value := Number(IniRead(PrefPath, "chat", "auto_switch", "0"))
        StartProfileBox.Choose(Number(IniRead(PrefPath, "chat", "start_profile", "1")))
        Msg1Box.Value := IniRead(PrefPath, "messages", "first", "请帮我整理申论，生成word")
        ModeBox.Choose(Number(IniRead(PrefPath, "messages", "mode_index", "1")))
        ; 发送模式的实际任务列表保持不动；重新打开脚本时才切到导入的模式。
        PlusX := IniRead(PrefPath, "coords", "plusX", "")
        PlusY := IniRead(PrefPath, "coords", "plusY", "")
        UploadX := IniRead(PrefPath, "coords", "uploadX", "")
        UploadY := IniRead(PrefPath, "coords", "uploadY", "")
        InputX := IniRead(PrefPath, "coords", "inputX", "")
        InputY := IniRead(PrefPath, "coords", "inputY", "")
        AttachedInputX := IniRead(PrefPath, "coords", "attachedInputX", "")
        AttachedInputY := IniRead(PrefPath, "coords", "attachedInputY", "")
        FreshPlusX := IniRead(PrefPath, "coords", "freshPlusX", "")
        FreshPlusY := IniRead(PrefPath, "coords", "freshPlusY", "")
        FreshUploadX := IniRead(PrefPath, "coords", "freshUploadX", "")
        FreshUploadY := IniRead(PrefPath, "coords", "freshUploadY", "")
        FreshInputX := IniRead(PrefPath, "coords", "freshInputX", "")
        FreshInputY := IniRead(PrefPath, "coords", "freshInputY", "")
        FreshAttachedX := IniRead(PrefPath, "coords", "freshAttachedX", "")
        FreshAttachedY := IniRead(PrefPath, "coords", "freshAttachedY", "")
        NewChatX := IniRead(PrefPath, "coords", "newChatX", "")
        NewChatY := IniRead(PrefPath, "coords", "newChatY", "")
        UpdateCalibration()
        ; 导入的发送模式下次重启会恢复，这里不强制切换正在编辑的任务模式。
        if SaveAllSettings(false)
            MsgBox("导入成功！已加载旧设置并保存到固定位置。`n`n旧设置内的发送模式将在下次启动时恢复。`n" PrefPath, "导入完成", "Iconi")
        else
            MsgBox("已读入旧INI，但有字段无效。请检查三个间隔及PDF上限，并点击【保存全部设置】。", "需要检查")
    } catch as e {
        MsgBox("导入失败：" e.Message, "错误", "Iconx")
    }
}

OpenPrefsFolder(*) {
    global PrefDir
    Run(PrefDir)
}

CalibrateFresh(which) {
    global PrefPath, FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY
    global FreshInputX, FreshInputY, FreshAttachedX, FreshAttachedY, NewChatX, NewChatY
    h := GetChat()
    if !h {
        MsgBox("请先切换到ChatGPT窗口并按 Ctrl+Alt+0 绑定后再校准。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx-wx, ry := my-wy
    if which = "plus" {
        FreshPlusX := rx, FreshPlusY := ry
        key := "freshPlus", label := "新对话附件＋"
    } else if which = "upload" {
        FreshUploadX := rx, FreshUploadY := ry
        key := "freshUpload", label := "新对话上传菜单"
    } else if which = "input" {
        FreshInputX := rx, FreshInputY := ry
        key := "freshInput", label := "新对话普通输入框"
    } else if which = "attached_input" {
        FreshAttachedX := rx, FreshAttachedY := ry
        key := "freshAttached", label := "新对话带PDF的输入框"
    } else {
        NewChatX := rx, NewChatY := ry
        key := "newChat", label := "新建聊天按钮"
    }
    IniWrite(String(rx), PrefPath, "coords", key "X")
    IniWrite(String(ry), PrefPath, "coords", key "Y")
    UpdateCalibration()
    ToolTip("已保存：" label "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -2200)
}

; 切到新对话后，只有第一条带附件的PDF消息使用居中的新对话坐标。
; 第一条实际发出以后立即恢复原来已经校准好的旧对话坐标。

ModeIndex() {
    global Mode
    return Mode = "single" ? 2 : (Mode = "custom" ? 3 : 1)
}

TaskTemplate() {
    global Mode
    if Mode = "questions"
        return "# 每行：PDF完整路径|题号，如 D:\第一讲.pdf|8-10,12`r`n"
    if Mode = "single"
        return "# 每行一个PDF完整路径；或 @NO_PDF 代表在当前对话直接发一次固定话语。`r`n"
    return "# V4自定义任务文件：建议用窗口【管理每份PDF的话语】编辑，保存时会自动转义特殊字符。`r`n# 每行一份PDF路径与一条或多条话语，字段由 | 分隔。`r`n"
}

InitSelectedMode() {
    global ModeBox
    SelectMode(ModeBox.Value, false)
}

SelectMode(idx, reload := true) {
    global Mode, TaskPath, StatePath, OriginalTaskPath, OriginalStatePath, CustomTaskPath, CustomStatePath
    global FixedTaskPath, FixedStatePath, PrefPath, NoPdfBtn, CustomManageBtn, Msg1Label, Msg1Box
    idx := idx = 2 ? 2 : (idx = 3 ? 3 : 1)
    Mode := idx = 1 ? "questions" : (idx = 2 ? "single" : "custom")
    TaskPath := idx = 1 ? OriginalTaskPath : (idx = 2 ? FixedTaskPath : CustomTaskPath)
    StatePath := idx = 1 ? OriginalStatePath : (idx = 2 ? FixedStatePath : CustomStatePath)
    if !FileExist(TaskPath)
        FileAppend(TaskTemplate(), TaskPath, "UTF-8")
    NoPdfBtn.Enabled := idx != 1
    CustomManageBtn.Enabled := idx = 3
    Msg1Box.Enabled := idx = 2
    Msg1Label.Text := idx = 3 ? "功能二：请点【管理每份PDF的话语】，每份单独编辑（每行发送一次）" : "功能一专用：所有PDF共用一条固定话语（可修改）："
    IniWrite(String(idx), PrefPath, "messages", "mode_index")
    if reload
        ReloadJobs()
}

SwitchMode(*) {
    global Running, Busy, ModeBox, EditorOpen, ManagerGui
    if Running || Busy || EditorOpen || IsObject(ManagerGui) {
        MsgBox("请先暂停并关闭自定义任务管理/编辑窗口，再切换模式。", "暂时不能切换")
        ModeBox.Choose(ModeIndex())
        return
    }
    try SelectMode(ModeBox.Value)
    catch as e {
        MsgBox("切换模式失败：" e.Message, "错误")
        ModeBox.Choose(ModeIndex())
    }
}

SaveMessageSettings(*) {
    global Msg1Box, PrefPath
    IniWrite(Trim(Msg1Box.Value), PrefPath, "messages", "first")
}

AddTextOnlyJob(*) {
    global TaskPath, Running, Busy, Mode, Jobs, EditorOpen, Msg1Box
    if Mode = "questions" {
        MsgBox("原版逐题模式不支持纯文字任务，请选择固定或自定义话语模式。")
        return
    }
    if Running || Busy || EditorOpen {
        MsgBox("请先暂停并关闭话语编辑窗口，再添加任务。")
        return
    }
    if Mode = "custom" {
        Jobs.Push({path: "", name: "当前对话（不上传PDF）", qs: [1], msgs: [DefaultCustomMessage()]})
        try {
            SaveCustomJobs()
            OpenCustomManager()
        } catch as e
            MsgBox("添加失败：" e.Message)
    } else {
        FileAppend("@NO_PDF`r`n", TaskPath, "UTF-8")
        ReloadJobs()
    }
}

DefaultCustomMessage() {
    global PrefPath
    return IniRead(PrefPath, "custom", "default_message", "请帮我整理申论，生成Word")
}

; 任务清单编码，允许文字里包含竖线、百分号、逗号及换行；不会误分割话语。
EscapeCustomField(s) {
    s := StrReplace(s, "%", "%25")
    s := StrReplace(s, "|", "%7C")
    s := StrReplace(s, "`r", "%0D")
    return StrReplace(s, "`n", "%0A")
}
UnescapeCustomField(s) {
    s := StrReplace(s, "%0A", "`n")
    s := StrReplace(s, "%0D", "`r")
    s := StrReplace(s, "%7C", "|")
    return StrReplace(s, "%25", "%")
}

; 修改功能二任务后只重置功能二的进度，不触碰原版和功能一的进度。
SaveCustomJobs() {
    global Mode, Jobs, TaskPath, Running, Busy
    if Mode != "custom" || Running || Busy
        throw Error("只能在已暂停的自定义话语模式下修改")
    content := TaskTemplate()
    for job in Jobs {
        if job.msgs.Length < 1
            throw Error("PDF：" job.name " 至少要设置一条话语")
        line := EscapeCustomField(job.path = "" ? "@NO_PDF" : job.path)
        for m in job.msgs {
            if Trim(m) = ""
                throw Error("PDF：" job.name " 有空白话语")
            line .= "|" EscapeCustomField(m)
        }
        content .= line "`r`n"
    }
    temp := TaskPath ".new"
    if FileExist(temp)
        FileDelete(temp)
    FileAppend(content, temp, "UTF-8")
    FileMove(temp, TaskPath, 1)
    ResetState(ManifestId(content))
    ReloadJobs()
    RefreshCustomManager()
}

; 功能二不需要编辑代码，在管理窗口中选PDF、编辑/新增/删除话语即可。
OpenCustomManager(*) {
    global Mode, ManagerGui, ManagerList, MainGui, Running, Busy
    if Mode != "custom" {
        MsgBox("请先切换到【功能二：每份PDF自定义话语】。")
        return
    }
    if IsObject(ManagerGui) {
        try WinActivate("ahk_id " ManagerGui.Hwnd)
        return
    }
    mgr := Gui("+AlwaysOnTop", "功能二 · 每份PDF分别设置发送次数及话语")
    mgr.SetFont("s10", "Microsoft YaHei")
    mgr.AddText("xm w855", "每份PDF可设置1句、2句、3句或更多；一行话语=一次发送。当前顺序就是自动发送顺序。")
    ManagerList := mgr.AddListView("xm y+8 w855 r12 Grid -Multi", ["序号", "PDF", "话语数", "首句话预览"])
    ManagerList.ModifyCol(1, 48)
    ManagerList.ModifyCol(2, 295)
    ManagerList.ModifyCol(3, 75)
    ManagerList.ModifyCol(4, 425)
    ManagerList.OnEvent("DoubleClick", EditCustomJob)
    add := mgr.AddButton("xm y+12 w118", "添加PDF")
    add.OnEvent("Click", AddPdfJob)
    edit := mgr.AddButton("x+6 yp w128", "编辑这份话语")
    edit.OnEvent("Click", EditCustomJob)
    del := mgr.AddButton("x+6 yp w105", "删除这份PDF")
    del.OnEvent("Click", DeleteCustomJob)
    up := mgr.AddButton("x+6 yp w100", "向上移动")
    up.OnEvent("Click", (*) => MoveCustomJob(-1))
    down := mgr.AddButton("x+6 yp w100", "向下移动")
    down.OnEvent("Click", (*) => MoveCustomJob(1))
    mgr.AddText("xm y+12 w855", "提示：编辑时每一行是一条完整的话语。保存后自动存盘，下次打开仍在；修改任务会重置功能二发送进度。")
    mgr.OnEvent("Close", CloseCustomManager)
    ManagerGui := mgr
    RefreshCustomManager()
    mgr.Show("w880 h430")
}

CloseCustomManager(*) {
    global ManagerGui, ManagerList, EditorOpen
    if EditorOpen {
        MsgBox("请先保存或取消正在编辑的话语。")
        return
    }
    if IsObject(ManagerGui)
        ManagerGui.Destroy()
    ManagerGui := 0
    ManagerList := 0
}

RefreshCustomManager() {
    global Mode, Jobs, ManagerGui, ManagerList
    if Mode != "custom" || !IsObject(ManagerGui)
        return
    ManagerList.Delete()
    for i, job in Jobs {
        preview := job.msgs.Length ? StrReplace(job.msgs[1], "`n", " ") : ""
        ManagerList.Add("", i, job.name, job.msgs.Length, SubStr(preview, 1, 75))
    }
}

SelectedCustomRow() {
    global ManagerGui, ManagerList, Jobs
    if !IsObject(ManagerGui)
        return 0
    row := ManagerList.GetNext()
    if row < 1 || row > Jobs.Length {
        MsgBox("请先在列表里选中一份PDF。")
        return 0
    }
    return row
}

JoinCustomMessages(msgs) {
    result := ""
    for m in msgs
        result .= (A_Index = 1 ? "" : "`r`n") m
    return result
}

EditCustomJob(*) {
    global Mode, Jobs, EditorOpen, ManagerGui
    if Mode != "custom" || EditorOpen
        return
    row := SelectedCustomRow()
    if !row
        return
    EditorOpen := true
    ed := Gui("+AlwaysOnTop", "编辑第" row "份PDF的话语：" Jobs[row].name)
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w795", "一行 = 发送一次。只写一行就只发一次；增加到两行就发两次。按从上到下的顺序发送。")
    field := ed.AddEdit("xm y+8 w795 r12 VScroll", JoinCustomMessages(Jobs[row].msgs))
    more := ed.AddButton("xm y+12 w140", "再添加一句")
    more.OnEvent("Click", (*) => AppendBlankMessage(field))
    save := ed.AddButton("x+9 yp w135 Default", "保存这份话语")
    save.OnEvent("Click", (*) => SaveCustomEditor(row, field.Value, ed))
    cancel := ed.AddButton("x+9 yp w110", "取消")
    cancel.OnEvent("Click", (*) => CloseCustomEditor(ed))
    ed.OnEvent("Close", (*) => CloseCustomEditor(ed))
    ed.Show("w825 h390")
}

AppendBlankMessage(field) {
    field.Value .= "`r`n"
    field.Focus()
    Send("^{End}")
}

CloseCustomEditor(editor) {
    global EditorOpen
    EditorOpen := false
    try editor.Destroy()
}

SaveCustomEditor(row, value, editor) {
    global Jobs, Running, Busy
    if Running || Busy {
        MsgBox("正在发送，不能修改。请先F9暂停。")
        return
    }
    msgs := []
    for line in StrSplit(StrReplace(value, "`r", ""), "`n") {
        line := Trim(line, " `t`r`n")
        if line != ""
            msgs.Push(line)
    }
    if msgs.Length < 1 {
        MsgBox("至少保留一句话；不需要的整份PDF请在列表中删除。")
        return
    }
    if MsgBox("保存这份PDF的" msgs.Length "句话？`n修改后功能二发送进度会从头开始，其他模式不受影响。", "确认保存", "YesNo Icon?") != "Yes"
        return
    old := Jobs[row].msgs
    Jobs[row].msgs := msgs
    try {
        SaveCustomJobs()
        CloseCustomEditor(editor)
        MsgBox("已保存：本份PDF发送" msgs.Length "次。")
    } catch as e {
        Jobs[row].msgs := old
        MsgBox("保存失败：" e.Message)
    }
}

DeleteCustomJob(*) {
    global Jobs, Running, Busy
    row := SelectedCustomRow()
    if !row || Running || Busy
        return
    if MsgBox("确定删除第" row "份PDF任务？`n只删除任务记录，不会删除PDF文件。功能二进度将重置。", "删除任务", "YesNo Icon!") != "Yes"
        return
    old := Jobs.RemoveAt(row)
    try SaveCustomJobs()
    catch as e {
        Jobs.InsertAt(row, old)
        MsgBox("删除失败：" e.Message)
    }
}

MoveCustomJob(dir) {
    global Jobs, Running, Busy, ManagerList
    row := SelectedCustomRow()
    if !row || Running || Busy
        return
    dest := row + dir
    if dest < 1 || dest > Jobs.Length
        return
    temp := Jobs[row]
    Jobs[row] := Jobs[dest]
    Jobs[dest] := temp
    try {
        SaveCustomJobs()
        ManagerList.Modify(dest, "Select Focus Vis")
    } catch as e {
        Jobs[dest] := Jobs[row]
        Jobs[row] := temp
        MsgBox("移动失败：" e.Message)
    }
}

GetChat() {
    global ChatHwnd, MainGui, AdvancedGui
    if (ChatHwnd && WinExist("ahk_id " ChatHwnd))
        return ChatHwnd
    ; 优先识别原ChatGPT V4已正常使用的独立桌面程序。
    try {
        h := WinExist("ahk_exe ChatGPT.exe")
        if h
            return h
    }
    try {
        h := WinGetID("A")
        if IsChatGPTWindow(h)
            return h
    }
    for h in WinGetList() {
        if IsChatGPTWindow(h)
            return h
    }
    return 0
}

IsChatGPTWindow(h) {
    global MainGui, AdvancedGui
    if !h || h = MainGui.Hwnd || h = AdvancedGui.Hwnd
        return false
    try {
        title := StrLower(WinGetTitle("ahk_id " h))
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "explorer.exe" || InStr(exe, "autohotkey") || InStr(title, "gemini"))
            return false
        if (exe = "chatgpt.exe")
            return true
        return InStr(title, "chatgpt") > 0
    }
    return false
}

BindChatGPTWindow(*) {
    global ChatHwnd, MainGui, AdvancedGui
    try {
        h := WinGetID("A")
        if !h || h = MainGui.Hwnd || h = AdvancedGui.Hwnd {
            MsgBox("先切换到 ChatGPT 桌面应用窗口，再按 Ctrl+Alt+0。", "窗口未绑定")
            return
        }
        title := WinGetTitle("ahk_id " h)
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "explorer.exe" || InStr(exe, "autohotkey") || InStr(StrLower(title), "gemini")) {
            MsgBox("当前窗口看起来不是 ChatGPT，请切换到 ChatGPT 再试。", "绑定失败")
            return
        }
        if !IsChatGPTWindow(h) {
            if MsgBox("当前窗口标题和程序名未明显显示 ChatGPT：`n" title "`n确定要绑定这个窗口吗？", "确认绑定", "YesNo Icon?") != "Yes"
                return
        }
        ChatHwnd := h
        ToolTip("已绑定 ChatGPT 窗口；可以校准附件＋、上传菜单与输入框")
        SetTimer(() => ToolTip(), -2300)
        UpdateCalibration()
    } catch as e {
        MsgBox("绑定失败：" e.Message)
    }
}

ActivateChat() {
    global ChatHwnd
    h := GetChat()
    if !h
        throw Error("找不到 ChatGPT 窗口；打开 ChatGPT 应用，切入目标对话并按 Ctrl+Alt+0 绑定")
    ChatHwnd := h
    WinActivate("ahk_id " h)
    if !WinWaitActive("ahk_id " h, , 5)
        throw Error("无法激活 ChatGPT 窗口")
    return h
}

Calibrate(which) {
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY, PrefPath
    h := GetChat()
    if !h {
        MsgBox("先打开 ChatGPT 桌面端，并按 Ctrl+Alt+0 绑定窗口，再将鼠标悬停在要校准的位置。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx - wx
    ry := my - wy
    if (which = "plus") {
        PlusX := rx, PlusY := ry
        IniWrite(rx, PrefPath, "coords", "plusX")
        IniWrite(ry, PrefPath, "coords", "plusY")
        title := "附件＋号"
    } else if (which = "upload") {
        UploadX := rx, UploadY := ry
        IniWrite(rx, PrefPath, "coords", "uploadX")
        IniWrite(ry, PrefPath, "coords", "uploadY")
        title := "上传文件菜单"
    } else if (which = "attached_input") {
        AttachedInputX := rx, AttachedInputY := ry
        IniWrite(rx, PrefPath, "coords", "attachedInputX")
        IniWrite(ry, PrefPath, "coords", "attachedInputY")
        title := "PDF已附加时的输入框"
    } else {
        InputX := rx, InputY := ry
        IniWrite(rx, PrefPath, "coords", "inputX")
        IniWrite(ry, PrefPath, "coords", "inputY")
        title := "普通聊天输入框"
    }
    UpdateCalibration()
    ToolTip("已保存：" title "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -1800)
}

UpdateCalibration() {
    global CalText, PlusX, UploadX, InputX, AttachedInputX, FreshPlusX, FreshUploadX, FreshInputX, NewChatX
    CalText.Text := "定位状态：附件＋ " (PlusX = "" ? "未设" : "✓")
        . "   上传菜单 " (UploadX = "" ? "未设" : "✓")
        . "   普通输入框 " (InputX = "" ? "未设" : "✓")
        . "   附件输入框 " (AttachedInputX = "" ? "沿用普通" : "✓")
        . "`n新对话：附件＋ " (FreshPlusX = "" ? "待校准5" : "✓")
        . "  上传菜单 " (FreshUploadX = "" ? "待校准6" : "✓")
        . "  输入框 " (FreshInputX = "" ? "待校准7" : "✓")
        . "  自动新建 " (NewChatX = "" ? "未校准9" : "✓")
}

ClickChat(which) {
    global InFreshComposer
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY, FreshInputX, FreshInputY, FreshAttachedX, FreshAttachedY
    global NewChatX, NewChatY
    h := ActivateChat()
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    if which = "new_chat" {
        rx := NewChatX, ry := NewChatY
    } else if InFreshComposer {
        if which = "plus"
            rx := FreshPlusX, ry := FreshPlusY
        else if which = "upload"
            rx := FreshUploadX, ry := FreshUploadY
        else if which = "attached_input" {
            ; 附加PDF的输入框如未单独校准，则沿用新对话普通输入框坐标。
            rx := FreshAttachedX != "" ? FreshAttachedX : FreshInputX
            ry := FreshAttachedY != "" ? FreshAttachedY : FreshInputY
        } else
            rx := FreshInputX, ry := FreshInputY
    } else {
        if which = "plus"
            rx := PlusX, ry := PlusY
        else if which = "upload"
            rx := UploadX, ry := UploadY
        else if which = "attached_input" {
            rx := AttachedInputX != "" ? AttachedInputX : InputX
            ry := AttachedInputY != "" ? AttachedInputY : InputY
        } else
            rx := InputX, ry := InputY
    }
    if rx = "" || ry = ""
        throw Error("当前" (InFreshComposer ? "空白新对话" : "旧对话") "尚未校准：" which "。请使用高级设置中的对应快捷键校准。")
    Click(wx+Number(rx), wy+Number(ry))
}

PutClipboard(text) {
    old := ClipboardAll()
    try {
        A_Clipboard := ""
        A_Clipboard := text
        if !ClipWait(3)
            throw Error("写入剪贴板失败")
        Send("^v")
        Sleep(550)
    } finally {
        A_Clipboard := old
    }
}

SendChatText(message, withAttachment := false) {
    ; 普通提问沿用ChatGPT V4已正常运行的输入方式。
    ; 带附件的首条消息避免Ctrl+A误选网页。
    ClickChat(withAttachment ? "attached_input" : "input")
    Sleep(350)
    if !withAttachment {
        Send("^a")
        Sleep(150)
    }
    PutClipboard(message)
    Sleep(250)
    Send("{Enter}")
    Sleep(1500)
}

AttachPDF(path) {
    global Running
    if !FileExist(path)
        throw Error("PDF 文件不存在：" path)
    ClickChat("plus")
    Sleep(850)
    ClickChat("upload")
    dialog := WinWaitActive("ahk_class #32770", , 14)
    if !dialog
        throw Error("没弹出文件选择框：请重新校准‘上传文件’菜单的位置")
    target := "ahk_id " dialog
    try {
        ControlFocus("Edit1", target)
        ControlSetText(path, "Edit1", target)
        ControlSend("{Enter}", "Edit1", target)
    } catch {
        ; 兼容部分 Windows 11 文件窗口：Alt+N 通常定位到“文件名”。
        Send("!n")
        Sleep(200)
        Send("^a")
        PutClipboard(path)
        Send("{Enter}")
    }
    if !WinWaitClose(target, , 16)
        throw Error("文件选择窗口未关闭，PDF可能未选择成功")
    ; 文件可见与上传完成的判断不是官方接口，只能留足上传准备时间。
    Sleep(12000)
}

ToChinese(n) {
    chars := ["零","一","二","三","四","五","六","七","八","九"]
    if (n < 10)
        return chars[n+1]
    if (n < 20)
        return "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 100)
        return chars[Floor(n/10)+1] "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 1000) {
        r := Mod(n, 100)
        return chars[Floor(n/100)+1] "百" (r = 0 ? "" : (r < 10 ? "零" chars[r+1] : ToChinese(r)))
    }
    return String(n)
}

ParseQuestions(spec, lineNo) {
    result := []
    seen := Map()
    for item in StrSplit(StrReplace(spec, "，", ","), ",") {
        item := Trim(item)
        if item = ""
            continue
        item := StrReplace(StrReplace(item, "—", "-"), "–", "-")
        if RegExMatch(item, "^\d+$") {
            n := Number(item)
            if (n < 1 || n > 9999)
                throw Error("第" lineNo "行题号超出范围")
            if !seen.Has(n) {
                result.Push(n)
                seen[n] := true
            }
        } else if RegExMatch(item, "^\d+\s*-\s*\d+$") {
            segments := StrSplit(item, "-")
            a := Number(Trim(segments[1]))
            b := Number(Trim(segments[2]))
            if (a < 1 || a > b || b > 9999 || b-a > 500)
                throw Error("第" lineNo "行题号范围无效或过大：" item)
            Loop b-a+1 {
                n := a+A_Index-1
                if !seen.Has(n) {
                    result.Push(n)
                    seen[n] := true
                }
            }
        } else
            throw Error("第" lineNo "行的题号格式错误：" item)
    }
    if !result.Length
        throw Error("第" lineNo "行没有有效题号")
    return result
}

ManifestId(src) {
    ; 用于防止任务清单变更后误用旧进度。轻量非安全哈希。
    h := 2166136261
    Loop Parse src {
        h := Mod(((h ^ Ord(A_LoopField)) * 16777619), 4294967296)
    }
    return Format("{:08X}", h)
}

ReloadJobs(*) {
    global Jobs, TaskPath, Signature, Running, CountText, Mode
    if Running {
        MsgBox("请先按 F9 暂停，再重新载入任务。")
        return
    }
    raw := FileRead(TaskPath, "UTF-8")
    freshJobs := []
    lineNo := 0
    for line in StrSplit(raw, "`n") {
        lineNo++
        line := Trim(line, " `t`r`n")
        if (line = "" || SubStr(line, 1, 1) = "#")
            continue
        msgs := []
        if Mode = "questions" {
            parts := StrSplit(line, "|")
            if (parts.Length != 2)
                throw Error("任务清单第" lineNo "行须用 | 分隔PDF路径和题号")
            path := Trim(parts[1], " `t`r`n" Chr(34))
            if !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            qs := ParseQuestions(Trim(parts[2]), lineNo)
            SplitPath(path, &name)
        } else if Mode = "custom" {
            parts := StrSplit(line, "|")
            if parts.Length < 2
                throw Error("自定义任务第" lineNo "行缺少话语。请用【管理每份PDF的话语】编辑。")
            path := UnescapeCustomField(parts[1])
            if path = "@NO_PDF"
                path := ""
            if path != "" && !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            name := "当前对话（无需上传PDF）"
            if path != ""
                SplitPath(path, &name)
            Loop parts.Length - 1 {
                message := UnescapeCustomField(parts[A_Index + 1])
                if Trim(message) = ""
                    throw Error("自定义任务第" lineNo "行有空话语")
                msgs.Push(message)
            }
            qs := []
            Loop msgs.Length
                qs.Push(A_Index)
        } else {
            ; 功能一：固定话语，每份PDF只发送同一句。
            if line = "@NO_PDF" {
                path := ""
                name := "当前对话（无需上传PDF）"
            } else {
                path := Trim(line, " `t`r`n" Chr(34))
                if !FileExist(path)
                    throw Error("找不到第" lineNo "行的PDF：" path)
                SplitPath(path, &name)
            }
            qs := [1]
        }
        freshJobs.Push({path: path, name: name, qs: qs, msgs: msgs})
    }
    newSignature := ManifestId(raw)
    oldSignature := IniRead(StatePath, "progress", "task_id", "")
    if (oldSignature != "" && newSignature != oldSignature) {
        answer := MsgBox("检测到PDF任务清单已改变。是否从新清单的第1份PDF重新开始？`n选择‘否’会取消载入。", "任务清单改变", "YesNo Icon!")
        if answer != "Yes"
            return
        ResetState(newSignature)
    }
    Jobs := freshJobs
    Signature := newSignature
    RestoreProgress()
    total := 0
    for job in Jobs
        total += job.qs.Length
    CountText.Text := "已载入：" Jobs.Length " 份任务，共 " total " 条" (Mode = "questions" ? "逐题提问" : "话语") "。当前模式：" (Mode = "custom" ? "每PDF自定义" : Mode = "single" ? "固定话语" : "原版逐题")
    ShowProgress()
    if Mode = "custom"
        RefreshCustomManager()
}


; 【重新载入任务】按钮：清空当前模式的任务清单并重置当前模式的断点。
; ReloadJobs 保持原样：脚本启动和添加PDF时仍然读取任务，不会误清空。
ClearTaskList(*) {
    global TaskPath, Running, Busy
    if (Running || Busy) {
        MsgBox("先按 F9 暂停，等当前上传或发送结束后再清空任务。", "任务正在运行")
        return
    }
    try {
        ; 保留一份旧清单备份，以免误点后无法找回任务路径。
        oldContent := FileRead(TaskPath, "UTF-8")
        backup := ""
        if RegExMatch(oldContent, "m)^\s*[^#\s].*$") {
            backup := A_ScriptDir "\ChatGPT_PDF任务清单_备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") "_" A_TickCount ".txt"
            FileCopy(TaskPath, backup)
        }
        ; 只保留格式说明。原PDF文件、计时与校准设置不会被删除。
        starter := TaskTemplate()
        temp := TaskPath ".new"
        if FileExist(temp)
            FileDelete(temp)
        FileAppend(starter, temp, "UTF-8")
        FileMove(temp, TaskPath, 1)

        ; 写入新空清单的标识，重置进度，再按旧逻辑重新读取。
        ResetState(ManifestId(FileRead(TaskPath, "UTF-8")))
        ReloadJobs()
        msg := "✓ 旧PDF任务已清空，发送进度已重置。`n点击【添加 PDF 任务】录入新PDF即可。原PDF和时间/坐标设置未改变。"
        if (backup != "")
            msg .= "`n已自动备份原任务清单：" backup
        SetStatus(msg)
    } catch as e {
        MsgBox("清空任务失败：" e.Message, "错误")
        SetStatus("⚠ 清空任务失败。请检查任务文件是否被占用；旧任务可能未更改。")
    }
}

AddPdfJob(*) {
    global TaskPath, Running, Mode, Busy, Jobs, EditorOpen
    if Running || Busy || EditorOpen {
        MsgBox("请先F9暂停并结束编辑，再添加PDF。")
        return
    }
    chosen := Mode = "questions" ? FileSelect(1, , "选择要上传的PDF", "PDF 文件 (*.pdf)") : FileSelect("M1", , "可按 Ctrl 多选PDF，依次加入任务", "PDF 文件 (*.pdf)")
    if !chosen
        return
    if Mode = "questions" {
        box := InputBox("输入这份PDF要提问的题号。例如：8-10,12,15-17", "设置题号", "w460 h150", "8-10")
        if box.Result != "OK"
            return
        try ParseQuestions(box.Value, 1)
        catch as e {
            MsgBox(e.Message, "题号格式错误")
            return
        }
        FileAppend(chosen "|" box.Value "`r`n", TaskPath, "UTF-8")
        ReloadJobs()
        return
    }
    files := chosen is Array ? chosen : [chosen]
    if Mode = "custom" {
        for pdf in files {
            SplitPath(pdf, &name)
            Jobs.Push({path: pdf, name: name, qs: [1], msgs: [DefaultCustomMessage()]})
        }
        try {
            SaveCustomJobs()
            OpenCustomManager()
        } catch as e
            MsgBox("添加PDF失败：" e.Message)
    } else {
        for pdf in files
            FileAppend(pdf "`r`n", TaskPath, "UTF-8")
        ReloadJobs()
    }
}

EditJobs(*) {
    global TaskPath, Mode
    if Mode = "custom" {
        OpenCustomManager()
        return
    }
    Run('notepad.exe "' TaskPath '"')
}

ResetState(sig) {
    global StatePath, StartProfileBox
    IniWrite(sig, StatePath, "progress", "task_id")
    IniWrite("1", StatePath, "progress", "job")
    IniWrite("1", StatePath, "progress", "question")
    IniWrite("upload", StatePath, "progress", "stage")
    IniWrite("", StatePath, "progress", "until")
    IniWrite("1", StatePath, "progress", "chat_group_start")
    IniWrite("0", StatePath, "progress", "awaiting_new_chat")
    IniWrite(String(StartProfileBox.Value = 2 ? 1 : 0), StatePath, "progress", "fresh_profile")
}

ResetProgress(*) {
    global Running, Signature, Jobs
    if Running {
        MsgBox("先按 F9 暂停后才能重置。")
        return
    }
    if MsgBox("确定把发送进度清零吗？注意：重置后会重新上传第一份PDF、重新发送话语或题目。", "重置进度", "YesNo Icon!") != "Yes"
        return
    ResetState(Signature)
    RestoreProgress()
    ShowProgress()
}

RestoreProgress() {
    global StatePath, JobIndex, QuestionIndex, Stage, WaitUntil, ChatGroupStartJob, NeedManualNewChat, InFreshComposer, StartProfileBox
    JobIndex := Number(IniRead(StatePath, "progress", "job", "1"))
    QuestionIndex := Number(IniRead(StatePath, "progress", "question", "1"))
    Stage := IniRead(StatePath, "progress", "stage", "upload")
    WaitUntil := IniRead(StatePath, "progress", "until", "")
    ChatGroupStartJob := Number(IniRead(StatePath, "progress", "chat_group_start", "1"))
    NeedManualNewChat := IniRead(StatePath, "progress", "awaiting_new_chat", "0") = "1"
    InFreshComposer := IniRead(StatePath, "progress", "fresh_profile", StartProfileBox.Value = 2 ? "1" : "0") = "1"
}

SaveProgress() {
    global StatePath, Signature, JobIndex, QuestionIndex, Stage, WaitUntil, ChatGroupStartJob, NeedManualNewChat, InFreshComposer
    IniWrite(Signature, StatePath, "progress", "task_id")
    IniWrite(String(JobIndex), StatePath, "progress", "job")
    IniWrite(String(QuestionIndex), StatePath, "progress", "question")
    IniWrite(Stage, StatePath, "progress", "stage")
    IniWrite(WaitUntil, StatePath, "progress", "until")
    IniWrite(String(ChatGroupStartJob), StatePath, "progress", "chat_group_start")
    IniWrite(NeedManualNewChat ? "1" : "0", StatePath, "progress", "awaiting_new_chat")
    IniWrite(InFreshComposer ? "1" : "0", StatePath, "progress", "fresh_profile")
}

SetStatus(info) {
    global StatusText
    StatusText.Text := info
}

ShowProgress() {
    global Jobs, JobIndex, QuestionIndex, Stage, WaitUntil, Running, Mode
    if (Stage = "done") {
        SetStatus("✓ 全部PDF及对应提问已经发送完毕。注意这只代表脚本完成发送，不代表回答已结束。")
        return
    }
    if Jobs.Length = 0 {
        SetStatus("还没有任务。添加PDF任务；功能一、二都可以点【只发话语】。")
        return
    }
    if (JobIndex > Jobs.Length) {
        SetStatus("进度超出任务数量，请重置进度。")
        return
    }
    j := Jobs[JobIndex]
    qText := QuestionIndex <= j.qs.Length ? (Mode = "questions" ? "第" j.qs[QuestionIndex] "题" : "第" QuestionIndex "/" j.qs.Length "条话语") : "等待切换"
    msg := (Running ? "运行中" : "未运行/已暂停") "｜PDF " JobIndex "/" Jobs.Length "：" j.name
        . "`n当前阶段：" Stage "｜" qText
    if (Stage = "upload_wait" || Stage = "question_wait" || Stage = "pdf_wait") {
        secs := WaitUntil != "" ? Max(0, DateDiff(WaitUntil, A_Now, "Seconds")) : 0
        msg .= "｜剩余约" secs "秒"
    }
    SetStatus(msg)
}

ValidateTimers() {
    global QBox, PBox, UBox, QWait, PDFWait, UploadWait, PrefPath
    qText := Trim(QBox.Value)
    pText := Trim(PBox.Value)
    uText := Trim(UBox.Value)
    if !RegExMatch(qText, "^\d+$") || !RegExMatch(pText, "^\d+$") || !RegExMatch(uText, "^\d+$")
        throw Error("等待时间请输入整数")
    q := Number(qText), p := Number(pText), u := Number(uText)
    if (q < 1 || q > 120 || p < 1 || p > 120 || u < 15 || u > 3600)
        throw Error("每题及PDF间隔为1~120分钟；上传后的等待为15~3600秒")
    QWait := q, PDFWait := p, UploadWait := u
    IniWrite(String(q), PrefPath, "timing", "question_minutes")
    IniWrite(String(p), PrefPath, "timing", "pdf_minutes")
    IniWrite(String(u), PrefPath, "timing", "upload_seconds")
}

StartRun() {
    global Running, Jobs, Stage, ChatHwnd, Busy, Mode, Msg1Box, SendMsg1, NeedManualNewChat, ChatGroupStartJob, JobIndex, InFreshComposer
    if Running {
        ShowProgress()
        return
    }
    if !Jobs.Length {
        MsgBox("先添加至少一份PDF任务。", "没有任务")
        return
    }
    if Stage = "done" {
        MsgBox("任务已经完成。若要从头来，请使用‘重置发送进度’。")
        return
    }
    try {
        ValidateTimers()
        SaveConversationOptions()
        SaveMessageSettings()
        SendMsg1 := Trim(Msg1Box.Value)
        if Mode = "single" && SendMsg1 = ""
            throw Error("功能一请填写固定话语")
        if Mode = "custom" {
            for job in Jobs {
                if job.msgs.Length < 1
                    throw Error("有PDF还没设置话语：" job.name)
            }
        }
        if NeedManualNewChat {
            answer := MsgBox("此处必须开始一个全新的ChatGPT对话。`n`n请先在ChatGPT中手动点击【新建聊天】，确认页面空白；必要时按Ctrl+Alt+0绑定窗口。`n`n已经进入新的空白对话了吗？", "确认切换新对话", "YesNo Icon?")
            if answer != "Yes"
                return
            NeedManualNewChat := false
            ChatGroupStartJob := JobIndex
            InFreshComposer := true
            SaveProgress()
        }
        ChatHwnd := ActivateChat()
        Running := true
        ShowProgress()
        SetTimer(Tick, 1000) ; 必须保持周期定时器，避免只发一次就停止
        Tick()
    } catch as e {
        Running := false
        MsgBox(e.Message, "无法开始")
    }
}

PauseRun() {
    global Running
    Running := false
    ShowProgress()
}

FastForward() {
    global Running, Stage, WaitUntil
    if (Stage != "upload_wait" && Stage != "question_wait" && Stage != "pdf_wait") {
        SetStatus("当前不在等待阶段，F10不会跳过PDF或题目。")
        return
    }
    if !Running
        StartRun()
    if !Running
        return
    WaitUntil := A_Now
    SaveProgress()
    SetTimer(Tick, 1000)
    Tick()
}

BeginWait(nextStage, seconds) {
    global Stage, WaitUntil
    Stage := nextStage
    WaitUntil := DateAdd(A_Now, seconds, "Seconds")
    SaveProgress()
}

Tick(*) {
    global Running, Busy, Jobs, JobIndex, QuestionIndex, Stage, WaitUntil, Mode, SendMsg1
    global UploadWait, QWait, PDFWait, InFreshComposer, ChatGroupStartJob, NeedManualNewChat
    global MaxPDFBox, AutoSwitchBox, NewChatX, NewChatY
    if !Running || Busy
        return
    if !Jobs.Length || Stage = "done"
        return
    Busy := true
    try {
        if (Stage = "upload_wait" || Stage = "question_wait" || Stage = "pdf_wait") {
            if (WaitUntil != "" && DateDiff(WaitUntil, A_Now, "Seconds") > 0) {
                ShowProgress()
                return
            }
            WaitUntil := ""
            if Stage = "upload_wait"
                Stage := "question"
            else if Stage = "question_wait"
                Stage := "question"
            else {
                JobIndex += 1
                QuestionIndex := 1
                Stage := "upload"
            }
            SaveProgress()
        }

        if (JobIndex > Jobs.Length) {
            Stage := "done"
            SaveProgress()
            Running := false
            ShowProgress()
            return
        }
        job := Jobs[JobIndex]
        if (Stage = "upload") {
            limit := Number(Trim(MaxPDFBox.Value) = "" ? "0" : MaxPDFBox.Value)
            if limit > 0 && JobIndex > 1 && Mod(JobIndex-1, limit) = 0 && ChatGroupStartJob != JobIndex {
                ; 在下一份PDF上传之前切换新聊天，避免把第11份误发到已满的旧聊天。
                if AutoSwitchBox.Value && NewChatX != "" && NewChatY != "" {
                    SetStatus("已达" limit "份PDF：尝试自动新建ChatGPT对话（请不要操作窗口）")
                    ClickChat("new_chat")
                    Sleep(2600)
                    ChatGroupStartJob := JobIndex
                    InFreshComposer := true
                    SaveProgress()
                    WriteLog("已点击新建ChatGPT对话，后续按新对话布局发送第" JobIndex "份PDF")
                } else {
                    NeedManualNewChat := true
                    Running := false
                    SaveProgress()
                    SetStatus("⏸ 已完成前" (JobIndex-1) "份PDF；请在ChatGPT手动新建空白聊天、Ctrl+Alt+0绑定并按F8。`n不会重发先前的PDF，也不会清空任务。")
                    return
                }
            }
            if (Mode = "questions" || job.path != "") {
                SetStatus("正在上传PDF " JobIndex "/" Jobs.Length "：" job.name "`n不要操作鼠标或键盘……")
                AttachPDF(job.path)
                SendChatText("请接收这份PDF《" job.name "》，后续提问均针对这份PDF。", true)
                ; 首条成功执行发送键后，ChatGPT会从空白新聊天进入已有消息聊天布局。
                InFreshComposer := false
                BeginWait("upload_wait", UploadWait)
                WriteLog("已发送PDF：" job.path)
            } else {
                ; 当前对话已有资料时可不再次上传PDF、不发介绍语。
                BeginWait("upload_wait", 1)
                WriteLog("纯文字任务准备开始")
            }
        } else if (Stage = "question") {
            if Mode = "questions" {
                q := job.qs[QuestionIndex]
                msg := "这份PDF第" ToChinese(q) "题没懂"
            } else if Mode = "single"
                msg := SendMsg1
            else
                msg := job.msgs[QuestionIndex]
            SetStatus("正在发送：" job.name " → " msg)
            SendChatText(msg)
            InFreshComposer := false
            WriteLog("已发送提问：" job.name "：" msg)
            if (QuestionIndex < job.qs.Length) {
                QuestionIndex += 1
                BeginWait("question_wait", QWait*60)
            } else if (JobIndex < Jobs.Length) {
                BeginWait("pdf_wait", PDFWait*60)
            } else {
                Stage := "done"
                WaitUntil := ""
                SaveProgress()
                Running := false
            }
        }
        ShowProgress()
    } catch as e {
        Running := false
        WriteLog("失败：" e.Message)
        SetStatus("⚠ 已暂停：" e.Message "`n请检查ChatGPT是否正常、PDF是否上传成功、消息是否已发送。排查后按F8恢复；必要时重置进度。")
    } finally {
        Busy := false
    }
}

WriteLog(info) {
    global LogPath
    FileAppend(FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " " info "`r`n", LogPath, "UTF-8")
}
