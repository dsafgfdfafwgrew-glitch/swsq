﻿#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
SetTitleMatchMode(2)
SendMode("Input")
CoordMode("Mouse", "Screen")
CoordMode("Pixel", "Screen")
global MergedLockOwner := ""
global MergedInChildCall := false
global MergedNextTurn := "chatgpt"
global MergedExitRequested := false
global MergedMode := 1
global MergedBackupPath := ""
MergedBackup()
CG_Init()
GM_Init()
global MergedControllers := Map(
    "chatgpt", {start:CG_StartRun, tick:CG_Tick, ready:CG_IsReadyForScheduler, status:CG_SchedulerStatus, bind:CG_BindChatGPTWindow, calibrate:CG_Calibrate, fresh:CG_CalibrateFresh, skip:CG_FastForward},
    "gemini", {start:GM_StartRun, tick:GM_Tick, ready:GM_IsReadyForScheduler, status:GM_SchedulerStatus, bind:GM_BindGeminiWindow, calibrate:GM_Calibrate, fresh:GM_CalibrateFresh, skip:GM_FastForward})
global MergedMainGui := Gui("+AlwaysOnTop", "ChatGPT + Gemini 双平台 V1.0.1 · 待Windows验收")
MergedMainGui.SetFont("s10", "Microsoft YaHei")
MergedMainGui.AddText("xm", "运行目标：")
global MergedPlatformBox := MergedMainGui.AddDropDownList("x+8 yp-4 w180", ["ChatGPT", "Gemini", "双平台调度"])
MergedPlatformBox.Choose(1)
MergedPlatformBox.OnEvent("Change", MergedModeChanged)
MergedMainGui.AddText("x+14 yp+4", "校准/核实目标：")
global MergedTargetBox := MergedMainGui.AddDropDownList("x+8 yp-4 w130", ["ChatGPT", "Gemini"])
MergedTargetBox.Choose(1)
MergedMainGui.AddButton("xm y+15 w120", "开始 / 继续 F8").OnEvent("Click", MergedStart)
MergedMainGui.AddButton("x+8 yp w120", "全部暂停 F9").OnEvent("Click", MergedPause)
MergedMainGui.AddButton("x+8 yp w130", "跳过等待 F10").OnEvent("Click", MergedFastForward)
MergedMainGui.AddButton("x+8 yp w100", "退出 F12").OnEvent("Click", MergedExit)
MergedMainGui.AddButton("xm y+10 w135", "ChatGPT任务设置").OnEvent("Click", (*) => MergedOpenSettings("chatgpt", false))
MergedMainGui.AddButton("x+8 yp w135", "Gemini任务设置").OnEvent("Click", (*) => MergedOpenSettings("gemini", false))
MergedMainGui.AddButton("x+8 yp w135", "ChatGPT高级设置").OnEvent("Click", (*) => MergedOpenSettings("chatgpt", true))
MergedMainGui.AddButton("x+8 yp w135", "Gemini高级设置").OnEvent("Click", (*) => MergedOpenSettings("gemini", true))
MergedMainGui.AddButton("xm y+10 w220", "核实目标平台的发送结果").OnEvent("Click", MergedResolve)
MergedMainGui.AddText("x+10 yp+5 w335", "Enter 后待核实，确认已发出才推进。")
global MergedStatusText := MergedMainGui.AddText("xm y+15 w590 h125", "")
MergedMainGui.OnEvent("Close", MergedExit)
MergedMainGui.Show("w620")
OnExit(MergedOnExit)
SetTimer(MergedTick, 500)
MergedShowStatus()
return

F8::MergedStart()
F9::MergedPause()
F10::MergedFastForward()
F12::MergedExit()
^!0::MergedBind()
^!1::MergedCalibrate("plus")
^!2::MergedCalibrate("upload")
^!3::MergedCalibrate("input")
^!4::MergedCalibrate("attached_input")
^!5::MergedCalibrateFresh("plus")
^!6::MergedCalibrateFresh("upload")
^!7::MergedCalibrateFresh("input")
^!8::MergedCalibrateFresh("attached_input")
^!9::MergedCalibrateFresh("new_chat")
^+!r::MergedInvoke("gemini", GM_CalibrateCleanupRemove)
^+!s::MergedInvoke("gemini", GM_ConfirmSkipCleanupOnce)

MergedBackup() {
    global MergedBackupPath
    dest := A_ScriptDir "\升级备份\" FormatTime(, "yyyyMMdd_HHmmss") "_" A_TickCount
    DirCreate(dest)
    for pattern in ["*.ini", "*任务清单.txt"] {
        Loop Files A_ScriptDir "\" pattern, "F"
            FileCopy(A_LoopFileFullPath, dest "\" A_LoopFileName, false)
    }
    for name in ["ChatGPT_MultiPDF_AutoSend", "Gemini_MultiPDF_AutoSend"] {
        if DirExist(A_AppData "\" name)
            DirCopy(A_AppData "\" name, dest "\" name, false)
    }
    MergedBackupPath := dest
}

MergedInvoke(owner, fn, args*) {
    global MergedLockOwner, MergedInChildCall, MergedExitRequested
    Critical("On")
    if MergedLockOwner != "" {
        Critical("Off")
        return false
    }
    MergedLockOwner := owner
    MergedInChildCall := true
    Critical("Off")
    try {
        fn.Call(args*)
        return true
    } catch as e {
        MergedStopOne(owner)
        MergedStatus(owner "：" e.Message)
        try FileAppend(FormatTime(, "yyyy-MM-dd HH:mm:ss") " " owner " " e.Message "`r`n", A_ScriptDir "\双平台诊断日志.txt", "UTF-8")
        return false
    } finally {
        MergedInChildCall := false
        MergedLockOwner := ""
        if MergedExitRequested
            ExitApp()
    }
}
MergedStopOne(owner) {
    global CG_Running, GM_Running
    if owner = "chatgpt"
        CG_Running := false
    else
        GM_Running := false
}
MergedPause(*) {
    global CG_Running, GM_Running
    CG_Running := false
    GM_Running := false
    MergedStatus("已请求全部暂停。当前操作会在安全边界停止；正在执行的Enter不会重复发送。")
}
MergedExit(*) {
    global MergedExitRequested, MergedLockOwner
    MergedPause()
    if MergedLockOwner != "" {
        MergedExitRequested := true
        return
    }
    ExitApp()
}
MergedOnExit(*) {
    try CG_OnScriptExit()
    try GM_OnScriptExit()
    return 0
}
MergedModeChanged(*) {
    global MergedMode, MergedPlatformBox
    MergedMode := MergedPlatformBox.Value
    MergedPause()
}
MergedCalibrationOwner() {
    global MergedTargetBox
    return MergedTargetBox.Value = 2 ? "gemini" : "chatgpt"
}
MergedStart(*) {
    global MergedMode, MergedControllers, MergedLockOwner
    if MergedLockOwner != ""
        return
    if IsObject(CG_ManagerGui) || CG_EditorOpen || IsObject(GM_ManagerGui) || GM_EditorOpen || IsObject(GM_UploadIntroGui) {
        MsgBox("请先保存并关闭两平台的话语/上传说明编辑窗口")
        return
    }
    CG_MainGui.Hide()
    CG_AdvancedGui.Hide()
    GM_MainGui.Hide()
    GM_AdvancedGui.Hide()
    for owner in ["chatgpt", "gemini"] {
        if MergedMode = 3 || (MergedMode = 1 && owner = "chatgpt") || (MergedMode = 2 && owner = "gemini")
            MergedInvoke(owner, MergedControllers[owner].start)
        else
            MergedStopOne(owner)
    }
    MergedShowStatus()
}
MergedFastForward(*) {
    global MergedControllers, MergedLockOwner
    if MergedLockOwner != ""
        return
    owner := MergedCalibrationOwner()
    MergedInvoke(owner, MergedControllers[owner].skip)
}
MergedBind(*) {
    global MergedControllers
    owner := MergedCalibrationOwner()
    MergedInvoke(owner, MergedControllers[owner].bind)
}
MergedCalibrate(which) {
    global MergedControllers
    owner := MergedCalibrationOwner()
    MergedInvoke(owner, MergedControllers[owner].calibrate, which)
}
MergedCalibrateFresh(which) {
    global MergedControllers
    owner := MergedCalibrationOwner()
    MergedInvoke(owner, MergedControllers[owner].fresh, which)
}
MergedOpenSettings(owner, advanced) {
    global MergedLockOwner
    if MergedLockOwner != ""
        return
    MergedPause()
    if owner = "chatgpt" {
        if advanced
            CG_AdvancedGui.Show("w730 h370")
        else
            CG_MainGui.Show("w700 h430")
    } else {
        if advanced
            GM_AdvancedGui.Show("w760 h505")
        else
            GM_MainGui.Show("w700 h430")
    }
}
GM_TestGeminiUploadPickerManaged(*) {
    MergedInvoke("gemini", GM_TestGeminiUploadPicker)
}
MergedTick(*) {
    global MergedLockOwner, MergedNextTurn, MergedControllers, MergedMode, MergedMainGui
    if MergedLockOwner != ""
        return
    for owner in [MergedNextTurn, MergedNextTurn = "chatgpt" ? "gemini" : "chatgpt"] {
        if (MergedMode = 1 && owner != "chatgpt") || (MergedMode = 2 && owner != "gemini")
            continue
        if MergedControllers[owner].ready.Call() {
            MergedNextTurn := owner = "chatgpt" ? "gemini" : "chatgpt"
            MergedMainGui.Hide()
            try MergedInvoke(owner, MergedControllers[owner].tick)
            finally MergedMainGui.Show("NA")
            break
        }
    }
    MergedShowStatus()
}
MergedShowStatus() {
    global MergedStatusText, MergedLockOwner
    MergedStatusText.Text := "ChatGPT：" CG_SchedulerStatus() "`nGemini：" GM_SchedulerStatus() "`n设备锁：" (MergedLockOwner = "" ? "空闲" : MergedLockOwner)
}
MergedStatus(info) {
    global MergedStatusText
    if IsObject(MergedStatusText)
        MergedStatusText.Text := info
}
MergedRequireFocus(owner, hwnd) {
    global CG_Running, GM_Running
    if !(owner = "chatgpt" ? CG_Running : GM_Running)
        throw Error("已暂停，尚未执行下一次输入")
    if !hwnd || !WinActive("ahk_id " hwnd)
        throw Error("目标窗口失去焦点，停止输入")
}
MergedBeforeSend(owner, hwnd) {
    global CG_Stage, GM_Stage
    MergedRequireFocus(owner, hwnd)
    if owner = "chatgpt" {
        CG_Stage := "verify_" CG_Stage
        CG_SaveProgress()
    } else {
        GM_Stage := "verify_" GM_Stage
        GM_SaveProgress()
    }
}
MergedResolve(*) {
    owner := MergedCalibrationOwner()
    MergedInvoke(owner, MergedResolveCore, owner)
}
MergedResolveCore(owner) {
    global CG_Stage, GM_Stage
    stage := owner = "chatgpt" ? CG_Stage : GM_Stage
    if SubStr(stage, 1, 7) != "verify_" {
        MsgBox("该平台没有待核实的发送。")
        return
    }
    result := MsgBox("请查看 " owner " 的聊天记录，核对本条消息与PDF附件。`n是：已发出，推进当前步骤。`n否：确认未发出，保留附件；请清空残留文字后再F8重试。`n取消：无法确定，继续保持待核实。", "核实发送结果", "YesNoCancel Icon?")
    if result = "Cancel"
        return
    if result = "No" {
        if owner = "chatgpt" {
            CG_Stage := SubStr(stage, 8)
            CG_SaveProgress()
        } else {
            GM_Stage := SubStr(stage, 8)
            GM_SaveProgress()
        }
        return
    }
    if owner = "chatgpt"
        CG_ConfirmSent()
    else
        GM_ConfirmSent()
    MergedShowStatus()
}

CG_IsReadyForScheduler() {
    global CG_Running, CG_Busy, CG_Stage, CG_WaitUntil
    if !CG_Running || CG_Busy || CG_Stage = "done" || SubStr(CG_Stage, 1, 7) = "verify_"
        return false
    if (CG_Stage = "upload_wait" || CG_Stage = "question_wait" || CG_Stage = "pdf_wait") && CG_WaitUntil != "" && DateDiff(CG_WaitUntil, A_Now, "Seconds") > 0
        return false
    return true
}
CG_SchedulerStatus() {
    global CG_Running, CG_Stage, CG_JobIndex, CG_Jobs, CG_WaitUntil, CG_StatusText
    if CG_Stage = "done"
        return "完成"
    if SubStr(CG_Stage, 1, 7) = "verify_"
        return "待核实发送：任务 " CG_JobIndex
    if !CG_Running
        return "已暂停 " SubStr(CG_StatusText.Text, 1, 110)
    if CG_WaitUntil != ""
        return CG_Stage " 剩余 " Max(0, DateDiff(CG_WaitUntil, A_Now, "Seconds")) " 秒"
    return CG_Stage " 任务 " CG_JobIndex "/" CG_Jobs.Length
}
CG_ConfirmSent() {
    global CG_Stage, CG_InFreshComposer, CG_UploadWait, CG_Jobs, CG_JobIndex, CG_QuestionIndex, CG_QWait, CG_PDFWait, CG_WaitUntil, CG_Running, CG_Mode
    prior := SubStr(CG_Stage, 8)
    job := CG_Jobs[CG_JobIndex]
    CG_InFreshComposer := false
    if prior = "upload_ready" {
        CG_BeginWait("upload_wait", CG_UploadWait)
    } else if prior = "question" {
        if CG_QuestionIndex < job.qs.Length {
            CG_QuestionIndex += 1
            CG_BeginWait("question_wait", CG_QWait*60)
        } else if CG_JobIndex < CG_Jobs.Length
            CG_BeginWait("pdf_wait", CG_PDFWait*60)
        else {
            CG_Stage := "done"
            CG_WaitUntil := ""
        }
    } else
        throw Error("未知待核实阶段：" prior)
    CG_Running := false
    CG_SaveProgress()
    CG_ShowProgress()
}

GM_IsReadyForScheduler() {
    global GM_Running, GM_Busy, GM_Stage, GM_WaitUntil
    if !GM_Running || GM_Busy || GM_Stage = "done" || SubStr(GM_Stage, 1, 7) = "verify_"
        return false
    if (GM_Stage = "upload_wait" || GM_Stage = "question_wait" || GM_Stage = "pdf_wait") && GM_WaitUntil != "" && DateDiff(GM_WaitUntil, A_Now, "Seconds") > 0
        return false
    return true
}
GM_SchedulerStatus() {
    global GM_Running, GM_Stage, GM_JobIndex, GM_Jobs, GM_WaitUntil, GM_StatusText
    if GM_Stage = "done"
        return "完成"
    if SubStr(GM_Stage, 1, 7) = "verify_"
        return "待核实发送：任务 " GM_JobIndex
    if !GM_Running
        return "已暂停 " SubStr(GM_StatusText.Text, 1, 110)
    if GM_WaitUntil != ""
        return GM_Stage " 剩余 " Max(0, DateDiff(GM_WaitUntil, A_Now, "Seconds")) " 秒"
    return GM_Stage " 任务 " GM_JobIndex "/" GM_Jobs.Length
}
GM_ConfirmSent() {
    global GM_Stage, GM_InFreshComposer, GM_UploadWait, GM_Jobs, GM_JobIndex, GM_QuestionIndex, GM_QWait, GM_PDFWait, GM_WaitUntil, GM_Running, GM_Mode
    prior := SubStr(GM_Stage, 8)
    job := GM_Jobs[GM_JobIndex]
    GM_InFreshComposer := false
    if prior = "upload_ready" {
        if GM_Mode = "together" || (GM_Mode = "custom" && job.msgs.Length = 0)
            GM_FinishOnePDF()
        else
            GM_BeginWait("upload_wait", GM_UploadWait)
    } else if prior = "question" {
        if GM_QuestionIndex < job.qs.Length {
            GM_QuestionIndex += 1
            GM_BeginWait("question_wait", GM_QWait*60)
        } else if GM_JobIndex < GM_Jobs.Length
            GM_BeginWait("pdf_wait", GM_PDFWait*60)
        else {
            GM_Stage := "done"
            GM_WaitUntil := ""
        }
    } else
        throw Error("未知待核实阶段：" prior)
    GM_Running := false
    GM_SaveProgress()
    GM_ShowProgress()
}

CG_Init() {
SetTitleMatchMode(2)
SendMode("Input")
CoordMode("Mouse", "Screen") ; 以下保存/点击的都是屏幕绝对坐标

; Windows AutoHotkey v2 | ChatGPT 桌面端多 PDF 顺序上传与逐题发送
; 不调用 API，不读取 PDF 题目内容。使用桌面窗口坐标定位附件按钮、上传菜单、输入框。
; 暂停/恢复依靠进度.ini；允许新对话首发，也允许按每对话PDF数自动/手动切换。
; 若 ChatGPT 不是独立 exe，而是 Chrome/Edge 安装的桌面应用，可先按 Ctrl+Alt+0 绑定当前 ChatGPT 窗口。
; 仅当附件按钮能调出 Windows 文件选择对话框时上传流程可用。

baseDir := A_ScriptDir
global CG_TaskPath := baseDir "\PDF任务清单.txt"
; V4.4：设置不再存放在脚本所在目录，避免每次下载到不同文件夹被误认为重置。
; 首次启用会自动导入当前脚本文件夹的旧设置（如存在）。任务/进度仍沿用 V3/V4 原文件夹，不做清空。
global CG_PrefDir := A_AppData "\ChatGPT_MultiPDF_AutoSend"
DirCreate(CG_PrefDir)
legacyPrefPath := baseDir "\设置.ini"
global CG_PrefPath := CG_PrefDir "\ChatGPT_设置.ini"
if !FileExist(CG_PrefPath) {
    if FileExist(legacyPrefPath)
        FileCopy(legacyPrefPath, CG_PrefPath)
    else if FileExist(baseDir "\ChatGPT_设置.ini")
        FileCopy(baseDir "\ChatGPT_设置.ini", CG_PrefPath)
}
global CG_StatePath := baseDir "\多PDF进度.ini"
global CG_LogPath := baseDir "\运行日志.txt"
; V4 新增固定话语与每PDF自定义模式，仅在选中模式时启用，原逐题逻辑和旧任务文件保留。
global CG_Mode := "questions"
global CG_SendMsg1 := ""
global CG_OriginalTaskPath := CG_TaskPath
global CG_OriginalStatePath := CG_StatePath
global CG_FixedTaskPath := baseDir "\固定话语任务清单.txt"
global CG_FixedStatePath := baseDir "\固定话语进度.ini"
global CG_CustomTaskPath := baseDir "\自定义话语任务清单.txt"
global CG_CustomStatePath := baseDir "\自定义话语进度.ini"
global CG_ManagerGui := 0
global CG_ManagerList := 0
global CG_EditorOpen := false
global CG_Jobs := []
global CG_Signature := ""
global CG_JobIndex := 1
global CG_QuestionIndex := 1
global CG_Stage := "upload"   ; upload / upload_wait / question / question_wait / pdf_wait / done
global CG_WaitUntil := ""
global CG_Running := false
global CG_Busy := false
global CG_ChatHwnd := 0
global CG_PlusX := IniRead(CG_PrefPath, "coords", "plusX", "")
global CG_PlusY := IniRead(CG_PrefPath, "coords", "plusY", "")
global CG_UploadX := IniRead(CG_PrefPath, "coords", "uploadX", "")
global CG_UploadY := IniRead(CG_PrefPath, "coords", "uploadY", "")
global CG_InputX := IniRead(CG_PrefPath, "coords", "inputX", "")
global CG_InputY := IniRead(CG_PrefPath, "coords", "inputY", "")
; ChatGPT附加PDF后可选单独校准输入框位置；未校准时使用原版普通输入框坐标。
; Ctrl+Alt+4 可为已有消息对话校准带PDF时的输入框。
global CG_AttachedInputX := IniRead(CG_PrefPath, "coords", "attachedInputX", "")
global CG_AttachedInputY := IniRead(CG_PrefPath, "coords", "attachedInputY", "")
global CG_QWait := 30  ; 分钟
global CG_PDFWait := 60 ; 分钟
global CG_UploadWait := 30 ; 秒：PDF消息发送完到首题之间
; V4.4：旧对话坐标不变，新增空白新对话独立坐标；都持久保存在 AppData 的 ChatGPT_设置.ini。
global CG_FreshPlusX := IniRead(CG_PrefPath, "coords", "freshPlusX", "")
global CG_FreshPlusY := IniRead(CG_PrefPath, "coords", "freshPlusY", "")
global CG_FreshUploadX := IniRead(CG_PrefPath, "coords", "freshUploadX", "")
global CG_FreshUploadY := IniRead(CG_PrefPath, "coords", "freshUploadY", "")
global CG_FreshInputX := IniRead(CG_PrefPath, "coords", "freshInputX", "")
global CG_FreshInputY := IniRead(CG_PrefPath, "coords", "freshInputY", "")
global CG_FreshAttachedX := IniRead(CG_PrefPath, "coords", "freshAttachedX", "")
global CG_FreshAttachedY := IniRead(CG_PrefPath, "coords", "freshAttachedY", "")
global CG_NewChatX := IniRead(CG_PrefPath, "coords", "newChatX", "")
global CG_NewChatY := IniRead(CG_PrefPath, "coords", "newChatY", "")
global CG_InFreshComposer := false
; 当前模式进度分别保存这些字段，不会改动V3的原有任务清单字段。
global CG_ChatGroupStartJob := 1
; 需要手动新建对话时，不会发送下一份PDF，直到用户确认后按F8。
global CG_NeedManualNewChat := false


if !FileExist(CG_TaskPath)
    FileAppend("# 每行格式：PDF完整路径|题号，例如：D:\资料\第一讲.pdf|8-10,12,16-18`r`n# 可点脚本窗口里的【添加 PDF 任务】，无须手工写路径。`r`n", CG_TaskPath, "UTF-8")

; V4.3：主窗口缩小为紧凑可调整大小的界面；高级设置独立弹窗。
; 不改动上传、发送、任务、等待、校准和进度的实际处理函数。
global CG_MainGui := Gui("+AlwaysOnTop +Resize +MinSize590x395", "ChatGPT 多PDF自动发送 · V4.4 设置永久保存版")
CG_MainGui.SetFont("s9", "Microsoft YaHei")
CG_MainGui.MarginX := 12
CG_MainGui.MarginY := 10
global CG_CountText := CG_MainGui.AddText("xm w650 h26", "正在载入任务……")
CG_MainGui.AddText("xm y+8", "每条话语间隔(分)：")
global CG_QBox := CG_MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(CG_PrefPath, "timing", "question_minutes", "30"))
CG_MainGui.AddText("x+14 yp+3", "每份PDF间隔(分)：")
global CG_PBox := CG_MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(CG_PrefPath, "timing", "pdf_minutes", "60"))
CG_MainGui.AddText("x+14 yp+3", "上传后等待(秒)：")
global CG_UBox := CG_MainGui.AddEdit("x+5 yp-3 w60 Number", IniRead(CG_PrefPath, "timing", "upload_seconds", "30"))
CG_QBox.OnEvent("Change", CG_SaveTimersOnEdit)
CG_PBox.OnEvent("Change", CG_SaveTimersOnEdit)
CG_UBox.OnEvent("Change", CG_SaveTimersOnEdit)
CG_MainGui.AddText("xm y+12", "首次使用的 ChatGPT 对话：")
global CG_StartProfileBox := CG_MainGui.AddDropDownList("x+7 yp-4 w215", ["已有消息的旧对话", "空白新对话（首发PDF）"])
CG_StartProfileBox.Choose(GM_GeminiSafeInteger(IniRead(CG_PrefPath, "chat", "start_profile", "1"), 1, 1, 2))
CG_StartProfileBox.OnEvent("Change", CG_SaveStartProfile)
global CG_AdvBtn := CG_MainGui.AddButton("x+17 yp-1 w137 h27", "高级设置 / 定位")
CG_AdvBtn.OnEvent("Click", CG_ShowAdvancedSettings)
global CG_SavePrefsBtn := CG_MainGui.AddButton("x+8 yp w105 h27", "保存全部设置")
CG_SavePrefsBtn.OnEvent("Click", (*) => CG_SaveAllSettings(true))
CG_MainGui.AddText("xm y+12", "发送模式：")
global CG_ModeBox := CG_MainGui.AddDropDownList("x+6 yp-4 w565", ["原版：PDF逐题提问", "功能一：所有PDF共用一条固定话语", "功能二：每份PDF自定义1~多条话语"])
CG_ModeBox.Choose(GM_GeminiSafeInteger(IniRead(CG_PrefPath, "messages", "mode_index", "1"), 1, 1, 3))
CG_ModeBox.OnEvent("Change", CG_SwitchMode)
global CG_Msg1Label := CG_MainGui.AddText("xm y+9 w650", "功能一专用：所有PDF共用的固定话语（可修改）：")
global CG_Msg1Box := CG_MainGui.AddEdit("xm y+4 w650", IniRead(CG_PrefPath, "messages", "first", "请帮我整理申论，生成word"))
CG_Msg1Box.OnEvent("Change", CG_SaveMessageSettings)
addBtn := CG_MainGui.AddButton("xm y+11 w142 h29", "添加 PDF 任务")
addBtn.OnEvent("Click", CG_AddPdfJob)
editBtn := CG_MainGui.AddButton("x+7 yp w142 h29", "编辑任务清单")
editBtn.OnEvent("Click", CG_EditJobs)
reloadBtn := CG_MainGui.AddButton("x+7 yp w142 h29", "刷新任务（保留清单）")
reloadBtn.OnEvent("Click", CG_ReloadJobs)
resetBtn := CG_MainGui.AddButton("x+7 yp w142 h29", "重置发送进度")
resetBtn.OnEvent("Click", CG_ResetProgress)
noPdfBtn := CG_MainGui.AddButton("xm y+7 w250 h29", "只发话语（不重新上传PDF）")
noPdfBtn.OnEvent("Click", CG_AddTextOnlyJob)
global CG_NoPdfBtn := noPdfBtn
global CG_CustomManageBtn := CG_MainGui.AddButton("x+8 yp w250 h29", "管理每份PDF的话语")
CG_CustomManageBtn.OnEvent("Click", CG_OpenCustomManager)
CG_MainGui.AddText("xm y+10 w650", "F8 开始/继续　F9 暂停　F10 跳过等待　F12 退出")
global CG_StatusText := CG_MainGui.AddText("xm y+8 w650 h83", "添加PDF任务，校准 ChatGPT 窗口后按 F8。")
CG_MainGui.OnEvent("Size", CG_CompactWindowResized)
CG_MainGui.OnEvent("Close", (*) => CG_MainGui.Hide())

; 以下设置被移入弹出的高级窗口，仍沿用原变量和原保存逻辑。
global CG_AdvancedGui := Gui("+AlwaysOnTop", "ChatGPT · 高级设置与坐标定位")
CG_AdvancedGui.SetFont("s9", "Microsoft YaHei")
CG_AdvancedGui.MarginX := 14
CG_AdvancedGui.MarginY := 13
CG_AdvancedGui.AddText("xm w640", "快捷键校准：把鼠标放到 ChatGPT 目标位置后按组合键，位置自动保存。")
CG_AdvancedGui.AddText("xm y+9 w670", "Ctrl+Alt+0 绑定窗口； 1 附件＋； 2 上传菜单； 3 普通输入框； 4 附件后输入框")
CG_AdvancedGui.AddText("xm y+6 w670", "新对话专用：Ctrl+Alt+5 附件＋； 6 上传菜单； 7 普通输入框； 8 附件后输入框")
CG_AdvancedGui.AddText("xm y+6 w670", "Ctrl+Alt+9：新建聊天按钮（若需自动切换对话，必须先校准）")
global CG_CalText := CG_AdvancedGui.AddText("xm y+12 w665 h56", "正在读取定位状态……")
CG_AdvancedGui.AddText("xm y+12", "每个对话最多处理PDF数量（0 = 不换）：")
global CG_MaxPDFBox := CG_AdvancedGui.AddEdit("x+8 yp-3 w64 Number", IniRead(CG_PrefPath, "chat", "max_pdfs", "0"))
CG_MaxPDFBox.OnEvent("Change", CG_SaveConversationOptions)
global CG_AutoSwitchBox := CG_AdvancedGui.AddCheckBox("xm y+13", "到上限自动点击【新建聊天】（需要 Ctrl+Alt+9 已校准）")
CG_AutoSwitchBox.Value := GM_GeminiSafeInteger(IniRead(CG_PrefPath, "chat", "auto_switch", "0"), 0, 0, 1)
CG_AutoSwitchBox.OnEvent("Click", CG_SaveConversationOptions)
CG_AdvancedGui.AddText("xm y+12 w670", "不勾选时到上限将安全暂停，手动打开新聊天并按 Ctrl+Alt+0、F8 继续。")
CG_AdvancedGui.AddText("xm y+9 w670", "V4.4：设置保存在 Windows AppData，移动或升级脚本也不会重置。")
CG_AdvancedGui.AddText("xm y+5 w670", "设置文件：" CG_PrefPath)
CG_AdvancedGui.AddButton("xm y+12 w125 h28", "保存全部设置").OnEvent("Click", (*) => CG_SaveAllSettings(true))
CG_AdvancedGui.AddButton("x+8 yp w125 h28", "导入旧设置").OnEvent("Click", CG_ImportLegacySettings)
CG_AdvancedGui.AddButton("x+8 yp w125 h28", "打开设置文件夹").OnEvent("Click", CG_OpenPrefsFolder)
CG_AdvancedGui.AddButton("x+8 yp w125 h28", "关闭高级设置").OnEvent("Click", CG_HideAdvancedSettings)
CG_AdvancedGui.OnEvent("Close", CG_HideAdvancedSettings)
CG_MainGui.Hide()

CG_InitSelectedMode()
try CG_ReloadJobs()
catch as e
    CG_SetStatus("载入任务失败：" e.Message)
CG_UpdateCalibration()


; 紧凑窗口支持拖动四角改变大小，正文和状态栏自动随宽度扩展。









; ===== V4：三个独立模式。原版模式仍使用 V3 原始的文件和完整调度。 =====









; 下面的统一保存也会在按 F12 和点窗口 X 时执行；不会清空任务或进度。



; OnExit回调必须返回0，否则返回true会阻止程序退出。



; 手动保存：先检查三个间隔及PDF上限，再写入同一个 AppData 配置文件并读回确认。



; 旧版本的ini往往存放于各个下载文件夹。可选择其中一份导入，当前配置先备份。









; 切到新对话后，只有第一条带附件的PDF消息使用居中的新对话坐标。
; 第一条实际发出以后立即恢复原来已经校准好的旧对话坐标。

























; 任务清单编码，允许文字里包含竖线、百分号、逗号及换行；不会误分割话语。





; 修改功能二任务后只重置功能二的进度，不触碰原版和功能一的进度。



; 功能二不需要编辑代码，在管理窗口中选PDF、编辑/新增/删除话语即可。












































































; 【重新载入任务】按钮：清空当前模式的任务清单并重置当前模式的断点。
; CG_ReloadJobs 保持原样：脚本启动和添加PDF时仍然读取任务，不会误清空。
}

CG_CompactWindowResized(guiObj, minMax, width, height) {
    global CG_CountText, CG_ModeBox, CG_Msg1Label, CG_Msg1Box, CG_StatusText
    if minMax = -1
        return
    contentWidth := Max(555, width - 27)
    try {
        CG_CountText.Move(, , contentWidth)
        CG_ModeBox.Move(, , Max(430, contentWidth - 89))
        CG_Msg1Label.Move(, , contentWidth)
        CG_Msg1Box.Move(, , contentWidth)
        CG_StatusText.GetPos(&sx, &sy, &sw, &sh)
        CG_StatusText.Move(, , contentWidth, Max(58, height - sy - 16))
    }
}

CG_ShowAdvancedSettings(*) {
    global CG_AdvancedGui
    CG_AdvancedGui.Show("w730 h370")
}

CG_HideAdvancedSettings(*) {
    global CG_AdvancedGui
    try CG_SaveConversationOptions()
    CG_AdvancedGui.Hide()
}

CG_SaveTimersOnEdit(*) {
    ; 修改后立即保存，F12和右上角关闭也会再保存一次，避免退出重置。
    global CG_QBox, CG_PBox, CG_UBox, CG_PrefPath
    for t in [["question_minutes", CG_QBox.Value, 1, 120], ["pdf_minutes", CG_PBox.Value, 1, 120], ["upload_seconds", CG_UBox.Value, 15, 3600]] {
        v := Trim(t[2])
        if RegExMatch(v, "^\d+$") && Number(v) >= t[3] && Number(v) <= t[4]
            IniWrite(String(Number(v)), CG_PrefPath, "timing", t[1])
    }
}

CG_SaveConversationOptions(*) {
    global CG_PrefPath, CG_MaxPDFBox, CG_AutoSwitchBox
    n := Trim(CG_MaxPDFBox.Value)
    if RegExMatch(n, "^\d+$") && Number(n) <= 1000
        IniWrite(String(Number(n)), CG_PrefPath, "chat", "max_pdfs")
    IniWrite(String(CG_AutoSwitchBox.Value), CG_PrefPath, "chat", "auto_switch")
}

CG_SaveStartProfile(*) {
    global CG_StartProfileBox, CG_PrefPath, CG_JobIndex, CG_Stage, CG_InFreshComposer, CG_Running
    IniWrite(String(CG_StartProfileBox.Value), CG_PrefPath, "chat", "start_profile")
    ; 仅尚未开始的第一份任务可切换开场界面，防止中途误覆盖现场状态。
    if !CG_Running && CG_JobIndex = 1 && CG_Stage = "upload" {
        CG_InFreshComposer := CG_StartProfileBox.Value = 2
        CG_SaveProgress()
    }
}

CG_SafeExit(*) {
    CG_SaveAllSettings(false)
    ExitApp()
}

CG_OnScriptExit(*) {
    CG_SaveAllSettings(false)
    return 0
}

CG_SaveAllSettings(showNotice := true) {
    global CG_PrefPath, CG_QBox, CG_PBox, CG_UBox, CG_MaxPDFBox, CG_AutoSwitchBox, CG_StartProfileBox, CG_ModeBox, CG_Msg1Box
    global CG_PlusX, CG_PlusY, CG_UploadX, CG_UploadY, CG_InputX, CG_InputY, CG_AttachedInputX, CG_AttachedInputY
    global CG_FreshPlusX, CG_FreshPlusY, CG_FreshUploadX, CG_FreshUploadY, CG_FreshInputX, CG_FreshInputY
    global CG_FreshAttachedX, CG_FreshAttachedY, CG_NewChatX, CG_NewChatY
    try {
        CG_ValidateTimers()
        n := Trim(CG_MaxPDFBox.Value)
        if !RegExMatch(n, "^\d+$") || Number(n) > 1000
            throw Error("每个对话的PDF数量必须是0～1000之间的整数")
        CG_SaveConversationOptions()
        CG_SaveMessageSettings()
        IniWrite(String(CG_StartProfileBox.Value), CG_PrefPath, "chat", "start_profile")
        IniWrite(String(CG_ModeBox.Value), CG_PrefPath, "messages", "mode_index")
        values := Map(
            "plusX", CG_PlusX, "plusY", CG_PlusY, "uploadX", CG_UploadX, "uploadY", CG_UploadY,
            "inputX", CG_InputX, "inputY", CG_InputY,
            "attachedInputX", CG_AttachedInputX, "attachedInputY", CG_AttachedInputY,
            "freshPlusX", CG_FreshPlusX, "freshPlusY", CG_FreshPlusY,
            "freshUploadX", CG_FreshUploadX, "freshUploadY", CG_FreshUploadY,
            "freshInputX", CG_FreshInputX, "freshInputY", CG_FreshInputY,
            "freshAttachedX", CG_FreshAttachedX, "freshAttachedY", CG_FreshAttachedY,
            "newChatX", CG_NewChatX, "newChatY", CG_NewChatY)
        for key, value in values {
            if value != ""
                IniWrite(String(value), CG_PrefPath, "coords", key)
        }
        if IniRead(CG_PrefPath, "timing", "question_minutes", "") != String(Number(Trim(CG_QBox.Value)))
            throw Error("每条话语间隔未能读回，请检查写入权限")
        if IniRead(CG_PrefPath, "timing", "pdf_minutes", "") != String(Number(Trim(CG_PBox.Value)))
            throw Error("每份PDF间隔未能读回，请检查写入权限")
        if IniRead(CG_PrefPath, "timing", "upload_seconds", "") != String(Number(Trim(CG_UBox.Value)))
            throw Error("上传后等待时间未能读回，请检查写入权限")
        if IniRead(CG_PrefPath, "chat", "max_pdfs", "") != String(Number(n))
            throw Error("每个对话PDF数量未能读回，请检查写入权限")
        for key, value in values {
            if value != "" && IniRead(CG_PrefPath, "coords", key, "") != String(value)
                throw Error("定位设置 " key " 未能读回，请检查写入权限")
        }
        if showNotice
            MsgBox("已保存并核对成功！`n`n间隔：" CG_QBox.Value " 分钟 / " CG_PBox.Value " 分钟 / " CG_UBox.Value " 秒"
                . "`n每对话上限：" n " 份PDF`n`n坐标：所有已校准的位置`n`n设置文件：`n" CG_PrefPath,
                "设置保存成功", "Iconi")
        return true
    } catch as e {
        if showNotice
            MsgBox("保存未完成：" e.Message "`n请不要退出，先检查填写和目录权限。`n" CG_PrefPath, "保存失败", "Iconx")
        return false
    }
}

CG_ImportLegacySettings(*) {
    global CG_PrefPath, CG_Running, CG_Busy, CG_QBox, CG_PBox, CG_UBox, CG_MaxPDFBox, CG_AutoSwitchBox
    global CG_StartProfileBox, CG_Msg1Box, CG_ModeBox, CG_PrefDir
    global CG_PlusX, CG_PlusY, CG_UploadX, CG_UploadY, CG_InputX, CG_InputY, CG_AttachedInputX, CG_AttachedInputY
    global CG_FreshPlusX, CG_FreshPlusY, CG_FreshUploadX, CG_FreshUploadY, CG_FreshInputX, CG_FreshInputY
    global CG_FreshAttachedX, CG_FreshAttachedY, CG_NewChatX, CG_NewChatY
    if CG_Running || CG_Busy {
        MsgBox("请先按 F9 暂停任务，再导入旧设置。")
        return
    }
    selected := FileSelect(1, A_ScriptDir, "选择旧版 ChatGPT_设置.ini", "INI 设置文件 (*.ini)")
    if selected = ""
        return
    if StrLower(selected) = StrLower(CG_PrefPath) {
        MsgBox("你选的就是当前设置文件，不需要重复导入。")
        return
    }
    if MsgBox("将读取所选旧设置，替换当前的间隔、定位坐标和模式设置。`n当前设置会先自动备份；PDF任务和发送进度不删除。`n`n继续？", "确认导入", "YesNo Icon?") != "Yes"
        return
    try {
        if FileExist(CG_PrefPath)
            FileCopy(CG_PrefPath, CG_PrefDir "\ChatGPT_设置_导入前备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") ".ini")
        FileCopy(selected, CG_PrefPath, true)
        CG_QBox.Value := IniRead(CG_PrefPath, "timing", "question_minutes", "30")
        CG_PBox.Value := IniRead(CG_PrefPath, "timing", "pdf_minutes", "60")
        CG_UBox.Value := IniRead(CG_PrefPath, "timing", "upload_seconds", "30")
        CG_MaxPDFBox.Value := IniRead(CG_PrefPath, "chat", "max_pdfs", "0")
        CG_AutoSwitchBox.Value := GM_GeminiSafeInteger(IniRead(CG_PrefPath, "chat", "auto_switch", "0"), 0, 0, 1)
        CG_StartProfileBox.Choose(GM_GeminiSafeInteger(IniRead(CG_PrefPath, "chat", "start_profile", "1"), 1, 1, 2))
        CG_Msg1Box.Value := IniRead(CG_PrefPath, "messages", "first", "请帮我整理申论，生成word")
        CG_ModeBox.Choose(GM_GeminiSafeInteger(IniRead(CG_PrefPath, "messages", "mode_index", "1"), 1, 1, 3))
        ; 发送模式的实际任务列表保持不动；重新打开脚本时才切到导入的模式。
        CG_PlusX := IniRead(CG_PrefPath, "coords", "plusX", "")
        CG_PlusY := IniRead(CG_PrefPath, "coords", "plusY", "")
        CG_UploadX := IniRead(CG_PrefPath, "coords", "uploadX", "")
        CG_UploadY := IniRead(CG_PrefPath, "coords", "uploadY", "")
        CG_InputX := IniRead(CG_PrefPath, "coords", "inputX", "")
        CG_InputY := IniRead(CG_PrefPath, "coords", "inputY", "")
        CG_AttachedInputX := IniRead(CG_PrefPath, "coords", "attachedInputX", "")
        CG_AttachedInputY := IniRead(CG_PrefPath, "coords", "attachedInputY", "")
        CG_FreshPlusX := IniRead(CG_PrefPath, "coords", "freshPlusX", "")
        CG_FreshPlusY := IniRead(CG_PrefPath, "coords", "freshPlusY", "")
        CG_FreshUploadX := IniRead(CG_PrefPath, "coords", "freshUploadX", "")
        CG_FreshUploadY := IniRead(CG_PrefPath, "coords", "freshUploadY", "")
        CG_FreshInputX := IniRead(CG_PrefPath, "coords", "freshInputX", "")
        CG_FreshInputY := IniRead(CG_PrefPath, "coords", "freshInputY", "")
        CG_FreshAttachedX := IniRead(CG_PrefPath, "coords", "freshAttachedX", "")
        CG_FreshAttachedY := IniRead(CG_PrefPath, "coords", "freshAttachedY", "")
        CG_NewChatX := IniRead(CG_PrefPath, "coords", "newChatX", "")
        CG_NewChatY := IniRead(CG_PrefPath, "coords", "newChatY", "")
        CG_UpdateCalibration()
        ; 导入的发送模式下次重启会恢复，这里不强制切换正在编辑的任务模式。
        if CG_SaveAllSettings(false)
            MsgBox("导入成功！已加载旧设置并保存到固定位置。`n`n旧设置内的发送模式将在下次启动时恢复。`n" CG_PrefPath, "导入完成", "Iconi")
        else
            MsgBox("已读入旧INI，但有字段无效。请检查三个间隔及PDF上限，并点击【保存全部设置】。", "需要检查")
    } catch as e {
        MsgBox("导入失败：" e.Message, "错误", "Iconx")
    }
}

CG_OpenPrefsFolder(*) {
    global CG_PrefDir
    Run(CG_PrefDir)
}

CG_CalibrateFresh(which) {
    global CG_PrefPath, CG_FreshPlusX, CG_FreshPlusY, CG_FreshUploadX, CG_FreshUploadY
    global CG_FreshInputX, CG_FreshInputY, CG_FreshAttachedX, CG_FreshAttachedY, CG_NewChatX, CG_NewChatY
    h := CG_GetChat()
    if !h {
        MsgBox("请先切换到ChatGPT窗口并按 Ctrl+Alt+0 绑定后再校准。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx-wx, ry := my-wy
    if which = "plus" {
        CG_FreshPlusX := rx, CG_FreshPlusY := ry
        key := "freshPlus", label := "新对话附件＋"
    } else if which = "upload" {
        CG_FreshUploadX := rx, CG_FreshUploadY := ry
        key := "freshUpload", label := "新对话上传菜单"
    } else if which = "input" {
        CG_FreshInputX := rx, CG_FreshInputY := ry
        key := "freshInput", label := "新对话普通输入框"
    } else if which = "attached_input" {
        CG_FreshAttachedX := rx, CG_FreshAttachedY := ry
        key := "freshAttached", label := "新对话带PDF的输入框"
    } else {
        CG_NewChatX := rx, CG_NewChatY := ry
        key := "newChat", label := "新建聊天按钮"
    }
    IniWrite(String(rx), CG_PrefPath, "coords", key "X")
    IniWrite(String(ry), CG_PrefPath, "coords", key "Y")
    CG_UpdateCalibration()
    ToolTip("已保存：" label "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -2200)
}

CG_ModeIndex() {
    global CG_Mode
    return CG_Mode = "single" ? 2 : (CG_Mode = "custom" ? 3 : 1)
}

CG_TaskTemplate() {
    global CG_Mode
    if CG_Mode = "questions"
        return "# 每行：PDF完整路径|题号，如 D:\第一讲.pdf|8-10,12`r`n"
    if CG_Mode = "single"
        return "# 每行一个PDF完整路径；或 @NO_PDF 代表在当前对话直接发一次固定话语。`r`n"
    return "# V4自定义任务文件：建议用窗口【管理每份PDF的话语】编辑，保存时会自动转义特殊字符。`r`n# 每行一份PDF路径与一条或多条话语，字段由 | 分隔。`r`n"
}

CG_InitSelectedMode() {
    global CG_ModeBox
    CG_SelectMode(CG_ModeBox.Value, false)
}

CG_SelectMode(idx, reload := true) {
    global CG_Mode, CG_TaskPath, CG_StatePath, CG_OriginalTaskPath, CG_OriginalStatePath, CG_CustomTaskPath, CG_CustomStatePath
    global CG_FixedTaskPath, CG_FixedStatePath, CG_PrefPath, CG_NoPdfBtn, CG_CustomManageBtn, CG_Msg1Label, CG_Msg1Box
    idx := idx = 2 ? 2 : (idx = 3 ? 3 : 1)
    CG_Mode := idx = 1 ? "questions" : (idx = 2 ? "single" : "custom")
    CG_TaskPath := idx = 1 ? CG_OriginalTaskPath : (idx = 2 ? CG_FixedTaskPath : CG_CustomTaskPath)
    CG_StatePath := idx = 1 ? CG_OriginalStatePath : (idx = 2 ? CG_FixedStatePath : CG_CustomStatePath)
    if !FileExist(CG_TaskPath)
        FileAppend(CG_TaskTemplate(), CG_TaskPath, "UTF-8")
    CG_NoPdfBtn.Enabled := idx != 1
    CG_CustomManageBtn.Enabled := idx = 3
    CG_Msg1Box.Enabled := idx = 2
    CG_Msg1Label.Text := idx = 3 ? "功能二：请点【管理每份PDF的话语】，每份单独编辑（每行发送一次）" : "功能一专用：所有PDF共用一条固定话语（可修改）："
    IniWrite(String(idx), CG_PrefPath, "messages", "mode_index")
    if reload
        CG_ReloadJobs()
}

CG_SwitchMode(*) {
    global CG_Running, CG_Busy, CG_ModeBox, CG_EditorOpen, CG_ManagerGui
    if CG_Running || CG_Busy || CG_EditorOpen || IsObject(CG_ManagerGui) {
        MsgBox("请先暂停并关闭自定义任务管理/编辑窗口，再切换模式。", "暂时不能切换")
        CG_ModeBox.Choose(CG_ModeIndex())
        return
    }
    try CG_SelectMode(CG_ModeBox.Value)
    catch as e {
        MsgBox("切换模式失败：" e.Message, "错误")
        CG_ModeBox.Choose(CG_ModeIndex())
    }
}

CG_SaveMessageSettings(*) {
    global CG_Msg1Box, CG_PrefPath
    IniWrite(Trim(CG_Msg1Box.Value), CG_PrefPath, "messages", "first")
}

CG_AddTextOnlyJob(*) {
    global CG_TaskPath, CG_Running, CG_Busy, CG_Mode, CG_Jobs, CG_EditorOpen, CG_Msg1Box
    if CG_Mode = "questions" {
        MsgBox("原版逐题模式不支持纯文字任务，请选择固定或自定义话语模式。")
        return
    }
    if CG_Running || CG_Busy || CG_EditorOpen {
        MsgBox("请先暂停并关闭话语编辑窗口，再添加任务。")
        return
    }
    if CG_Mode = "custom" {
        CG_Jobs.Push({path: "", name: "当前对话（不上传PDF）", qs: [1], msgs: [CG_DefaultCustomMessage()]})
        try {
            CG_SaveCustomJobs()
            CG_OpenCustomManager()
        } catch as e
            MsgBox("添加失败：" e.Message)
    } else {
        FileAppend("@NO_PDF`r`n", CG_TaskPath, "UTF-8")
        CG_ReloadJobs()
    }
}

CG_DefaultCustomMessage() {
    global CG_PrefPath
    return IniRead(CG_PrefPath, "custom", "default_message", "请帮我整理申论，生成Word")
}

CG_EscapeCustomField(s) {
    s := StrReplace(s, "%", "%25")
    s := StrReplace(s, "|", "%7C")
    s := StrReplace(s, "`r", "%0D")
    return StrReplace(s, "`n", "%0A")
}

CG_UnescapeCustomField(s) {
    s := StrReplace(s, "%0A", "`n")
    s := StrReplace(s, "%0D", "`r")
    s := StrReplace(s, "%7C", "|")
    return StrReplace(s, "%25", "%")
}

CG_SaveCustomJobs() {
    global CG_Mode, CG_Jobs, CG_TaskPath, CG_Running, CG_Busy
    if CG_Mode != "custom" || CG_Running || CG_Busy
        throw Error("只能在已暂停的自定义话语模式下修改")
    content := CG_TaskTemplate()
    for job in CG_Jobs {
        if job.msgs.Length < 1
            throw Error("PDF：" job.name " 至少要设置一条话语")
        line := CG_EscapeCustomField(job.path = "" ? "@NO_PDF" : job.path)
        for m in job.msgs {
            if Trim(m) = ""
                throw Error("PDF：" job.name " 有空白话语")
            line .= "|" CG_EscapeCustomField(m)
        }
        content .= line "`r`n"
    }
    temp := CG_TaskPath ".new"
    if FileExist(temp)
        FileDelete(temp)
    FileAppend(content, temp, "UTF-8")
    FileMove(temp, CG_TaskPath, 1)
    CG_ResetState(CG_ManifestId(content))
    CG_ReloadJobs()
    CG_RefreshCustomManager()
}

CG_OpenCustomManager(*) {
    global CG_Mode, CG_ManagerGui, CG_ManagerList, CG_MainGui, CG_Running, CG_Busy
    if CG_Mode != "custom" {
        MsgBox("请先切换到【功能二：每份PDF自定义话语】。")
        return
    }
    if IsObject(CG_ManagerGui) {
        try WinActivate("ahk_id " CG_ManagerGui.Hwnd)
        return
    }
    mgr := Gui("+AlwaysOnTop", "功能二 · 每份PDF分别设置发送次数及话语")
    mgr.SetFont("s10", "Microsoft YaHei")
    mgr.AddText("xm w855", "每份PDF可设置1句、2句、3句或更多；一行话语=一次发送。当前顺序就是自动发送顺序。")
    CG_ManagerList := mgr.AddListView("xm y+8 w855 r12 Grid -Multi", ["序号", "PDF", "话语数", "首句话预览"])
    CG_ManagerList.ModifyCol(1, 48)
    CG_ManagerList.ModifyCol(2, 295)
    CG_ManagerList.ModifyCol(3, 75)
    CG_ManagerList.ModifyCol(4, 425)
    CG_ManagerList.OnEvent("DoubleClick", CG_EditCustomJob)
    add := mgr.AddButton("xm y+12 w118", "添加PDF")
    add.OnEvent("Click", CG_AddPdfJob)
    edit := mgr.AddButton("x+6 yp w128", "编辑这份话语")
    edit.OnEvent("Click", CG_EditCustomJob)
    del := mgr.AddButton("x+6 yp w105", "删除这份PDF")
    del.OnEvent("Click", CG_DeleteCustomJob)
    up := mgr.AddButton("x+6 yp w100", "向上移动")
    up.OnEvent("Click", (*) => CG_MoveCustomJob(-1))
    down := mgr.AddButton("x+6 yp w100", "向下移动")
    down.OnEvent("Click", (*) => CG_MoveCustomJob(1))
    mgr.AddText("xm y+12 w855", "提示：编辑时每一行是一条完整的话语。保存后自动存盘，下次打开仍在；修改任务会重置功能二发送进度。")
    mgr.OnEvent("Close", CG_CloseCustomManager)
    CG_ManagerGui := mgr
    CG_RefreshCustomManager()
    mgr.Show("w880 h430")
}

CG_CloseCustomManager(*) {
    global CG_ManagerGui, CG_ManagerList, CG_EditorOpen
    if CG_EditorOpen {
        MsgBox("请先保存或取消正在编辑的话语。")
        return
    }
    if IsObject(CG_ManagerGui)
        CG_ManagerGui.Destroy()
    CG_ManagerGui := 0
    CG_ManagerList := 0
}

CG_RefreshCustomManager() {
    global CG_Mode, CG_Jobs, CG_ManagerGui, CG_ManagerList
    if CG_Mode != "custom" || !IsObject(CG_ManagerGui)
        return
    CG_ManagerList.Delete()
    for i, job in CG_Jobs {
        preview := job.msgs.Length ? StrReplace(job.msgs[1], "`n", " ") : ""
        CG_ManagerList.Add("", i, job.name, job.msgs.Length, SubStr(preview, 1, 75))
    }
}

CG_SelectedCustomRow() {
    global CG_ManagerGui, CG_ManagerList, CG_Jobs
    if !IsObject(CG_ManagerGui)
        return 0
    row := CG_ManagerList.GetNext()
    if row < 1 || row > CG_Jobs.Length {
        MsgBox("请先在列表里选中一份PDF。")
        return 0
    }
    return row
}

CG_JoinCustomMessages(msgs) {
    result := ""
    for m in msgs
        result .= (A_Index = 1 ? "" : "`r`n") m
    return result
}

CG_EditCustomJob(*) {
    global CG_Mode, CG_Jobs, CG_EditorOpen, CG_ManagerGui
    if CG_Mode != "custom" || CG_EditorOpen
        return
    row := CG_SelectedCustomRow()
    if !row
        return
    CG_EditorOpen := true
    ed := Gui("+AlwaysOnTop", "编辑第" row "份PDF的话语：" CG_Jobs[row].name)
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w795", "一行 = 发送一次。只写一行就只发一次；增加到两行就发两次。按从上到下的顺序发送。")
    field := ed.AddEdit("xm y+8 w795 r12 VScroll", CG_JoinCustomMessages(CG_Jobs[row].msgs))
    more := ed.AddButton("xm y+12 w140", "再添加一句")
    more.OnEvent("Click", (*) => CG_AppendBlankMessage(field))
    save := ed.AddButton("x+9 yp w135 Default", "保存这份话语")
    save.OnEvent("Click", (*) => CG_SaveCustomEditor(row, field.Value, ed))
    cancel := ed.AddButton("x+9 yp w110", "取消")
    cancel.OnEvent("Click", (*) => CG_CloseCustomEditor(ed))
    ed.OnEvent("Close", (*) => CG_CloseCustomEditor(ed))
    ed.Show("w825 h390")
}

CG_AppendBlankMessage(field) {
    field.Value .= "`r`n"
    field.Focus()
    Send("^{End}")
}

CG_CloseCustomEditor(editor) {
    global CG_EditorOpen
    CG_EditorOpen := false
    try editor.Destroy()
}

CG_SaveCustomEditor(row, value, editor) {
    global CG_Jobs, CG_Running, CG_Busy
    if CG_Running || CG_Busy {
        MsgBox("正在发送，不能修改。请先F9暂停。")
        return
    }
    msgs := []
    for line in StrSplit(StrReplace(value, "`r", ""), "`n") {
        line := Trim(line, " `t`r`n")
        if line != ""
            msgs.Push(line)
    }
    if msgs.Length < 1 {
        MsgBox("至少保留一句话；不需要的整份PDF请在列表中删除。")
        return
    }
    if MsgBox("保存这份PDF的" msgs.Length "句话？`n修改后功能二发送进度会从头开始，其他模式不受影响。", "确认保存", "YesNo Icon?") != "Yes"
        return
    old := CG_Jobs[row].msgs
    CG_Jobs[row].msgs := msgs
    try {
        CG_SaveCustomJobs()
        CG_CloseCustomEditor(editor)
        MsgBox("已保存：本份PDF发送" msgs.Length "次。")
    } catch as e {
        CG_Jobs[row].msgs := old
        MsgBox("保存失败：" e.Message)
    }
}

CG_DeleteCustomJob(*) {
    global CG_Jobs, CG_Running, CG_Busy
    row := CG_SelectedCustomRow()
    if !row || CG_Running || CG_Busy
        return
    if MsgBox("确定删除第" row "份PDF任务？`n只删除任务记录，不会删除PDF文件。功能二进度将重置。", "删除任务", "YesNo Icon!") != "Yes"
        return
    old := CG_Jobs.RemoveAt(row)
    try CG_SaveCustomJobs()
    catch as e {
        CG_Jobs.InsertAt(row, old)
        MsgBox("删除失败：" e.Message)
    }
}

CG_MoveCustomJob(dir) {
    global CG_Jobs, CG_Running, CG_Busy, CG_ManagerList
    row := CG_SelectedCustomRow()
    if !row || CG_Running || CG_Busy
        return
    dest := row + dir
    if dest < 1 || dest > CG_Jobs.Length
        return
    temp := CG_Jobs[row]
    CG_Jobs[row] := CG_Jobs[dest]
    CG_Jobs[dest] := temp
    try {
        CG_SaveCustomJobs()
        CG_ManagerList.Modify(dest, "Select Focus Vis")
    } catch as e {
        CG_Jobs[dest] := CG_Jobs[row]
        CG_Jobs[row] := temp
        MsgBox("移动失败：" e.Message)
    }
}

CG_GetChat() {
    global CG_ChatHwnd, CG_MainGui, CG_AdvancedGui
    if (CG_ChatHwnd && WinExist("ahk_id " CG_ChatHwnd))
        return CG_ChatHwnd
    ; 优先识别原ChatGPT V4已正常使用的独立桌面程序。
    try {
        h := WinExist("ahk_exe ChatGPT.exe")
        if h
            return h
    }
    try {
        h := WinGetID("A")
        if CG_IsChatGPTWindow(h)
            return h
    }
    for h in WinGetList() {
        if CG_IsChatGPTWindow(h)
            return h
    }
    return 0
}

CG_IsChatGPTWindow(h) {
    global CG_MainGui, CG_AdvancedGui
    if !h || h = CG_MainGui.Hwnd || h = CG_AdvancedGui.Hwnd
        return false
    try {
        title := StrLower(WinGetTitle("ahk_id " h))
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "explorer.exe" || InStr(exe, "autohotkey") || InStr(title, "gemini"))
            return false
        if (exe = "chatgpt.exe")
            return true
        return InStr(title, "chatgpt") > 0
    }
    return false
}

CG_BindChatGPTWindow(*) {
    global CG_ChatHwnd, CG_MainGui, CG_AdvancedGui
    try {
        h := WinGetID("A")
        if !h || h = CG_MainGui.Hwnd || h = CG_AdvancedGui.Hwnd {
            MsgBox("先切换到 ChatGPT 桌面应用窗口，再按 Ctrl+Alt+0。", "窗口未绑定")
            return
        }
        title := WinGetTitle("ahk_id " h)
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "explorer.exe" || InStr(exe, "autohotkey") || InStr(StrLower(title), "gemini")) {
            MsgBox("当前窗口看起来不是 ChatGPT，请切换到 ChatGPT 再试。", "绑定失败")
            return
        }
        if !CG_IsChatGPTWindow(h) {
            if MsgBox("当前窗口标题和程序名未明显显示 ChatGPT：`n" title "`n确定要绑定这个窗口吗？", "确认绑定", "YesNo Icon?") != "Yes"
                return
        }
        CG_ChatHwnd := h
        ToolTip("已绑定 ChatGPT 窗口；可以校准附件＋、上传菜单与输入框")
        SetTimer(() => ToolTip(), -2300)
        CG_UpdateCalibration()
    } catch as e {
        MsgBox("绑定失败：" e.Message)
    }
}

CG_ActivateChat() {
    global CG_ChatHwnd
    h := CG_GetChat()
    if !h
        throw Error("找不到 ChatGPT 窗口；打开 ChatGPT 应用，切入目标对话并按 Ctrl+Alt+0 绑定")
    CG_ChatHwnd := h
    WinActivate("ahk_id " h)
    if !WinWaitActive("ahk_id " h, , 5)
        throw Error("无法激活 ChatGPT 窗口")
    return h
}

CG_Calibrate(which) {
    global CG_PlusX, CG_PlusY, CG_UploadX, CG_UploadY, CG_InputX, CG_InputY, CG_AttachedInputX, CG_AttachedInputY, CG_PrefPath
    h := CG_GetChat()
    if !h {
        MsgBox("先打开 ChatGPT 桌面端，并按 Ctrl+Alt+0 绑定窗口，再将鼠标悬停在要校准的位置。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx - wx
    ry := my - wy
    if (which = "plus") {
        CG_PlusX := rx, CG_PlusY := ry
        IniWrite(rx, CG_PrefPath, "coords", "plusX")
        IniWrite(ry, CG_PrefPath, "coords", "plusY")
        title := "附件＋号"
    } else if (which = "upload") {
        CG_UploadX := rx, CG_UploadY := ry
        IniWrite(rx, CG_PrefPath, "coords", "uploadX")
        IniWrite(ry, CG_PrefPath, "coords", "uploadY")
        title := "上传文件菜单"
    } else if (which = "attached_input") {
        CG_AttachedInputX := rx, CG_AttachedInputY := ry
        IniWrite(rx, CG_PrefPath, "coords", "attachedInputX")
        IniWrite(ry, CG_PrefPath, "coords", "attachedInputY")
        title := "PDF已附加时的输入框"
    } else {
        CG_InputX := rx, CG_InputY := ry
        IniWrite(rx, CG_PrefPath, "coords", "inputX")
        IniWrite(ry, CG_PrefPath, "coords", "inputY")
        title := "普通聊天输入框"
    }
    CG_UpdateCalibration()
    ToolTip("已保存：" title "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -1800)
}

CG_UpdateCalibration() {
    global CG_CalText, CG_PlusX, CG_UploadX, CG_InputX, CG_AttachedInputX, CG_FreshPlusX, CG_FreshUploadX, CG_FreshInputX, CG_NewChatX
    CG_CalText.Text := "定位状态：附件＋ " (CG_PlusX = "" ? "未设" : "✓")
        . "   上传菜单 " (CG_UploadX = "" ? "未设" : "✓")
        . "   普通输入框 " (CG_InputX = "" ? "未设" : "✓")
        . "   附件输入框 " (CG_AttachedInputX = "" ? "沿用普通" : "✓")
        . "`n新对话：附件＋ " (CG_FreshPlusX = "" ? "待校准5" : "✓")
        . "  上传菜单 " (CG_FreshUploadX = "" ? "待校准6" : "✓")
        . "  输入框 " (CG_FreshInputX = "" ? "待校准7" : "✓")
        . "  自动新建 " (CG_NewChatX = "" ? "未校准9" : "✓")
}

CG_ClickChat(which) {
    global CG_InFreshComposer
    global CG_PlusX, CG_PlusY, CG_UploadX, CG_UploadY, CG_InputX, CG_InputY, CG_AttachedInputX, CG_AttachedInputY
    global CG_FreshPlusX, CG_FreshPlusY, CG_FreshUploadX, CG_FreshUploadY, CG_FreshInputX, CG_FreshInputY, CG_FreshAttachedX, CG_FreshAttachedY
    global CG_NewChatX, CG_NewChatY
    h := CG_ActivateChat()
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    if which = "new_chat" {
        rx := CG_NewChatX, ry := CG_NewChatY
    } else if CG_InFreshComposer {
        if which = "plus"
            rx := CG_FreshPlusX, ry := CG_FreshPlusY
        else if which = "upload"
            rx := CG_FreshUploadX, ry := CG_FreshUploadY
        else if which = "attached_input" {
            ; 附加PDF的输入框如未单独校准，则沿用新对话普通输入框坐标。
            rx := CG_FreshAttachedX != "" ? CG_FreshAttachedX : CG_FreshInputX
            ry := CG_FreshAttachedY != "" ? CG_FreshAttachedY : CG_FreshInputY
        } else
            rx := CG_FreshInputX, ry := CG_FreshInputY
    } else {
        if which = "plus"
            rx := CG_PlusX, ry := CG_PlusY
        else if which = "upload"
            rx := CG_UploadX, ry := CG_UploadY
        else if which = "attached_input" {
            rx := CG_AttachedInputX != "" ? CG_AttachedInputX : CG_InputX
            ry := CG_AttachedInputY != "" ? CG_AttachedInputY : CG_InputY
        } else
            rx := CG_InputX, ry := CG_InputY
    }
    if rx = "" || ry = ""
        throw Error("当前" (CG_InFreshComposer ? "空白新对话" : "旧对话") "尚未校准：" which "。请使用高级设置中的对应快捷键校准。")
    Click(wx+Number(rx), wy+Number(ry))
}

CG_PutClipboard(text) {
    old := ClipboardAll()
    try {
        A_Clipboard := ""
        A_Clipboard := text
        if !ClipWait(3)
            throw Error("写入剪贴板失败")
        Send("^v")
        Sleep(550)
    } finally {
        A_Clipboard := old
    }
}

CG_SendChatText(message, withAttachment := false) {
    global CG_ChatHwnd
    CG_ClickChat(withAttachment ? "attached_input" : "input")
    Sleep(350)
    MergedRequireFocus("chatgpt", CG_ChatHwnd)
    CG_PutClipboard(message)
    Sleep(400)
    MergedBeforeSend("chatgpt", CG_ChatHwnd)
    SendEvent("{Enter}")
    throw Error("已按Enter，待核实页面是否出现消息；请用主窗口核实按钮继续")
}

CG_AttachPDF(path) {
    global CG_Running, CG_Stage
    if !FileExist(path)
        throw Error("PDF 文件不存在：" path)
    CG_ClickChat("plus")
    Sleep(850)
    CG_ClickChat("upload")
    dialog := WinWaitActive("ahk_class #32770", , 14)
    if !dialog
        throw Error("没弹出文件选择框：请重新校准‘上传文件’菜单的位置")
    target := "ahk_id " dialog
    try {
        ControlFocus("Edit1", target)
        ControlSetText(path, "Edit1", target)
        ControlSend("{Enter}", "Edit1", target)
    } catch {
        ; 兼容部分 Windows 11 文件窗口：Alt+N 通常定位到“文件名”。
        Send("!n")
        Sleep(200)
        Send("^a")
        CG_PutClipboard(path)
        Send("{Enter}")
    }
    if !WinWaitClose(target, , 16)
        throw Error("文件选择窗口未关闭，PDF可能未选择成功")
    ; 文件可见与上传完成的判断不是官方接口，只能留足上传准备时间。
    CG_Stage := "upload_ready"
    CG_SaveProgress()
    Sleep(12000)
}

CG_ToChinese(n) {
    chars := ["零","一","二","三","四","五","六","七","八","九"]
    if (n < 10)
        return chars[n+1]
    if (n < 20)
        return "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 100)
        return chars[Floor(n/10)+1] "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 1000) {
        r := Mod(n, 100)
        return chars[Floor(n/100)+1] "百" (r = 0 ? "" : (r < 10 ? "零" chars[r+1] : CG_ToChinese(r)))
    }
    return String(n)
}

CG_ParseQuestions(spec, lineNo) {
    result := []
    seen := Map()
    for item in StrSplit(StrReplace(spec, "，", ","), ",") {
        item := Trim(item)
        if item = ""
            continue
        item := StrReplace(StrReplace(item, "—", "-"), "–", "-")
        if RegExMatch(item, "^\d+$") {
            n := Number(item)
            if (n < 1 || n > 9999)
                throw Error("第" lineNo "行题号超出范围")
            if !seen.Has(n) {
                result.Push(n)
                seen[n] := true
            }
        } else if RegExMatch(item, "^\d+\s*-\s*\d+$") {
            segments := StrSplit(item, "-")
            a := Number(Trim(segments[1]))
            b := Number(Trim(segments[2]))
            if (a < 1 || a > b || b > 9999 || b-a > 500)
                throw Error("第" lineNo "行题号范围无效或过大：" item)
            Loop b-a+1 {
                n := a+A_Index-1
                if !seen.Has(n) {
                    result.Push(n)
                    seen[n] := true
                }
            }
        } else
            throw Error("第" lineNo "行的题号格式错误：" item)
    }
    if !result.Length
        throw Error("第" lineNo "行没有有效题号")
    return result
}

CG_ManifestId(src) {
    ; 用于防止任务清单变更后误用旧进度。轻量非安全哈希。
    h := 2166136261
    Loop Parse src {
        h := Mod(((h ^ Ord(A_LoopField)) * 16777619), 4294967296)
    }
    return Format("{:08X}", h)
}

CG_ReloadJobs(*) {
    global CG_Busy
    if CG_Busy
        return
    global CG_Jobs, CG_TaskPath, CG_Signature, CG_Running, CG_CountText, CG_Mode
    if CG_Running {
        MsgBox("请先按 F9 暂停，再重新载入任务。")
        return
    }
    raw := FileRead(CG_TaskPath, "UTF-8")
    freshJobs := []
    lineNo := 0
    for line in StrSplit(raw, "`n") {
        lineNo++
        line := Trim(line, " `t`r`n")
        if (line = "" || SubStr(line, 1, 1) = "#")
            continue
        msgs := []
        if CG_Mode = "questions" {
            parts := StrSplit(line, "|")
            if (parts.Length != 2)
                throw Error("任务清单第" lineNo "行须用 | 分隔PDF路径和题号")
            path := Trim(parts[1], " `t`r`n" Chr(34))
            if !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            qs := CG_ParseQuestions(Trim(parts[2]), lineNo)
            SplitPath(path, &name)
        } else if CG_Mode = "custom" {
            parts := StrSplit(line, "|")
            if parts.Length < 2
                throw Error("自定义任务第" lineNo "行缺少话语。请用【管理每份PDF的话语】编辑。")
            path := CG_UnescapeCustomField(parts[1])
            if path = "@NO_PDF"
                path := ""
            if path != "" && !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            name := "当前对话（无需上传PDF）"
            if path != ""
                SplitPath(path, &name)
            Loop parts.Length - 1 {
                message := CG_UnescapeCustomField(parts[A_Index + 1])
                if Trim(message) = ""
                    throw Error("自定义任务第" lineNo "行有空话语")
                msgs.Push(message)
            }
            qs := []
            Loop msgs.Length
                qs.Push(A_Index)
        } else {
            ; 功能一：固定话语，每份PDF只发送同一句。
            if line = "@NO_PDF" {
                path := ""
                name := "当前对话（无需上传PDF）"
            } else {
                path := Trim(line, " `t`r`n" Chr(34))
                if !FileExist(path)
                    throw Error("找不到第" lineNo "行的PDF：" path)
                SplitPath(path, &name)
            }
            qs := [1]
        }
        freshJobs.Push({path: path, name: name, qs: qs, msgs: msgs})
    }
    newSignature := CG_ManifestId(raw)
    oldSignature := IniRead(CG_StatePath, "progress", "task_id", "")
    if (oldSignature != "" && newSignature != oldSignature) {
        answer := MsgBox("检测到PDF任务清单已改变。是否从新清单的第1份PDF重新开始？`n选择‘否’会取消载入。", "任务清单改变", "YesNo Icon!")
        if answer != "Yes"
            return
        CG_ResetState(newSignature)
    }
    CG_Jobs := freshJobs
    CG_Signature := newSignature
    CG_RestoreProgress()
    total := 0
    for job in CG_Jobs
        total += job.qs.Length
    CG_CountText.Text := "已载入：" CG_Jobs.Length " 份任务，共 " total " 条" (CG_Mode = "questions" ? "逐题提问" : "话语") "。当前模式：" (CG_Mode = "custom" ? "每PDF自定义" : CG_Mode = "single" ? "固定话语" : "原版逐题")
    CG_ShowProgress()
    if CG_Mode = "custom"
        CG_RefreshCustomManager()
}

CG_ClearTaskList(*) {
    global CG_TaskPath, CG_Running, CG_Busy
    if (CG_Running || CG_Busy) {
        MsgBox("先按 F9 暂停，等当前上传或发送结束后再清空任务。", "任务正在运行")
        return
    }
    try {
        ; 保留一份旧清单备份，以免误点后无法找回任务路径。
        oldContent := FileRead(CG_TaskPath, "UTF-8")
        backup := ""
        if RegExMatch(oldContent, "m)^\s*[^#\s].*$") {
            backup := A_ScriptDir "\ChatGPT_PDF任务清单_备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") "_" A_TickCount ".txt"
            FileCopy(CG_TaskPath, backup)
        }
        ; 只保留格式说明。原PDF文件、计时与校准设置不会被删除。
        starter := CG_TaskTemplate()
        temp := CG_TaskPath ".new"
        if FileExist(temp)
            FileDelete(temp)
        FileAppend(starter, temp, "UTF-8")
        FileMove(temp, CG_TaskPath, 1)

        ; 写入新空清单的标识，重置进度，再按旧逻辑重新读取。
        CG_ResetState(CG_ManifestId(FileRead(CG_TaskPath, "UTF-8")))
        CG_ReloadJobs()
        msg := "✓ 旧PDF任务已清空，发送进度已重置。`n点击【添加 PDF 任务】录入新PDF即可。原PDF和时间/坐标设置未改变。"
        if (backup != "")
            msg .= "`n已自动备份原任务清单：" backup
        CG_SetStatus(msg)
    } catch as e {
        MsgBox("清空任务失败：" e.Message, "错误")
        CG_SetStatus("⚠ 清空任务失败。请检查任务文件是否被占用；旧任务可能未更改。")
    }
}

CG_AddPdfJob(*) {
    global CG_TaskPath, CG_Running, CG_Mode, CG_Busy, CG_Jobs, CG_EditorOpen
    if CG_Running || CG_Busy || CG_EditorOpen {
        MsgBox("请先F9暂停并结束编辑，再添加PDF。")
        return
    }
    chosen := CG_Mode = "questions" ? FileSelect(1, , "选择要上传的PDF", "PDF 文件 (*.pdf)") : FileSelect("M1", , "可按 Ctrl 多选PDF，依次加入任务", "PDF 文件 (*.pdf)")
    if !chosen
        return
    if CG_Mode = "questions" {
        box := InputBox("输入这份PDF要提问的题号。例如：8-10,12,15-17", "设置题号", "w460 h150", "8-10")
        if box.Result != "OK"
            return
        try CG_ParseQuestions(box.Value, 1)
        catch as e {
            MsgBox(e.Message, "题号格式错误")
            return
        }
        FileAppend(chosen "|" box.Value "`r`n", CG_TaskPath, "UTF-8")
        CG_ReloadJobs()
        return
    }
    files := chosen is Array ? chosen : [chosen]
    if CG_Mode = "custom" {
        for pdf in files {
            SplitPath(pdf, &name)
            CG_Jobs.Push({path: pdf, name: name, qs: [1], msgs: [CG_DefaultCustomMessage()]})
        }
        try {
            CG_SaveCustomJobs()
            CG_OpenCustomManager()
        } catch as e
            MsgBox("添加PDF失败：" e.Message)
    } else {
        for pdf in files
            FileAppend(pdf "`r`n", CG_TaskPath, "UTF-8")
        CG_ReloadJobs()
    }
}

CG_EditJobs(*) {
    global CG_TaskPath, CG_Mode
    if CG_Mode = "custom" {
        CG_OpenCustomManager()
        return
    }
    Run('notepad.exe "' TaskPath '"')
}

CG_ResetState(sig) {
    global CG_StatePath, CG_StartProfileBox
    IniWrite(sig, CG_StatePath, "progress", "task_id")
    IniWrite("1", CG_StatePath, "progress", "job")
    IniWrite("1", CG_StatePath, "progress", "question")
    IniWrite("upload", CG_StatePath, "progress", "stage")
    IniWrite("", CG_StatePath, "progress", "until")
    IniWrite("1", CG_StatePath, "progress", "chat_group_start")
    IniWrite("0", CG_StatePath, "progress", "awaiting_new_chat")
    IniWrite(String(CG_StartProfileBox.Value = 2 ? 1 : 0), CG_StatePath, "progress", "fresh_profile")
}

CG_ResetProgress(*) {
    global CG_Busy
    if CG_Busy
        return
    global CG_Running, CG_Signature, CG_Jobs
    if CG_Running {
        MsgBox("先按 F9 暂停后才能重置。")
        return
    }
    if MsgBox("确定把发送进度清零吗？注意：重置后会重新上传第一份PDF、重新发送话语或题目。", "重置进度", "YesNo Icon!") != "Yes"
        return
    CG_ResetState(CG_Signature)
    CG_RestoreProgress()
    CG_ShowProgress()
}

CG_RestoreProgress() {
    global CG_StatePath, CG_JobIndex, CG_QuestionIndex, CG_Stage, CG_WaitUntil, CG_ChatGroupStartJob, CG_NeedManualNewChat, CG_InFreshComposer, CG_StartProfileBox
    CG_JobIndex := Number(IniRead(CG_StatePath, "progress", "job", "1"))
    CG_QuestionIndex := Number(IniRead(CG_StatePath, "progress", "question", "1"))
    CG_Stage := IniRead(CG_StatePath, "progress", "stage", "upload")
    CG_WaitUntil := IniRead(CG_StatePath, "progress", "until", "")
    CG_ChatGroupStartJob := Number(IniRead(CG_StatePath, "progress", "chat_group_start", "1"))
    CG_NeedManualNewChat := IniRead(CG_StatePath, "progress", "awaiting_new_chat", "0") = "1"
    CG_InFreshComposer := IniRead(CG_StatePath, "progress", "fresh_profile", CG_StartProfileBox.Value = 2 ? "1" : "0") = "1"
}

CG_SaveProgress() {
    global CG_StatePath, CG_Signature, CG_JobIndex, CG_QuestionIndex, CG_Stage, CG_WaitUntil, CG_ChatGroupStartJob, CG_NeedManualNewChat, CG_InFreshComposer
    IniWrite(CG_Signature, CG_StatePath, "progress", "task_id")
    IniWrite(String(CG_JobIndex), CG_StatePath, "progress", "job")
    IniWrite(String(CG_QuestionIndex), CG_StatePath, "progress", "question")
    IniWrite(CG_Stage, CG_StatePath, "progress", "stage")
    IniWrite(CG_WaitUntil, CG_StatePath, "progress", "until")
    IniWrite(String(CG_ChatGroupStartJob), CG_StatePath, "progress", "chat_group_start")
    IniWrite(CG_NeedManualNewChat ? "1" : "0", CG_StatePath, "progress", "awaiting_new_chat")
    IniWrite(CG_InFreshComposer ? "1" : "0", CG_StatePath, "progress", "fresh_profile")
}

CG_SetStatus(info) {
    global CG_StatusText
    CG_StatusText.Text := info
}

CG_ShowProgress() {
    global CG_Jobs, CG_JobIndex, CG_QuestionIndex, CG_Stage, CG_WaitUntil, CG_Running, CG_Mode
    if (CG_Stage = "done") {
        CG_SetStatus("✓ 全部PDF及对应提问已经发送完毕。注意这只代表脚本完成发送，不代表回答已结束。")
        return
    }
    if CG_Jobs.Length = 0 {
        CG_SetStatus("还没有任务。添加PDF任务；功能一、二都可以点【只发话语】。")
        return
    }
    if (CG_JobIndex > CG_Jobs.Length) {
        CG_SetStatus("进度超出任务数量，请重置进度。")
        return
    }
    j := CG_Jobs[CG_JobIndex]
    qText := CG_QuestionIndex <= j.qs.Length ? (CG_Mode = "questions" ? "第" j.qs[CG_QuestionIndex] "题" : "第" CG_QuestionIndex "/" j.qs.Length "条话语") : "等待切换"
    msg := (CG_Running ? "运行中" : "未运行/已暂停") "｜PDF " CG_JobIndex "/" CG_Jobs.Length "：" j.name
        . "`n当前阶段：" CG_Stage "｜" qText
    if (CG_Stage = "upload_wait" || CG_Stage = "question_wait" || CG_Stage = "pdf_wait") {
        secs := CG_WaitUntil != "" ? Max(0, DateDiff(CG_WaitUntil, A_Now, "Seconds")) : 0
        msg .= "｜剩余约" secs "秒"
    }
    CG_SetStatus(msg)
}

CG_ValidateTimers() {
    global CG_QBox, CG_PBox, CG_UBox, CG_QWait, CG_PDFWait, CG_UploadWait, CG_PrefPath
    qText := Trim(CG_QBox.Value)
    pText := Trim(CG_PBox.Value)
    uText := Trim(CG_UBox.Value)
    if !RegExMatch(qText, "^\d+$") || !RegExMatch(pText, "^\d+$") || !RegExMatch(uText, "^\d+$")
        throw Error("等待时间请输入整数")
    q := Number(qText), p := Number(pText), u := Number(uText)
    if (q < 1 || q > 120 || p < 1 || p > 120 || u < 15 || u > 3600)
        throw Error("每题及PDF间隔为1~120分钟；上传后的等待为15~3600秒")
    CG_QWait := q, CG_PDFWait := p, CG_UploadWait := u
    IniWrite(String(q), CG_PrefPath, "timing", "question_minutes")
    IniWrite(String(p), CG_PrefPath, "timing", "pdf_minutes")
    IniWrite(String(u), CG_PrefPath, "timing", "upload_seconds")
}

CG_StartRun() {
    global CG_Busy
    if CG_Busy
        return
    global CG_EditorOpen, CG_ManagerGui
    if CG_EditorOpen || IsObject(CG_ManagerGui)
        throw Error("请先关闭话语编辑窗口")
    if SubStr(CG_Stage, 1, 7) = "verify_"
        throw Error("有待核实操作，请使用主窗口的核实按钮")
    global CG_Running, CG_Jobs, CG_Stage, CG_ChatHwnd, CG_Busy, CG_Mode, CG_Msg1Box, CG_SendMsg1, CG_NeedManualNewChat, CG_ChatGroupStartJob, CG_JobIndex, CG_InFreshComposer
    if CG_Running {
        CG_ShowProgress()
        return
    }
    if !CG_Jobs.Length {
        MsgBox("先添加至少一份PDF任务。", "没有任务")
        return
    }
    if CG_Stage = "done" {
        MsgBox("任务已经完成。若要从头来，请使用‘重置发送进度’。")
        return
    }
    try {
        CG_ValidateTimers()
        CG_SaveConversationOptions()
        CG_SaveMessageSettings()
        CG_SendMsg1 := Trim(CG_Msg1Box.Value)
        if CG_Mode = "single" && CG_SendMsg1 = ""
            throw Error("功能一请填写固定话语")
        if CG_Mode = "custom" {
            for job in CG_Jobs {
                if job.msgs.Length < 1
                    throw Error("有PDF还没设置话语：" job.name)
            }
        }
        if CG_NeedManualNewChat {
            answer := MsgBox("此处必须开始一个全新的ChatGPT对话。`n`n请先在ChatGPT中手动点击【新建聊天】，确认页面空白；必要时按Ctrl+Alt+0绑定窗口。`n`n已经进入新的空白对话了吗？", "确认切换新对话", "YesNo Icon?")
            if answer != "Yes"
                return
            CG_NeedManualNewChat := false
            CG_ChatGroupStartJob := CG_JobIndex
            CG_InFreshComposer := true
            CG_SaveProgress()
        }
        CG_ChatHwnd := CG_ActivateChat()
        CG_Running := true
        CG_ShowProgress()


    } catch as e {
        CG_Running := false
        MsgBox(e.Message, "无法开始")
    }
}

CG_PauseRun() {
    global CG_Running
    CG_Running := false
    CG_ShowProgress()
}

CG_FastForward() {
    global CG_Running, CG_Stage, CG_WaitUntil
    if (CG_Stage != "upload_wait" && CG_Stage != "question_wait" && CG_Stage != "pdf_wait") {
        CG_SetStatus("当前不在等待阶段，F10不会跳过PDF或题目。")
        return
    }
    if !CG_Running
        CG_StartRun()
    if !CG_Running
        return
    CG_WaitUntil := A_Now
    CG_SaveProgress()


}

CG_BeginWait(nextStage, seconds) {
    global CG_Stage, CG_WaitUntil
    CG_Stage := nextStage
    CG_WaitUntil := DateAdd(A_Now, seconds, "Seconds")
    CG_SaveProgress()
}

CG_TickCore(*) {
    global CG_Running, CG_Busy, CG_Jobs, CG_JobIndex, CG_QuestionIndex, CG_Stage, CG_WaitUntil, CG_Mode, CG_SendMsg1
    global CG_UploadWait, CG_QWait, CG_PDFWait, CG_InFreshComposer, CG_ChatGroupStartJob, CG_NeedManualNewChat
    global CG_MaxPDFBox, CG_AutoSwitchBox, CG_NewChatX, CG_NewChatY
    if !CG_Running || CG_Busy
        return
    if !CG_Jobs.Length || CG_Stage = "done"
        return
    CG_Busy := true
    try {
        if (CG_Stage = "upload_wait" || CG_Stage = "question_wait" || CG_Stage = "pdf_wait") {
            if (CG_WaitUntil != "" && DateDiff(CG_WaitUntil, A_Now, "Seconds") > 0) {
                CG_ShowProgress()
                return
            }
            CG_WaitUntil := ""
            if CG_Stage = "upload_wait"
                CG_Stage := "question"
            else if CG_Stage = "question_wait"
                CG_Stage := "question"
            else {
                CG_JobIndex += 1
                CG_QuestionIndex := 1
                CG_Stage := "upload"
            }
            CG_SaveProgress()
        }

        if (CG_JobIndex > CG_Jobs.Length) {
            CG_Stage := "done"
            CG_SaveProgress()
            CG_Running := false
            CG_ShowProgress()
            return
        }
        job := CG_Jobs[CG_JobIndex]
        if (CG_Stage = "upload") {
            limit := Number(Trim(CG_MaxPDFBox.Value) = "" ? "0" : CG_MaxPDFBox.Value)
            if limit > 0 && CG_JobIndex > 1 && Mod(CG_JobIndex-1, limit) = 0 && CG_ChatGroupStartJob != CG_JobIndex {
                ; 在下一份PDF上传之前切换新聊天，避免把第11份误发到已满的旧聊天。
                if CG_AutoSwitchBox.Value && CG_NewChatX != "" && CG_NewChatY != "" {
                    CG_SetStatus("已达" limit "份PDF：尝试自动新建ChatGPT对话（请不要操作窗口）")
                    CG_ClickChat("new_chat")
                    Sleep(2600)
                    CG_ChatGroupStartJob := CG_JobIndex
                    CG_InFreshComposer := true
                    CG_SaveProgress()
                    CG_WriteLog("已点击新建ChatGPT对话，后续按新对话布局发送第" CG_JobIndex "份PDF")
                } else {
                    CG_NeedManualNewChat := true
                    CG_Running := false
                    CG_SaveProgress()
                    CG_SetStatus("⏸ 已完成前" (CG_JobIndex-1) "份PDF；请在ChatGPT手动新建空白聊天、Ctrl+Alt+0绑定并按F8。`n不会重发先前的PDF，也不会清空任务。")
                    return
                }
            }
            if (CG_Mode = "questions" || job.path != "") {
                CG_SetStatus("正在上传PDF " CG_JobIndex "/" CG_Jobs.Length "：" job.name "`n不要操作鼠标或键盘……")
                CG_AttachPDF(job.path)
                CG_SendChatText("请接收这份PDF《" job.name "》，后续提问均针对这份PDF。", true)
                ; 首条成功执行发送键后，ChatGPT会从空白新聊天进入已有消息聊天布局。
                CG_InFreshComposer := false
                CG_BeginWait("upload_wait", CG_UploadWait)
                CG_WriteLog("已发送PDF：" job.path)
            } else {
                ; 当前对话已有资料时可不再次上传PDF、不发介绍语。
                CG_BeginWait("upload_wait", 1)
                CG_WriteLog("纯文字任务准备开始")
            }
        } else if (CG_Stage = "upload_ready") {
            CG_SendChatText("请接收这份PDF《" job.name "》，后续提问均针对这份PDF。", true)
            CG_InFreshComposer := false
            CG_BeginWait("upload_wait", CG_UploadWait)
        } else if (CG_Stage = "question") {
            if CG_Mode = "questions" {
                q := job.qs[CG_QuestionIndex]
                msg := "这份PDF第" CG_ToChinese(q) "题没懂"
            } else if CG_Mode = "single"
                msg := CG_SendMsg1
            else
                msg := job.msgs[CG_QuestionIndex]
            CG_SetStatus("正在发送：" job.name " → " msg)
            CG_SendChatText(msg)
            CG_InFreshComposer := false
            CG_WriteLog("已发送提问：" job.name "：" msg)
            if (CG_QuestionIndex < job.qs.Length) {
                CG_QuestionIndex += 1
                CG_BeginWait("question_wait", CG_QWait*60)
            } else if (CG_JobIndex < CG_Jobs.Length) {
                CG_BeginWait("pdf_wait", CG_PDFWait*60)
            } else {
                CG_Stage := "done"
                CG_WaitUntil := ""
                CG_SaveProgress()
                CG_Running := false
            }
        }
        CG_ShowProgress()
    } catch as e {
        CG_Running := false
        CG_WriteLog("失败：" e.Message)
        CG_SetStatus("⚠ 已暂停：" e.Message "`n请检查ChatGPT是否正常、PDF是否上传成功、消息是否已发送。排查后按F8恢复；必要时重置进度。")
    } finally {
        CG_Busy := false
    }
}

CG_WriteLog(info) {
    global CG_LogPath
    FileAppend(FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " " info "`r`n", CG_LogPath, "UTF-8")
}


CG_Tick(*) {
    global MergedLockOwner, MergedInChildCall
    if MergedInChildCall && MergedLockOwner = "chatgpt"
        CG_TickCore()
}

GM_Init() {
SetTitleMatchMode(2)
SendMode("Input")
CoordMode("Mouse", "Screen") ; 以下保存/点击的都是屏幕绝对坐标
CoordMode("Pixel", "Screen") ; 残留附件图块检测使用屏幕坐标

; Windows AutoHotkey v2 | Gemini 桌面端多 PDF 顺序上传与逐题发送
; 不调用 API，不读取 PDF 题目内容。使用桌面窗口坐标定位附件按钮、上传菜单、输入框。
; 暂停/恢复依靠进度.ini；允许新对话首发，也允许按每对话PDF数自动/手动切换。
; 若 Gemini 不是独立 exe，而是 Chrome/Edge 安装的桌面应用，可先按 Ctrl+Alt+0 绑定当前 Gemini 窗口。
; 仅当附件按钮能调出 Windows 文件选择对话框时上传流程可用。

baseDir := A_ScriptDir
global GM_TaskPath := baseDir "\Gemini_PDF任务清单.txt"
; V4.4：设置不再存放在脚本所在目录，避免每次下载到不同文件夹被误认为重置。
; 首次启用会自动导入当前脚本文件夹的旧设置（如存在）。任务/进度仍沿用 V3/V4 原文件夹，不做清空。
global GM_PrefDir := A_AppData "\Gemini_MultiPDF_AutoSend"
DirCreate(GM_PrefDir)
legacyPrefPath := baseDir "\Gemini_设置.ini"
global GM_PrefPath := GM_PrefDir "\Gemini_设置.ini"
if !FileExist(GM_PrefPath) && FileExist(legacyPrefPath)
    FileCopy(legacyPrefPath, GM_PrefPath)
global GM_StatePath := baseDir "\Gemini_多PDF进度.ini"
global GM_LogPath := baseDir "\Gemini_运行日志.txt"
; V4.9.5 将详细诊断日志放在稳定的 AppData 目录，与已有任务/进度文件分离。
global GM_DebugPath := GM_PrefDir "\Gemini_V4.9.5_详细诊断日志.txt"
global GM_DebugSeq := 0
global GM_LastDiagProblem := "尚无故障记录"
global GM_DiagSession := FormatTime(A_Now, "yyyyMMdd-HHmmss")
; V4 新增固定话语与每PDF自定义模式，仅在选中模式时启用，原逐题逻辑和旧任务文件保留。
global GM_Mode := "questions"
global GM_SendMsg1 := ""
global GM_OriginalTaskPath := GM_TaskPath
global GM_OriginalStatePath := GM_StatePath
global GM_FixedTaskPath := baseDir "\Gemini_固定话语任务清单.txt"
global GM_FixedStatePath := baseDir "\Gemini_固定话语进度.ini"
global GM_CustomTaskPath := baseDir "\Gemini_自定义话语任务清单.txt"
global GM_CustomStatePath := baseDir "\Gemini_自定义话语进度.ini"
; V4.9.4：修复检测时弹出 PowerShell 窗口抢走焦点；保留 V4.9.3 上传和话语定位改进。
; 保留 V4.9.1 的任务、进度及设置路径。
global GM_TogetherTaskPath := baseDir "\Gemini_同步上传话语任务清单.txt"
global GM_TogetherStatePath := baseDir "\Gemini_同步上传话语进度.ini"
global GM_ManagerGui := 0
global GM_ManagerList := 0
global GM_EditorOpen := false
global GM_Jobs := []
global GM_Signature := ""
global GM_JobIndex := 1
global GM_QuestionIndex := 1
global GM_Stage := "upload"   ; upload / upload_ready / upload_wait / question / question_wait / pdf_wait / done
global GM_WaitUntil := ""
global GM_Running := false
global GM_Busy := false
global GM_LastUploadProbe := "尚未测试"
global GM_ChatHwnd := 0
global GM_PlusX := IniRead(GM_PrefPath, "coords", "plusX", "")
global GM_PlusY := IniRead(GM_PrefPath, "coords", "plusY", "")
global GM_UploadX := IniRead(GM_PrefPath, "coords", "uploadX", "")
global GM_UploadY := IniRead(GM_PrefPath, "coords", "uploadY", "")
global GM_InputX := IniRead(GM_PrefPath, "coords", "inputX", "")
global GM_InputY := IniRead(GM_PrefPath, "coords", "inputY", "")
; Gemini附加PDF后会把输入行向上抬高，因此与普通文字输入使用不同的落点。
; 未校准时按照附件＋号自动估计；按Ctrl+Alt+4可对含PDF的输入行精确校准。
global GM_AttachedInputX := IniRead(GM_PrefPath, "coords", "attachedInputX", "")
global GM_AttachedInputY := IniRead(GM_PrefPath, "coords", "attachedInputY", "")
global GM_QWait := 30  ; 分钟
global GM_PDFWait := 60 ; 分钟
global GM_UploadWait := 30 ; 秒：PDF消息发送完到首题之间
; V4.4: 旧对话坐标不变，新增空白新对话独立坐标；全部保存在原 Gemini_设置.ini。
global GM_FreshPlusX := IniRead(GM_PrefPath, "coords", "freshPlusX", "")
global GM_FreshPlusY := IniRead(GM_PrefPath, "coords", "freshPlusY", "")
global GM_FreshUploadX := IniRead(GM_PrefPath, "coords", "freshUploadX", "")
global GM_FreshUploadY := IniRead(GM_PrefPath, "coords", "freshUploadY", "")
global GM_FreshInputX := IniRead(GM_PrefPath, "coords", "freshInputX", "")
global GM_FreshInputY := IniRead(GM_PrefPath, "coords", "freshInputY", "")
global GM_FreshAttachedX := IniRead(GM_PrefPath, "coords", "freshAttachedX", "")
global GM_FreshAttachedY := IniRead(GM_PrefPath, "coords", "freshAttachedY", "")
global GM_NewChatX := IniRead(GM_PrefPath, "coords", "newChatX", "")
global GM_NewChatY := IniRead(GM_PrefPath, "coords", "newChatY", "")
global GM_InFreshComposer := false
; 当前模式进度分别保存这些字段，不会改动V3的原有任务清单字段。
global GM_ChatGroupStartJob := 1
; 需要手动新建对话时，不会发送下一份PDF，直到用户确认后按F8。
global GM_NeedManualNewChat := false
; V4.6：上传PDF时发送的“请接收这份PDF……”按PDF路径分别保存，所有模式共用。
; 仅改变首条上传说明，不改变原版逐题、功能一或功能二的正式话语。
global GM_UploadIntroPath := GM_PrefDir "\Gemini_每份PDF上传说明.txt"
global GM_UploadIntroMap := Map()
global GM_UploadIntroGui := 0
global GM_UploadIntroList := 0
global GM_UploadIntroEditor := 0

; V4.8：每份新PDF上传前多轮检测/重复清理残留输入框附件；清理异常只写日志不暂停。
; UIA自动识别/移除优先；若Gemini没有提供可访问的删除按钮，可校准一次卡片上的×。
global GM_CleanupRemoveX := IniRead(GM_PrefPath, "coords", "cleanupRemoveX", "")
global GM_CleanupRemoveY := IniRead(GM_PrefPath, "coords", "cleanupRemoveY", "")
global GM_FreshCleanupRemoveX := IniRead(GM_PrefPath, "coords", "freshCleanupRemoveX", "")
global GM_FreshCleanupRemoveY := IniRead(GM_PrefPath, "coords", "freshCleanupRemoveY", "")
global GM_SkipCleanupOnce := false


if !FileExist(GM_TaskPath)
    FileAppend("# 每行格式：PDF完整路径|题号，例如：D:\资料\第一讲.pdf|8-10,12,16-18`r`n# 可点脚本窗口里的【添加 PDF 任务】，无须手工写路径。`r`n", GM_TaskPath, "UTF-8")

; V4.9.8.2：处理空白/损坏的INI数值，防止Number("")造成启动中断；不写回、不重置任务。



; V4.3：主窗口缩小为紧凑可调整大小的界面；高级设置独立弹窗。
; 不改动上传、发送、任务、等待、校准和进度的实际处理函数。
global GM_MainGui := Gui("+AlwaysOnTop +Resize +MinSize590x395", "Gemini 多PDF自动发送 · V4.9.8.3 发送可靠性修复版")
GM_MainGui.SetFont("s9", "Microsoft YaHei")
GM_MainGui.MarginX := 12
GM_MainGui.MarginY := 10
global GM_CountText := GM_MainGui.AddText("xm w650 h26", "正在载入任务……")
GM_MainGui.AddText("xm y+8", "每条话语间隔(分)：")
global GM_QBox := GM_MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(GM_PrefPath, "timing", "question_minutes", "30"))
GM_MainGui.AddText("x+14 yp+3", "每份PDF间隔(分)：")
global GM_PBox := GM_MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(GM_PrefPath, "timing", "pdf_minutes", "60"))
GM_MainGui.AddText("x+14 yp+3", "上传后等待(秒)：")
global GM_UBox := GM_MainGui.AddEdit("x+5 yp-3 w60 Number", IniRead(GM_PrefPath, "timing", "upload_seconds", "30"))
GM_QBox.OnEvent("Change", GM_SaveTimersOnEdit)
GM_PBox.OnEvent("Change", GM_SaveTimersOnEdit)
GM_UBox.OnEvent("Change", GM_SaveTimersOnEdit)
GM_MainGui.AddText("xm y+12", "首次使用的 Gemini 对话：")
global GM_StartProfileBox := GM_MainGui.AddDropDownList("x+7 yp-4 w215", ["已有消息的旧对话", "空白新对话（首发PDF）"])
GM_StartProfileBox.Choose(GM_GeminiSafeInteger(IniRead(GM_PrefPath, "chat", "start_profile", "1"), 1, 1, 2))
GM_StartProfileBox.OnEvent("Change", GM_SaveStartProfile)
global GM_AdvBtn := GM_MainGui.AddButton("x+17 yp-1 w137 h27", "高级设置 / 定位")
GM_AdvBtn.OnEvent("Click", GM_ShowAdvancedSettings)
global GM_SavePrefsBtn := GM_MainGui.AddButton("x+8 yp w105 h27", "保存全部设置")
GM_SavePrefsBtn.OnEvent("Click", (*) => GM_SaveAllSettings(true))
GM_MainGui.AddText("xm y+12", "发送模式：")
global GM_ModeBox := GM_MainGui.AddDropDownList("x+6 yp-4 w565", ["原版：PDF逐题提问", "功能一：所有PDF共用一条固定话语", "功能二：每份PDF自定义1~多条话语", "功能三：PDF和一句话同时发送"])
GM_ModeBox.Choose(GM_GeminiSafeInteger(IniRead(GM_PrefPath, "messages", "mode_index", "1"), 1, 1, 4))
GM_ModeBox.OnEvent("Change", GM_SwitchMode)
global GM_Msg1Label := GM_MainGui.AddText("xm y+9 w650", "功能一专用：所有PDF共用的固定话语（可修改）：")
global GM_Msg1Box := GM_MainGui.AddEdit("xm y+4 w650", IniRead(GM_PrefPath, "messages", "first", "请帮我整理申论，生成word"))
GM_Msg1Box.OnEvent("Change", GM_SaveMessageSettings)
addBtn := GM_MainGui.AddButton("xm y+11 w142 h29", "添加 PDF 任务")
addBtn.OnEvent("Click", GM_AddPdfJob)
editBtn := GM_MainGui.AddButton("x+7 yp w142 h29", "编辑任务清单")
editBtn.OnEvent("Click", GM_EditJobs)
reloadBtn := GM_MainGui.AddButton("x+7 yp w142 h29", "刷新任务（不清空）")
reloadBtn.OnEvent("Click", GM_ReloadJobs)
resetBtn := GM_MainGui.AddButton("x+7 yp w142 h29", "重置发送进度")
resetBtn.OnEvent("Click", GM_ResetProgress)
; 在紧凑主窗口第一排末尾增加日志入口，不弹出需要确认的模态对话框。
GM_MainGui.AddButton("x+7 yp w72 h29", "诊断日志").OnEvent("Click", GM_OpenDiagnosticLog)
noPdfBtn := GM_MainGui.AddButton("xm y+7 w250 h29", "只发话语（不重新上传PDF）")
noPdfBtn.OnEvent("Click", GM_AddTextOnlyJob)
global GM_NoPdfBtn := noPdfBtn
global GM_CustomManageBtn := GM_MainGui.AddButton("x+8 yp w250 h29", "管理每份PDF的话语")
GM_CustomManageBtn.OnEvent("Click", GM_OpenCustomManager)
; 不需要切换功能一/功能二：三个模式都可以单独改“上传PDF时的说明”。
global GM_IntroManageBtn := GM_MainGui.AddButton("x+8 yp w155 h29", "每份PDF上传说明")
GM_IntroManageBtn.OnEvent("Click", GM_OpenUploadIntroManager)
GM_MainGui.AddText("xm y+10 w650", "F8 开始/继续　F9 暂停　F10 跳过等待　F12 退出")
global GM_StatusText := GM_MainGui.AddText("xm y+8 w650 h83", "添加PDF任务，校准 Gemini 窗口后按 F8。")
GM_MainGui.OnEvent("Size", GM_CompactWindowResized)
GM_MainGui.OnEvent("Close", (*) => GM_MainGui.Hide())

; 以下设置被移入弹出的高级窗口，仍沿用原变量和原保存逻辑。
global GM_AdvancedGui := Gui("+AlwaysOnTop", "Gemini · 高级设置与坐标定位")
GM_AdvancedGui.SetFont("s9", "Microsoft YaHei")
GM_AdvancedGui.MarginX := 14
GM_AdvancedGui.MarginY := 13
GM_AdvancedGui.AddText("xm w640", "快捷键校准：把鼠标放到 Gemini 目标位置后按组合键，位置自动保存。")
GM_AdvancedGui.AddText("xm y+9 w670", "Ctrl+Alt+0 绑定窗口； 1 附件＋； 2 上传菜单； 3 普通输入框； 4 附件后输入框")
GM_AdvancedGui.AddText("xm y+6 w670", "新对话专用：Ctrl+Alt+5 附件＋； 6 上传菜单； 7 普通输入框； 8 附件后输入框")
GM_AdvancedGui.AddText("xm y+6 w670", "Ctrl+Alt+9：新建聊天按钮（若需自动切换对话，必须先校准）")
GM_AdvancedGui.AddText("xm y+6 w690", "残留PDF清理：自动多次识别和清除；清理失败写日志但不中断。Ctrl+Shift+Alt+R 校准删除×")
global GM_CalText := GM_AdvancedGui.AddText("xm y+12 w665 h56", "正在读取定位状态……")
GM_AdvancedGui.AddText("xm y+12", "每个对话最多处理PDF数量（0 = 不换）：")
global GM_MaxPDFBox := GM_AdvancedGui.AddEdit("x+8 yp-3 w64 Number", IniRead(GM_PrefPath, "chat", "max_pdfs", "0"))
GM_MaxPDFBox.OnEvent("Change", GM_SaveConversationOptions)
global GM_AutoSwitchBox := GM_AdvancedGui.AddCheckBox("xm y+13", "到上限自动点击【新建聊天】（需要 Ctrl+Alt+9 已校准）")
GM_AutoSwitchBox.Value := GM_GeminiSafeInteger(IniRead(GM_PrefPath, "chat", "auto_switch", "0"), 0, 0, 1)
GM_AutoSwitchBox.OnEvent("Click", GM_SaveConversationOptions)
GM_AdvancedGui.AddText("xm y+12 w670", "不勾选时到上限将安全暂停，手动打开新聊天并按 Ctrl+Alt+0、F8 继续。")
GM_AdvancedGui.AddText("xm y+9 w670", "V4.4：设置保存在 Windows AppData，移动或升级脚本也不会重置。")
GM_AdvancedGui.AddText("xm y+5 w670", "设置文件：" GM_PrefPath)
GM_AdvancedGui.AddButton("xm y+12 w125 h28", "保存全部设置").OnEvent("Click", (*) => GM_SaveAllSettings(true))
GM_AdvancedGui.AddButton("x+8 yp w125 h28", "导入旧设置").OnEvent("Click", GM_ImportLegacySettings)
GM_AdvancedGui.AddButton("x+8 yp w125 h28", "打开设置文件夹").OnEvent("Click", GM_OpenPrefsFolder)
GM_AdvancedGui.AddButton("x+8 yp w125 h28", "关闭高级设置").OnEvent("Click", GM_HideAdvancedSettings)
GM_AdvancedGui.AddButton("x+8 yp w132 h28", "复制故障摘要").OnEvent("Click", GM_CopyDiagnosticSummary)
; V4.9.7：校准后可直接试开文件选择窗口，不触碰任务进度、不上传PDF。
GM_AdvancedGui.AddButton("xm y+11 w225 h30", "测试上传按钮（不上传PDF）").OnEvent("Click", GM_TestGeminiUploadPickerManaged)
GM_AdvancedGui.AddText("x+12 yp+7 w430", "新对话请先 Ctrl+Alt+5 校准＋，Ctrl+Alt+6 校准上传菜单。")
global GM_TestResultText := GM_AdvancedGui.AddText("xm y+9 w675 h40", "测试结果显示在这里。测试独立于41份任务，不上传文件、不推进进度。")
GM_AdvancedGui.OnEvent("Close", GM_HideAdvancedSettings)
GM_MainGui.Hide()

GM_InitSelectedMode()
try GM_LoadUploadIntros()
catch as e
    GM_SetStatus("PDF上传说明载入失败：" e.Message)
try GM_ReloadJobs()
catch as e
    GM_SetStatus("载入任务失败：" e.Message)
GM_UpdateCalibration()
GM_DiagLog("START", "V4.9.8.3已启动；修复附件后粘贴校验与发送焦点重试；原任务文件格式未变")


; 紧凑窗口支持拖动四角改变大小，正文和状态栏自动随宽度扩展。









; ===== V4：三个独立模式。原版模式仍使用 V3 原始的文件和完整调度。 =====









; 下面的统一保存也会在按 F12 和点窗口 X 时执行；不会清空任务或进度。



; OnExit回调必须返回0，否则返回true会阻止程序退出。



; 手动保存：先检查三个间隔及PDF上限，再写入同一个 AppData 配置文件并读回确认。



; 旧版本的ini往往存放于各个下载文件夹。可选择其中一份导入，当前配置先备份。









; 切到新对话后，只有第一条带附件的PDF消息使用居中的新对话坐标。
; 第一条实际发出以后立即恢复原来已经校准好的旧对话坐标。






















; ===== V4.6：管理每份PDF上传时的说明（独立于三种正式话语模式） =====
; 没有为某PDF设置专属说明时，严格保持V4.5原始上传话语。









; 文件存放在AppData，而不是脚本当前文件夹；换V4.x版本也不会丢失。
; 路径和话语都编码为一行，支持中文、|、%、换行。















; V4.9：选择多行后的索引由第一列任务号决定（避免忽略无PDF任务时错行）。

































; 任务清单编码，允许文字里包含竖线、百分号、逗号及换行；不会误分割话语。





; 修改功能二任务后只重置功能二的进度，不触碰原版和功能一的进度。



; 功能二不需要编辑代码，在管理窗口中选PDF、编辑/新增/删除话语即可。



























; V4.9：功能二批量多句/空白；功能三批量单句，均只重置当前模式的进度。













































; V4.9.4：所有 UI Automation 检测统一以隐藏进程执行。
; 旧版 WScript.Shell.Exec(powershell.exe) 会显示控制台并夺取 Gemini 的前台焦点。
; 用隐藏的 cmd /c 重定向 PowerShell 结果文件，避免检测影响鼠标点击和后续输入。
; ===== V4.9.5 诊断辅助（不记录PDF正文或用户完整话语） =====

































; ===== V4.8：上传下一份PDF前多轮检测/清除，无法清理也继续（有混入风险） =====
; 检测范围严格限制在 Gemini 输入框＋号左侧附近的附件卡片区域，
; 不触碰已发出的聊天记录、任务清单或上传说明。






















; 所有UIA坐标在转换前先确认非空、确实为数字：避免Number("")让整个脚本暂停。












 ; ===== V4.9.8 点击与文件选择窗口诊断：不写任务、不写进度 =====
























; 保持原任务文件和坐标字段不变；只是避免在新对话借用旧坐标。






; 可检测是否真的打开 Windows 文件选择框；测试会自行关闭对话框，绝不上传PDF，不修改41份任务。



















; 【重新载入任务】按钮：清空当前模式的任务清单并重置当前模式的断点。
; GM_ReloadJobs 保持原样：脚本启动和添加PDF时仍然读取任务，不会误清空。










































; 功能三PDF+一句同发，或功能二后续话语为零时：直接进入下一PDF等待。
}

GM_GeminiSafeInteger(raw, fallback, minimum, maximum) {
    val := Trim(String(raw))
    if !RegExMatch(val, "^\d+$") || StrLen(val) > 8
        return fallback
    n := Number(val)
    return (n >= minimum && n <= maximum) ? n : fallback
}

GM_CompactWindowResized(guiObj, minMax, width, height) {
    global GM_CountText, GM_ModeBox, GM_Msg1Label, GM_Msg1Box, GM_StatusText
    if minMax = -1
        return
    contentWidth := Max(555, width - 27)
    try {
        GM_CountText.Move(, , contentWidth)
        GM_ModeBox.Move(, , Max(430, contentWidth - 89))
        GM_Msg1Label.Move(, , contentWidth)
        GM_Msg1Box.Move(, , contentWidth)
        GM_StatusText.GetPos(&sx, &sy, &sw, &sh)
        GM_StatusText.Move(, , contentWidth, Max(58, height - sy - 16))
    }
}

GM_ShowAdvancedSettings(*) {
    global GM_AdvancedGui
    GM_AdvancedGui.Show("w760 h505")
}

GM_HideAdvancedSettings(*) {
    global GM_AdvancedGui
    try GM_SaveConversationOptions()
    GM_AdvancedGui.Hide()
}

GM_SaveTimersOnEdit(*) {
    ; 修改后立即保存，F12和右上角关闭也会再保存一次，避免退出重置。
    global GM_QBox, GM_PBox, GM_UBox, GM_PrefPath
    for t in [["question_minutes", GM_QBox.Value, 1, 120], ["pdf_minutes", GM_PBox.Value, 1, 120], ["upload_seconds", GM_UBox.Value, 15, 3600]] {
        v := Trim(t[2])
        if RegExMatch(v, "^\d+$") && Number(v) >= t[3] && Number(v) <= t[4]
            IniWrite(String(Number(v)), GM_PrefPath, "timing", t[1])
    }
}

GM_SaveConversationOptions(*) {
    global GM_PrefPath, GM_MaxPDFBox, GM_AutoSwitchBox
    n := Trim(GM_MaxPDFBox.Value)
    if RegExMatch(n, "^\d+$") && Number(n) <= 1000
        IniWrite(String(Number(n)), GM_PrefPath, "chat", "max_pdfs")
    IniWrite(String(GM_AutoSwitchBox.Value), GM_PrefPath, "chat", "auto_switch")
}

GM_SaveStartProfile(*) {
    global GM_StartProfileBox, GM_PrefPath, GM_JobIndex, GM_Stage, GM_InFreshComposer, GM_Running
    IniWrite(String(GM_StartProfileBox.Value), GM_PrefPath, "chat", "start_profile")
    ; 仅尚未开始的第一份任务可切换开场界面，防止中途误覆盖现场状态。
    if !GM_Running && GM_JobIndex = 1 && GM_Stage = "upload" {
        GM_InFreshComposer := GM_StartProfileBox.Value = 2
        GM_SaveProgress()
    }
}

GM_SafeExit(*) {
    GM_SaveAllSettings(false)
    ExitApp()
}

GM_OnScriptExit(*) {
    GM_SaveAllSettings(false)
    return 0
}

GM_SaveAllSettings(showNotice := true) {
    global GM_PrefPath, GM_QBox, GM_PBox, GM_UBox, GM_MaxPDFBox, GM_AutoSwitchBox, GM_StartProfileBox, GM_ModeBox, GM_Msg1Box
    global GM_PlusX, GM_PlusY, GM_UploadX, GM_UploadY, GM_InputX, GM_InputY, GM_AttachedInputX, GM_AttachedInputY
    global GM_FreshPlusX, GM_FreshPlusY, GM_FreshUploadX, GM_FreshUploadY, GM_FreshInputX, GM_FreshInputY
    global GM_FreshAttachedX, GM_FreshAttachedY, GM_NewChatX, GM_NewChatY
    global GM_CleanupRemoveX, GM_CleanupRemoveY, GM_FreshCleanupRemoveX, GM_FreshCleanupRemoveY
    try {
        GM_ValidateTimers()
        n := Trim(GM_MaxPDFBox.Value)
        if !RegExMatch(n, "^\d+$") || Number(n) > 1000
            throw Error("每个对话的PDF数量必须是0～1000之间的整数")
        GM_SaveConversationOptions()
        GM_SaveMessageSettings()
        IniWrite(String(GM_StartProfileBox.Value), GM_PrefPath, "chat", "start_profile")
        IniWrite(String(GM_ModeBox.Value), GM_PrefPath, "messages", "mode_index")
        values := Map(
            "plusX", GM_PlusX, "plusY", GM_PlusY, "uploadX", GM_UploadX, "uploadY", GM_UploadY,
            "inputX", GM_InputX, "inputY", GM_InputY,
            "attachedInputX", GM_AttachedInputX, "attachedInputY", GM_AttachedInputY,
            "freshPlusX", GM_FreshPlusX, "freshPlusY", GM_FreshPlusY,
            "freshUploadX", GM_FreshUploadX, "freshUploadY", GM_FreshUploadY,
            "freshInputX", GM_FreshInputX, "freshInputY", GM_FreshInputY,
            "freshAttachedX", GM_FreshAttachedX, "freshAttachedY", GM_FreshAttachedY,
            "newChatX", GM_NewChatX, "newChatY", GM_NewChatY,
            "cleanupRemoveX", GM_CleanupRemoveX, "cleanupRemoveY", GM_CleanupRemoveY,
            "freshCleanupRemoveX", GM_FreshCleanupRemoveX, "freshCleanupRemoveY", GM_FreshCleanupRemoveY)
        for key, value in values {
            if value != ""
                IniWrite(String(value), GM_PrefPath, "coords", key)
        }
        if IniRead(GM_PrefPath, "timing", "question_minutes", "") != String(Number(Trim(GM_QBox.Value)))
            throw Error("每条话语间隔未能读回，请检查写入权限")
        if IniRead(GM_PrefPath, "timing", "pdf_minutes", "") != String(Number(Trim(GM_PBox.Value)))
            throw Error("每份PDF间隔未能读回，请检查写入权限")
        if IniRead(GM_PrefPath, "timing", "upload_seconds", "") != String(Number(Trim(GM_UBox.Value)))
            throw Error("上传后等待时间未能读回，请检查写入权限")
        if IniRead(GM_PrefPath, "chat", "max_pdfs", "") != String(Number(n))
            throw Error("每个对话PDF数量未能读回，请检查写入权限")
        for key, value in values {
            if value != "" && IniRead(GM_PrefPath, "coords", key, "") != String(value)
                throw Error("定位设置 " key " 未能读回，请检查写入权限")
        }
        if showNotice
            GM_SetStatus("✓ 全部设置已保存并核对成功。间隔与坐标下次启动继续有效。")
        return true
    } catch as e {
        if showNotice
            MsgBox("保存未完成：" e.Message "`n请不要退出，先检查填写和目录权限。`n" GM_PrefPath, "保存失败", "Iconx")
        return false
    }
}

GM_ImportLegacySettings(button := 0, *) {
    global GM_PrefPath, GM_Running, GM_Busy, GM_QBox, GM_PBox, GM_UBox, GM_MaxPDFBox, GM_AutoSwitchBox
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    global GM_StartProfileBox, GM_Msg1Box, GM_ModeBox, GM_PrefDir
    global GM_PlusX, GM_PlusY, GM_UploadX, GM_UploadY, GM_InputX, GM_InputY, GM_AttachedInputX, GM_AttachedInputY
    global GM_FreshPlusX, GM_FreshPlusY, GM_FreshUploadX, GM_FreshUploadY, GM_FreshInputX, GM_FreshInputY
    global GM_FreshAttachedX, GM_FreshAttachedY, GM_NewChatX, GM_NewChatY
    global GM_CleanupRemoveX, GM_CleanupRemoveY, GM_FreshCleanupRemoveX, GM_FreshCleanupRemoveY
    if GM_Running || GM_Busy {
        MsgBox("请先按 F9 暂停任务，再导入旧设置。")
        return
    }
    selected := FileSelect(1, A_ScriptDir, "选择旧版 Gemini_设置.ini", "INI 设置文件 (*.ini)")
    if selected = ""
        return
    if StrLower(selected) = StrLower(GM_PrefPath) {
        MsgBox("你选的就是当前设置文件，不需要重复导入。")
        return
    }
    if MsgBox("将读取所选旧设置，替换当前的间隔、定位坐标和模式设置。`n当前设置会先自动备份；PDF任务和发送进度不删除。`n`n继续？", "确认导入", "YesNo Icon?") != "Yes"
        return
    try {
        if FileExist(GM_PrefPath)
            FileCopy(GM_PrefPath, GM_PrefDir "\Gemini_设置_导入前备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") ".ini")
        FileCopy(selected, GM_PrefPath, true)
        GM_QBox.Value := IniRead(GM_PrefPath, "timing", "question_minutes", "30")
        GM_PBox.Value := IniRead(GM_PrefPath, "timing", "pdf_minutes", "60")
        GM_UBox.Value := IniRead(GM_PrefPath, "timing", "upload_seconds", "30")
        GM_MaxPDFBox.Value := IniRead(GM_PrefPath, "chat", "max_pdfs", "0")
        GM_AutoSwitchBox.Value := GM_GeminiSafeInteger(IniRead(GM_PrefPath, "chat", "auto_switch", "0"), 0, 0, 1)
        GM_StartProfileBox.Choose(GM_GeminiSafeInteger(IniRead(GM_PrefPath, "chat", "start_profile", "1"), 1, 1, 2))
        GM_Msg1Box.Value := IniRead(GM_PrefPath, "messages", "first", "请帮我整理申论，生成word")
        GM_ModeBox.Choose(GM_GeminiSafeInteger(IniRead(GM_PrefPath, "messages", "mode_index", "1"), 1, 1, 4))
        ; 发送模式的实际任务列表保持不动；重新打开脚本时才切到导入的模式。
        GM_PlusX := IniRead(GM_PrefPath, "coords", "plusX", "")
        GM_PlusY := IniRead(GM_PrefPath, "coords", "plusY", "")
        GM_UploadX := IniRead(GM_PrefPath, "coords", "uploadX", "")
        GM_UploadY := IniRead(GM_PrefPath, "coords", "uploadY", "")
        GM_InputX := IniRead(GM_PrefPath, "coords", "inputX", "")
        GM_InputY := IniRead(GM_PrefPath, "coords", "inputY", "")
        GM_AttachedInputX := IniRead(GM_PrefPath, "coords", "attachedInputX", "")
        GM_AttachedInputY := IniRead(GM_PrefPath, "coords", "attachedInputY", "")
        GM_FreshPlusX := IniRead(GM_PrefPath, "coords", "freshPlusX", "")
        GM_FreshPlusY := IniRead(GM_PrefPath, "coords", "freshPlusY", "")
        GM_FreshUploadX := IniRead(GM_PrefPath, "coords", "freshUploadX", "")
        GM_FreshUploadY := IniRead(GM_PrefPath, "coords", "freshUploadY", "")
        GM_FreshInputX := IniRead(GM_PrefPath, "coords", "freshInputX", "")
        GM_FreshInputY := IniRead(GM_PrefPath, "coords", "freshInputY", "")
        GM_FreshAttachedX := IniRead(GM_PrefPath, "coords", "freshAttachedX", "")
        GM_FreshAttachedY := IniRead(GM_PrefPath, "coords", "freshAttachedY", "")
        GM_NewChatX := IniRead(GM_PrefPath, "coords", "newChatX", "")
        GM_NewChatY := IniRead(GM_PrefPath, "coords", "newChatY", "")
        GM_CleanupRemoveX := IniRead(GM_PrefPath, "coords", "cleanupRemoveX", "")
        GM_CleanupRemoveY := IniRead(GM_PrefPath, "coords", "cleanupRemoveY", "")
        GM_FreshCleanupRemoveX := IniRead(GM_PrefPath, "coords", "freshCleanupRemoveX", "")
        GM_FreshCleanupRemoveY := IniRead(GM_PrefPath, "coords", "freshCleanupRemoveY", "")
        GM_UpdateCalibration()
        ; 导入的发送模式下次重启会恢复，这里不强制切换正在编辑的任务模式。
        if GM_SaveAllSettings(false)
            MsgBox("导入成功！已加载旧设置并保存到固定位置。`n`n旧设置内的发送模式将在下次启动时恢复。`n" GM_PrefPath, "导入完成", "Iconi")
        else
            MsgBox("已读入旧INI，但有字段无效。请检查三个间隔及PDF上限，并点击【保存全部设置】。", "需要检查")
    } catch as e {
        MsgBox("导入失败：" e.Message, "错误", "Iconx")
    }
}

GM_OpenPrefsFolder(*) {
    global GM_PrefDir
    Run(GM_PrefDir)
}

GM_CalibrateFresh(which) {
    global GM_PrefPath, GM_FreshPlusX, GM_FreshPlusY, GM_FreshUploadX, GM_FreshUploadY
    global GM_FreshInputX, GM_FreshInputY, GM_FreshAttachedX, GM_FreshAttachedY, GM_NewChatX, GM_NewChatY
    h := GM_GetChat()
    if !h {
        MsgBox("请先切换到Gemini窗口并按 Ctrl+Alt+0 绑定后再校准。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx-wx, ry := my-wy
    if which = "plus" {
        GM_FreshPlusX := rx, GM_FreshPlusY := ry
        key := "freshPlus", label := "新对话附件＋"
    } else if which = "upload" {
        GM_FreshUploadX := rx, GM_FreshUploadY := ry
        key := "freshUpload", label := "新对话上传菜单"
    } else if which = "input" {
        GM_FreshInputX := rx, GM_FreshInputY := ry
        key := "freshInput", label := "新对话普通输入框"
    } else if which = "attached_input" {
        GM_FreshAttachedX := rx, GM_FreshAttachedY := ry
        key := "freshAttached", label := "新对话带PDF的输入框"
    } else {
        GM_NewChatX := rx, GM_NewChatY := ry
        key := "newChat", label := "新建聊天按钮"
    }
    IniWrite(String(rx), GM_PrefPath, "coords", key "X")
    IniWrite(String(ry), GM_PrefPath, "coords", key "Y")
    GM_UpdateCalibration()
    ToolTip("已保存：" label "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -2200)
}

GM_ModeIndex() {
    global GM_Mode
    return GM_Mode = "single" ? 2 : (GM_Mode = "custom" ? 3 : (GM_Mode = "together" ? 4 : 1))
}

GM_TaskTemplate() {
    global GM_Mode
    if GM_Mode = "questions"
        return "# 每行：PDF完整路径|题号，如 D:\第一讲.pdf|8-10,12`r`n"
    if GM_Mode = "single"
        return "# 每行一个PDF完整路径；或 @NO_PDF 代表在当前对话直接发一次固定话语。`r`n"
    if GM_Mode = "together"
        return "# 功能三：每个PDF附带且只发送一句专属话语；PDF路径|话语，使用窗口编辑。`r`n"
    return "# 功能二：每个PDF可设置多句；PDF路径|第1句|第2句；末尾单独|表示不发送后续话语。`r`n"
}

GM_InitSelectedMode() {
    global GM_ModeBox
    GM_SelectMode(GM_ModeBox.Value, false)
}

GM_SelectMode(idx, reload := true) {
    global GM_Mode, GM_TaskPath, GM_StatePath, GM_OriginalTaskPath, GM_OriginalStatePath, GM_CustomTaskPath, GM_CustomStatePath
    global GM_FixedTaskPath, GM_FixedStatePath, GM_TogetherTaskPath, GM_TogetherStatePath, GM_PrefPath, GM_NoPdfBtn, GM_CustomManageBtn, GM_IntroManageBtn, GM_Msg1Label, GM_Msg1Box
    idx := idx >= 1 && idx <= 4 ? idx : 1
    GM_Mode := idx = 1 ? "questions" : (idx = 2 ? "single" : (idx = 3 ? "custom" : "together"))
    GM_TaskPath := idx = 1 ? GM_OriginalTaskPath : (idx = 2 ? GM_FixedTaskPath : (idx = 3 ? GM_CustomTaskPath : GM_TogetherTaskPath))
    GM_StatePath := idx = 1 ? GM_OriginalStatePath : (idx = 2 ? GM_FixedStatePath : (idx = 3 ? GM_CustomStatePath : GM_TogetherStatePath))
    if !FileExist(GM_TaskPath)
        FileAppend(GM_TaskTemplate(), GM_TaskPath, "UTF-8")
    GM_NoPdfBtn.Enabled := idx = 2 || idx = 3
    GM_IntroManageBtn.Enabled := idx != 4 ; 功能三不使用单独上传说明
    GM_CustomManageBtn.Enabled := idx = 3 || idx = 4
    GM_Msg1Box.Enabled := idx = 2
    GM_Msg1Label.Text := idx = 4 ? "功能三：每份PDF只发一条消息，请点【管理每份PDF的话语】修改。" : (idx = 3 ? "功能二：请点【管理每份PDF的话语】，每份单独编辑；支持批量设空白。" : "功能一专用：所有PDF共用的固定话语（可修改）：")
    IniWrite(String(idx), GM_PrefPath, "messages", "mode_index")
    if reload
        GM_ReloadJobs()
}

GM_SwitchMode(*) {
    global GM_Running, GM_Busy, GM_ModeBox, GM_EditorOpen, GM_ManagerGui, GM_UploadIntroGui
    if GM_Running || GM_Busy || GM_EditorOpen || IsObject(GM_ManagerGui) || IsObject(GM_UploadIntroGui) {
        MsgBox("请先暂停并关闭自定义任务管理/编辑窗口，再切换模式。", "暂时不能切换")
        GM_ModeBox.Choose(GM_ModeIndex())
        return
    }
    try GM_SelectMode(GM_ModeBox.Value)
    catch as e {
        MsgBox("切换模式失败：" e.Message, "错误")
        GM_ModeBox.Choose(GM_ModeIndex())
    }
}

GM_SaveMessageSettings(*) {
    global GM_Msg1Box, GM_PrefPath
    IniWrite(Trim(GM_Msg1Box.Value), GM_PrefPath, "messages", "first")
}

GM_AddTextOnlyJob(*) {
    global GM_TaskPath, GM_Running, GM_Busy, GM_Mode, GM_Jobs, GM_EditorOpen, GM_Msg1Box
    if GM_Mode = "questions" {
        MsgBox("原版逐题模式不支持纯文字任务，请选择固定或自定义话语模式。")
        return
    }
    if GM_Running || GM_Busy || GM_EditorOpen {
        MsgBox("请先暂停并关闭话语编辑窗口，再添加任务。")
        return
    }
    if GM_Mode = "custom" {
        GM_Jobs.Push({path: "", name: "当前对话（不上传PDF）", qs: [1], msgs: [GM_DefaultCustomMessage()]})
        try {
            GM_SaveCustomJobs()
            GM_OpenCustomManager()
        } catch as e
            MsgBox("添加失败：" e.Message)
    } else {
        FileAppend("@NO_PDF`r`n", GM_TaskPath, "UTF-8")
        GM_ReloadJobs()
    }
}

GM_DefaultUploadIntro(job) {
    return "请接收这份PDF《" job.name "》，后续提问均针对这份PDF。"
}

GM_UploadIntroKey(path) {
    return StrLower(Trim(path))
}

GM_GetUploadIntro(job) {
    global GM_UploadIntroMap
    if job.path = ""
        return ""
    key := GM_UploadIntroKey(job.path)
    return GM_UploadIntroMap.Has(key) ? GM_UploadIntroMap[key] : GM_DefaultUploadIntro(job)
}

GM_LoadUploadIntros() {
    global GM_UploadIntroPath, GM_UploadIntroMap
    GM_UploadIntroMap := Map()
    if !FileExist(GM_UploadIntroPath)
        return
    for line in StrSplit(StrReplace(FileRead(GM_UploadIntroPath, "UTF-8"), "`r", ""), "`n") {
        if Trim(line) = "" || SubStr(line, 1, 1) = "#"
            continue
        sep := InStr(line, "|")
        if !sep
            continue
        path := GM_UnescapeCustomField(SubStr(line, 1, sep-1))
        msg := GM_UnescapeCustomField(SubStr(line, sep+1))
        ; 有路径且分隔符存在，即使说明为空也保留这条自定义记录。
        ; "路径|" 代表不发送上传说明（只发送PDF），与"未设置"严格区分。
        if path != ""
            GM_UploadIntroMap[GM_UploadIntroKey(path)] := msg
    }
}

GM_SaveUploadIntros() {
    global GM_UploadIntroMap, GM_UploadIntroPath
    content := "# Gemini V4.6 每份PDF上传说明。请在脚本窗口里编辑；不同发送模式共享同一PDF的上传说明。`r`n"
    for path, msg in GM_UploadIntroMap {
        ; 空白说明是允许的：仍然写出路径|，下次启动不会恢复默认话语。
        content .= GM_EscapeCustomField(path) "|" GM_EscapeCustomField(msg) "`r`n"
    }
    temp := GM_UploadIntroPath ".new"
    if FileExist(temp)
        FileDelete(temp)
    FileAppend(content, temp, "UTF-8")
    FileMove(temp, GM_UploadIntroPath, 1)
    ; 保存后立即读取磁盘，检查写入是否成功，避免退出后丢失。
    if !FileExist(GM_UploadIntroPath)
        throw Error("上传说明未写入磁盘")
}

GM_OpenUploadIntroManager(*) {
    global GM_UploadIntroGui, GM_UploadIntroList, GM_UploadIntroEditor, GM_Jobs, GM_Running, GM_Busy, GM_ManagerGui, GM_EditorOpen
    if GM_Running || GM_Busy {
        MsgBox("请先F9暂停发送，再修改PDF的上传说明。")
        return
    }
    if GM_EditorOpen || IsObject(GM_ManagerGui) {
        MsgBox("请先关闭功能二的话语管理窗口。")
        return
    }
    if IsObject(GM_UploadIntroGui) {
        WinActivate("ahk_id " GM_UploadIntroGui.Hwnd)
        return
    }
    hasPdf := false
    for job in GM_Jobs {
        if job.path != "" {
            hasPdf := true
            break
        }
    }
    if !hasPdf {
        MsgBox("当前模式还没有PDF任务，请先点击【添加 PDF 任务】。")
        return
    }
    uploadIntroManagerWin := Gui("+AlwaysOnTop", "每份PDF上传说明 · 独立编辑")
    uploadIntroManagerWin.SetFont("s9", "Microsoft YaHei")
    uploadIntroManagerWin.AddText("xm w770", "这里修改的是上传PDF时的第一句说明，不是上传后的逐题提问/固定话语。每份PDF可设置不同内容。")
    GM_UploadIntroList := uploadIntroManagerWin.AddListView("xm y+8 w770 r10 Grid Checked +Multi", ["序号", "PDF", "状态", "上传说明预览"])
    GM_UploadIntroList.ModifyCol(1, 45)
    GM_UploadIntroList.ModifyCol(2, 205)
    GM_UploadIntroList.ModifyCol(3, 65)
    GM_UploadIntroList.ModifyCol(4, 440)
    GM_UploadIntroList.OnEvent("DoubleClick", (control, clickedRow) => GM_EditUploadIntro(clickedRow))
    uploadIntroManagerWin.AddButton("xm y+10 w150 h30 Default", "编辑选中PDF说明").OnEvent("Click", (*) => GM_EditUploadIntro())
    uploadIntroManagerWin.AddButton("x+9 yp w135 h30", "恢复选中PDF默认").OnEvent("Click", (*) => GM_ResetUploadIntro())
    uploadIntroManagerWin.AddButton("x+9 yp w120 h30", "刷新列表").OnEvent("Click", GM_RefreshUploadIntroManager)
    uploadIntroManagerWin.AddButton("x+9 yp w115 h30", "关闭管理窗口").OnEvent("Click", GM_CloseUploadIntroManager)
    uploadIntroManagerWin.AddButton("xm y+8 w110 h29", "全选PDF").OnEvent("Click", (*) => GM_SelectAllListRows(GM_UploadIntroList))
    uploadIntroManagerWin.AddButton("x+8 yp w110 h29", "取消全选").OnEvent("Click", (*) => GM_ClearAllListRows(GM_UploadIntroList))
    uploadIntroManagerWin.AddButton("x+8 yp w165 h29", "批量同一句上传说明").OnEvent("Click", GM_OpenBulkUploadIntroEditor)
    uploadIntroManagerWin.AddButton("x+8 yp w145 h29", "批量设为空白").OnEvent("Click", (*) => GM_ApplyBulkUploadIntro(""))
    uploadIntroManagerWin.AddText("xm y+10 w770", "推荐勾选每行左侧方框来指定PDF；也支持Ctrl/Shift高亮。勾选优先；全选/取消全选可见。")
    uploadIntroManagerWin.OnEvent("Close", GM_CloseUploadIntroManager)
    GM_UploadIntroGui := uploadIntroManagerWin
    GM_RefreshUploadIntroManager()
    uploadIntroManagerWin.Show("w800 h440")
}

GM_RefreshUploadIntroManager(*) {
    global GM_UploadIntroGui, GM_UploadIntroList, GM_UploadIntroMap, GM_Jobs
    if !IsObject(GM_UploadIntroGui)
        return
    ; 保存已经勾选的任务序号，不要在保存后刷新列表时丢掉选择。
    marked := Map()
    previous := 0
    while previous := GM_UploadIntroList.GetNext(previous, "Checked") {
        identifier := Trim(GM_UploadIntroList.GetText(previous, 1))
        if RegExMatch(identifier, "^\d+$")
            marked[identifier] := true
    }
    GM_UploadIntroList.Delete()
    for i, job in GM_Jobs {
        if job.path = ""
            continue
        msg := GM_GetUploadIntro(job)
        customized := !GM_UploadIntroMap.Has(GM_UploadIntroKey(job.path)) ? "默认" : (Trim(msg) = "" ? "不发说明" : "自定义")
        preview := Trim(msg) = "" ? "（仅发送PDF；跳过上传说明）" : SubStr(StrReplace(msg, "`n", " "), 1, 90)
        GM_UploadIntroList.Add(marked.Has(String(i)) ? "Check" : "", i, job.name, customized, preview)
    }
}

GM_SelectedUploadIntroJob(preferredRow := 0) {
    global GM_UploadIntroList, GM_Jobs
    row := preferredRow > 0 ? preferredRow : 0
    if !row {
        markedRow := GM_UploadIntroList.GetNext(0, "Checked")
        if markedRow && GM_UploadIntroList.GetNext(markedRow, "Checked") {
            MsgBox("勾选了多份PDF。单独编辑请只勾一份，或者直接双击你要编辑的PDF那一行。")
            return 0
        }
        row := markedRow ? markedRow : GM_UploadIntroList.GetNext()
    }
    if !row
        row := GM_UploadIntroList.GetNext(0, "Focused")
    if !row {
        MsgBox("请点选该PDF所在行，或在它左侧勾选方框。")
        return 0
    }
    identifier := Trim(GM_UploadIntroList.GetText(row, 1))
    if !RegExMatch(identifier, "^\d+$")
        return 0
    index := Number(identifier)
    if index < 1 || index > GM_Jobs.Length || GM_Jobs[index].path = ""
        return 0
    return index
}

GM_SelectedJobIndices(view, includeNoPdf := false) {
    global GM_Jobs
    result := []
    seen := Map()
    ; 若至少有一个方框被勾选，只处理被勾选的PDF，避免误用旧的高亮行。
    selectionType := view.GetNext(0, "Checked") ? "Checked" : ""
    row := 0
    while row := view.GetNext(row, selectionType) {
        val := Trim(view.GetText(row, 1))
        if !RegExMatch(val, "^\d+$")
            continue
        i := Number(val)
        if i >= 1 && i <= GM_Jobs.Length && (includeNoPdf || GM_Jobs[i].path != "") && !seen.Has(i) {
            result.Push(i)
            seen[i] := true
        }
    }
    return result
}

GM_SelectAllListRows(view) {
    if view.GetCount() = 0
        return
    view.Modify(0, "Select Check")
    view.Modify(1, "Focus Vis")
    if view.GetNext(0, "Checked") = 0
        MsgBox("没有成功勾选。请检查列表是否可操作。")
}

GM_ClearAllListRows(view) {
    view.Modify(0, "-Select -Check")
}

GM_OpenBulkUploadIntroEditor(*) {
    global GM_UploadIntroList, GM_UploadIntroEditor
    if IsObject(GM_UploadIntroEditor)
        return
    indices := GM_SelectedJobIndices(GM_UploadIntroList)
    if indices.Length = 0 {
        MsgBox("请先在列表里选中若干份PDF，或点【全选PDF】。")
        return
    }
    ed := Gui("+AlwaysOnTop", "批量设置 " indices.Length " 份PDF的上传说明")
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w630", "下面文字将同时应用到选中的PDF；留空=只上传PDF，不附带上传说明。")
    field := ed.AddEdit("xm y+8 w630 r7 VScroll")
    ed.AddButton("xm y+10 w150 Default", "批量保存").OnEvent("Click", (*) => GM_ApplyBulkUploadIntro(field.Value, indices, ed))
    ed.AddButton("x+8 yp w120", "取消").OnEvent("Click", (*) => GM_CloseUploadIntroEditor(ed))
    ed.OnEvent("Close", (*) => GM_CloseUploadIntroEditor(ed))
    GM_UploadIntroEditor := ed
    ed.Show("w670 h300")
}

GM_ApplyBulkUploadIntro(textValue, selected := 0, editor := 0) {
    global GM_UploadIntroList, GM_UploadIntroMap, GM_Jobs, GM_Running, GM_Busy, GM_UploadIntroGui
    try {
        if IsObject(editor)
            editor.Opt("+OwnDialogs")
        else if IsObject(GM_UploadIntroGui)
            GM_UploadIntroGui.Opt("+OwnDialogs")
    }
    if GM_Running || GM_Busy {
        MsgBox("请先按F9暂停后再批量编辑。")
        return
    }
    indices := selected is Array ? selected : GM_SelectedJobIndices(GM_UploadIntroList)
    if indices.Length = 0 {
        MsgBox("请先选择PDF，或点击【全选PDF】。")
        return
    }
    msg := Trim(textValue, " `t`r`n")
    ; V4.9.2：批量保存按钮本身就是确认，不再另外弹“是/否”。
    previous := Map()
    for i in indices {
        key := GM_UploadIntroKey(GM_Jobs[i].path)
        if !previous.Has(key)
            previous[key] := GM_UploadIntroMap.Has(key) ? {exists: true, value: GM_UploadIntroMap[key]} : {exists: false}
        GM_UploadIntroMap[key] := msg
    }
    try {
        GM_SaveUploadIntros()
        GM_LoadUploadIntros()
        for i in indices {
            key := GM_UploadIntroKey(GM_Jobs[i].path)
            if !GM_UploadIntroMap.Has(key) || GM_UploadIntroMap[key] != msg
                throw Error("写入后读回不一致：" GM_Jobs[i].name)
        }
        if IsObject(editor)
            GM_CloseUploadIntroEditor(editor)
        GM_RefreshUploadIntroManager()
        GM_SetStatus("✓ 批量保存完成：" indices.Length " 份PDF上传说明" (msg = "" ? "（只发PDF）" : "") "。")
    } catch as e {
        for key, old in previous {
            if old.exists
                GM_UploadIntroMap[key] := old.value
            else if GM_UploadIntroMap.Has(key)
                GM_UploadIntroMap.Delete(key)
        }
        try GM_SaveUploadIntros()
        MsgBox("批量保存失败：" e.Message, "错误", "Iconx")
    }
}

GM_EditUploadIntro(clickedRow := 0) {
    global GM_UploadIntroGui, GM_UploadIntroEditor, GM_Jobs, GM_Running, GM_Busy
    if GM_Running || GM_Busy || IsObject(GM_UploadIntroEditor)
        return
    i := GM_SelectedUploadIntroJob(clickedRow)
    if !i
        return
    job := GM_Jobs[i]
    editor := Gui("+AlwaysOnTop", "编辑第" i "份PDF的上传说明：" job.name)
    editor.SetFont("s10", "Microsoft YaHei")
    editor.AddText("xm w765", "这里填写上传说明；可以完全留空：届时只发送PDF，不发任何上传说明。其他PDF不受影响。")
    field := editor.AddEdit("xm y+9 w765 r6 VScroll", GM_GetUploadIntro(job))
    editor.AddButton("xm y+10 w145 h32 Default", "保存这份PDF说明").OnEvent("Click", (*) => GM_SaveUploadIntroEditor(job, field.Value, editor))
    editor.AddButton("x+10 yp w135 h32", "取消不保存").OnEvent("Click", (*) => GM_CloseUploadIntroEditor(editor))
    editor.OnEvent("Close", (*) => GM_CloseUploadIntroEditor(editor))
    GM_UploadIntroEditor := editor
    editor.Show("w800 h270")
}

GM_SaveUploadIntroEditor(job, textValue, editor) {
    global GM_UploadIntroMap, GM_Running, GM_Busy
    try editor.Opt("+OwnDialogs")
    if GM_Running || GM_Busy {
        MsgBox("请先F9暂停发送。")
        return
    }
    ; 空白＝明确选择不发上传说明；不等于恢复默认。
    message := Trim(textValue, " `t`r`n")
    key := GM_UploadIntroKey(job.path)
    oldHad := GM_UploadIntroMap.Has(key)
    oldValue := oldHad ? GM_UploadIntroMap[key] : ""
    GM_UploadIntroMap[key] := message
    try {
        GM_SaveUploadIntros()
        ; 重新读取持久文件，确认这份PDF的内容确实保存一致。
        GM_LoadUploadIntros()
        if !GM_UploadIntroMap.Has(key) || GM_UploadIntroMap[key] != message
            throw Error("保存后读取结果不一致")
        GM_CloseUploadIntroEditor(editor)
        GM_RefreshUploadIntroManager()
        GM_SetStatus("✓ 《" job.name "》的上传说明已保存。" (message = "" ? "只发送PDF，不附加说明。" : ""))
    } catch as e {
        if oldHad
            GM_UploadIntroMap[key] := oldValue
        else if GM_UploadIntroMap.Has(key)
            GM_UploadIntroMap.Delete(key)
        MsgBox("保存失败：" e.Message, "错误", "Iconx")
    }
}

GM_ResetUploadIntro(*) {
    global GM_UploadIntroMap, GM_Running, GM_Busy, GM_Jobs
    if GM_Running || GM_Busy
        return
    i := GM_SelectedUploadIntroJob()
    if !i
        return
    key := GM_UploadIntroKey(GM_Jobs[i].path)
    if !GM_UploadIntroMap.Has(key) {
        MsgBox("这份PDF已经在使用默认说明。")
        return
    }
    ; 用户点击“恢复选中PDF默认”即视为确认。
    oldValue := GM_UploadIntroMap[key]
    GM_UploadIntroMap.Delete(key)
    try {
        GM_SaveUploadIntros()
        GM_RefreshUploadIntroManager()
    } catch as e {
        GM_UploadIntroMap[key] := oldValue
        MsgBox("恢复默认失败：" e.Message, "错误", "Iconx")
    }
}

GM_CloseUploadIntroEditor(editor) {
    global GM_UploadIntroEditor
    if IsObject(GM_UploadIntroEditor) {
        try editor.Destroy()
        GM_UploadIntroEditor := 0
    }
}

GM_CloseUploadIntroManager(*) {
    global GM_UploadIntroGui, GM_UploadIntroList, GM_UploadIntroEditor
    if IsObject(GM_UploadIntroEditor) {
        MsgBox("请先保存或关闭正在编辑的PDF上传说明。")
        return
    }
    if IsObject(GM_UploadIntroGui) {
        GM_UploadIntroGui.Destroy()
        GM_UploadIntroGui := 0
        GM_UploadIntroList := 0
    }
}

GM_DefaultCustomMessage() {
    global GM_PrefPath
    return IniRead(GM_PrefPath, "custom", "default_message", "请帮我整理申论，生成Word")
}

GM_EscapeCustomField(s) {
    s := StrReplace(s, "%", "%25")
    s := StrReplace(s, "|", "%7C")
    s := StrReplace(s, "`r", "%0D")
    return StrReplace(s, "`n", "%0A")
}

GM_UnescapeCustomField(s) {
    s := StrReplace(s, "%0A", "`n")
    s := StrReplace(s, "%0D", "`r")
    s := StrReplace(s, "%7C", "|")
    return StrReplace(s, "%25", "%")
}

GM_SaveCustomJobs() {
    global GM_Mode, GM_Jobs, GM_TaskPath, GM_Running, GM_Busy
    if (GM_Mode != "custom" && GM_Mode != "together") || GM_Running || GM_Busy
        throw Error("只能在已暂停的功能二/功能三下修改")
    content := GM_TaskTemplate()
    for job in GM_Jobs {
        if GM_Mode = "together" && (job.path = "" || job.msgs.Length != 1 || Trim(job.msgs[1]) = "")
            throw Error("功能三每份PDF必须有且仅有一条非空话语：" job.name)
        if job.path = "" && job.msgs.Length = 0
            throw Error("纯文字任务必须至少有一句话：" job.name)
        line := GM_EscapeCustomField(job.path = "" ? "@NO_PDF" : job.path)
        if job.msgs.Length = 0
            line .= "|%00"  ; 功能二：明确标记无后续话语，不依赖尾随分隔符解析
        for m in job.msgs {
            if Trim(m) = ""
                throw Error("PDF：" job.name " 有空白话语")
            line .= "|" GM_EscapeCustomField(m)
        }
        content .= line "`r`n"
    }
    temp := GM_TaskPath ".new"
    if FileExist(temp)
        FileDelete(temp)
    FileAppend(content, temp, "UTF-8")
    ; 写入完成才替换任务清单，并从真实文件重读校验（不能只相信内存）。
    saved := FileRead(temp, "UTF-8")
    if StrReplace(saved, "`r", "") != StrReplace(content, "`r", "")
        throw Error("临时任务文件写入校验失败")
    FileMove(temp, GM_TaskPath, 1)
    saved := FileRead(GM_TaskPath, "UTF-8")
    if StrReplace(saved, "`r", "") != StrReplace(content, "`r", "")
        throw Error("任务文件保存后读回不一致")
    GM_ResetState(GM_ManifestId(saved))
    GM_ReloadJobs()
    GM_RefreshCustomManager()
}

GM_OpenCustomManager(*) {
    global GM_Mode, GM_ManagerGui, GM_ManagerList, GM_MainGui, GM_Running, GM_Busy
    if GM_Mode != "custom" && GM_Mode != "together" {
        MsgBox("请先切换到功能二或功能三。")
        return
    }
    if IsObject(GM_ManagerGui) {
        try WinActivate("ahk_id " GM_ManagerGui.Hwnd)
        return
    }
    mgr := Gui("+AlwaysOnTop", GM_Mode = "together" ? "功能三 · 每份PDF只上传并发送一句" : "功能二 · 每份PDF分别设置发送次数及话语")
    mgr.SetFont("s10", "Microsoft YaHei")
    mgr.AddText("xm w855", GM_Mode = "together" ? "每份PDF只设置一句话，与PDF在同一条消息发送；可批量统一设置。" : "每份PDF可设置多句话；一行一条。批量清空后只发送上传说明，不再单独追问。")
    GM_ManagerList := mgr.AddListView("xm y+8 w855 r11 Grid Checked +Multi", ["序号", "PDF", "话语数", "首句话预览"])
    GM_ManagerList.ModifyCol(1, 48)
    GM_ManagerList.ModifyCol(2, 295)
    GM_ManagerList.ModifyCol(3, 75)
    GM_ManagerList.ModifyCol(4, 425)
    GM_ManagerList.OnEvent("DoubleClick", (control, clickedRow) => GM_EditCustomJob(clickedRow))
    add := mgr.AddButton("xm y+12 w118", "添加PDF")
    add.OnEvent("Click", GM_AddPdfJob)
    edit := mgr.AddButton("x+6 yp w128", "编辑这份话语")
    edit.OnEvent("Click", (*) => GM_EditCustomJob())
    del := mgr.AddButton("x+6 yp w105", "删除这份PDF")
    del.OnEvent("Click", GM_DeleteCustomJob)
    up := mgr.AddButton("x+6 yp w100", "向上移动")
    up.OnEvent("Click", (*) => GM_MoveCustomJob(-1))
    down := mgr.AddButton("x+6 yp w100", "向下移动")
    down.OnEvent("Click", (*) => GM_MoveCustomJob(1))
    mgr.AddButton("xm y+9 w110", "全选PDF").OnEvent("Click", (*) => GM_SelectAllListRows(GM_ManagerList))
    mgr.AddButton("x+7 yp w110", "取消全选").OnEvent("Click", (*) => GM_ClearAllListRows(GM_ManagerList))
    mgr.AddButton("x+7 yp w165", "批量设置相同话语").OnEvent("Click", GM_OpenBulkCustomEditor)
    bulkClearBtn := mgr.AddButton("x+7 yp w145", "批量设为空白")
    bulkClearBtn.Enabled := GM_Mode = "custom"
    bulkClearBtn.OnEvent("Click", (*) => GM_ApplyBulkCustomMessages(""))
    mgr.AddText("xm y+9 w855", GM_Mode = "together" ? "勾选指定PDF后批量设置；功能三每PDF只有一句，禁止空白。" : "勾选左侧复选框指定PDF，批量空白只清除功能二后续话语；支持Ctrl/Shift高亮。")
    mgr.OnEvent("Close", GM_CloseCustomManager)
    GM_ManagerGui := mgr
    GM_RefreshCustomManager()
    mgr.Show("w880 h470")
}

GM_CloseCustomManager(*) {
    global GM_ManagerGui, GM_ManagerList, GM_EditorOpen
    if GM_EditorOpen {
        MsgBox("请先保存或取消正在编辑的话语。")
        return
    }
    if IsObject(GM_ManagerGui)
        GM_ManagerGui.Destroy()
    GM_ManagerGui := 0
    GM_ManagerList := 0
}

GM_RefreshCustomManager() {
    global GM_Mode, GM_Jobs, GM_ManagerGui, GM_ManagerList
    if (GM_Mode != "custom" && GM_Mode != "together") || !IsObject(GM_ManagerGui)
        return
    marked := Map()
    previous := 0
    while previous := GM_ManagerList.GetNext(previous, "Checked") {
        identifier := Trim(GM_ManagerList.GetText(previous, 1))
        if RegExMatch(identifier, "^\d+$")
            marked[identifier] := true
    }
    GM_ManagerList.Delete()
    for i, job in GM_Jobs {
        preview := job.msgs.Length ? StrReplace(job.msgs[1], "`n", " ") : ""
        GM_ManagerList.Add(marked.Has(String(i)) ? "Check" : "", i, job.name, job.msgs.Length, SubStr(preview, 1, 75))
    }
}

GM_SelectedCustomRow(preferredRow := 0) {
    global GM_ManagerGui, GM_ManagerList, GM_Jobs
    if !IsObject(GM_ManagerGui)
        return 0
    row := preferredRow > 0 ? preferredRow : 0
    if !row {
        markedRow := GM_ManagerList.GetNext(0, "Checked")
        if markedRow && GM_ManagerList.GetNext(markedRow, "Checked") {
            MsgBox("勾选了多份PDF。单独编辑请只勾一份，或者直接双击要编辑的那一行。")
            return 0
        }
        row := markedRow ? markedRow : GM_ManagerList.GetNext()
    }
    if !row
        row := GM_ManagerList.GetNext(0, "Focused")
    if !row {
        MsgBox("请点击一份PDF所在行，或勾选左侧方框。")
        return 0
    }
    identifier := Trim(GM_ManagerList.GetText(row, 1))
    if !RegExMatch(identifier, "^\d+$")
        return 0
    index := Number(identifier)
    if index < 1 || index > GM_Jobs.Length
        return 0
    return index
}

GM_JoinCustomMessages(msgs) {
    result := ""
    for m in msgs
        result .= (A_Index = 1 ? "" : "`r`n") m
    return result
}

GM_EditCustomJob(clickedRow := 0) {
    global GM_Mode, GM_Jobs, GM_EditorOpen, GM_ManagerGui
    if (GM_Mode != "custom" && GM_Mode != "together") || GM_EditorOpen
        return
    row := GM_SelectedCustomRow(clickedRow)
    if !row
        return
    GM_EditorOpen := true
    ed := Gui("+AlwaysOnTop", "编辑第" row "份PDF的话语：" GM_Jobs[row].name)
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w795", GM_Mode = "together" ? "只写一句话，PDF和这句一起发送。" : "一行 = 发送一次；留空则不发送后续话语。")
    field := ed.AddEdit("xm y+8 w795 r12 VScroll", GM_JoinCustomMessages(GM_Jobs[row].msgs))
    ; 保存按钮始终新起一行：修复功能三没有【再添加一句】时保存按钮被挤到屏幕外。
    save := ed.AddButton("xm y+12 w155 Default", "保存这份话语")
    save.OnEvent("Click", (*) => GM_SaveCustomEditor(row, field.Value, ed))
    if GM_Mode = "custom" {
        more := ed.AddButton("x+9 yp w140", "再添加一句")
        more.OnEvent("Click", (*) => GM_AppendBlankMessage(field))
    }
    cancel := ed.AddButton("x+9 yp w110", "取消")
    cancel.OnEvent("Click", (*) => GM_CloseCustomEditor(ed))
    ed.OnEvent("Close", (*) => GM_CloseCustomEditor(ed))
    ed.Show("w825 h390")
}

GM_AppendBlankMessage(field) {
    field.Value .= "`r`n"
    field.Focus()
    Send("^{End}")
}

GM_CloseCustomEditor(editor) {
    global GM_EditorOpen
    GM_EditorOpen := false
    try editor.Destroy()
}

GM_SaveCustomEditor(row, value, editor) {
    global GM_Jobs, GM_Running, GM_Busy, GM_Mode
    try editor.Opt("+OwnDialogs")
    if GM_Running || GM_Busy {
        MsgBox("正在发送，不能修改。请先F9暂停。")
        return
    }
    msgs := []
    for line in StrSplit(StrReplace(value, "`r", ""), "`n") {
        line := Trim(line, " `t`r`n")
        if line != ""
            msgs.Push(line)
    }
    if GM_Mode = "together" && msgs.Length != 1 {
        MsgBox("功能三每份PDF只允许一句非空话语，请调整后保存。")
        return
    }
    ; V4.9.2：点击“保存这份话语”后立即保存并读回校验。
    old := GM_Jobs[row].msgs
    GM_Jobs[row].msgs := msgs
    try {
        GM_SaveCustomJobs()
        GM_CloseCustomEditor(editor)
        GM_SetStatus("✓ 已保存第" row "份PDF的" msgs.Length "条话语；当前模式进度已重置。")
    } catch as e {
        GM_Jobs[row].msgs := old
        MsgBox("保存失败：" e.Message)
    }
}

GM_OpenBulkCustomEditor(*) {
    global GM_Mode, GM_ManagerList, GM_EditorOpen
    if GM_EditorOpen
        return
    indices := GM_SelectedJobIndices(GM_ManagerList, GM_Mode = "custom")
    if indices.Length = 0 {
        MsgBox("请先多选PDF，或点【全选PDF】。")
        return
    }
    GM_EditorOpen := true
    ed := Gui("+AlwaysOnTop", "批量修改" indices.Length "份PDF的话语")
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w700", GM_Mode = "together" ? "功能三：下面只能填一句话；每份PDF与它同时发出。" : "功能二：每行一句话，可写多行；完全留空=不发送后续话语。")
    field := ed.AddEdit("xm y+10 w700 r8 VScroll")
    ed.AddButton("xm y+10 w140 Default", "批量保存").OnEvent("Click", (*) => GM_ApplyBulkCustomMessages(field.Value, indices, ed))
    ed.AddButton("x+8 yp w120", "取消").OnEvent("Click", (*) => GM_CloseCustomEditor(ed))
    ed.OnEvent("Close", (*) => GM_CloseCustomEditor(ed))
    ed.Show("w735 h335")
}

GM_ApplyBulkCustomMessages(rawText, indices := 0, editor := 0) {
    global GM_Mode, GM_ManagerList, GM_Jobs, GM_Running, GM_Busy, GM_ManagerGui
    try {
        if IsObject(editor)
            editor.Opt("+OwnDialogs")
        else if IsObject(GM_ManagerGui)
            GM_ManagerGui.Opt("+OwnDialogs")
    }
    if GM_Running || GM_Busy {
        MsgBox("先F9暂停再修改。")
        return
    }
    if GM_Mode != "custom" && GM_Mode != "together"
        return
    indices := indices is Array ? indices : GM_SelectedJobIndices(GM_ManagerList, GM_Mode = "custom")
    if indices.Length = 0 {
        MsgBox("请先在列表中选中PDF，或点击全选PDF。")
        return
    }
    msgs := []
    for line in StrSplit(StrReplace(rawText, "`r", ""), "`n") {
        line := Trim(line)
        if line != ""
            msgs.Push(line)
    }
    if GM_Mode = "together" && msgs.Length != 1 {
        MsgBox("功能三必须且只能填写一句非空话语，不支持批量留空。")
        return
    }
    ; V4.9.2：点击“批量保存”即直接作用于当前勾选的PDF。
    old := Map()
    for i in indices {
        old[i] := GM_Jobs[i].msgs
        GM_Jobs[i].msgs := msgs.Clone()
    }
    try {
        GM_SaveCustomJobs()
        if IsObject(editor)
            GM_CloseCustomEditor(editor)
        GM_SetStatus("✓ 批量保存成功：" indices.Length "份PDF，每份" msgs.Length "条话语；本模式进度已重置。")
    } catch as e {
        for i, messages in old
            GM_Jobs[i].msgs := messages
        MsgBox("批量保存失败：" e.Message, "错误", "Iconx")
    }
}

GM_DeleteCustomJob(button := 0, *) {
    global GM_Jobs, GM_Running, GM_Busy
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    row := GM_SelectedCustomRow()
    if !row || GM_Running || GM_Busy
        return
    if MsgBox("确定删除第" row "份PDF任务？`n只删除任务记录，不会删除PDF文件。功能二进度将重置。", "删除任务", "YesNo Icon!") != "Yes"
        return
    old := GM_Jobs.RemoveAt(row)
    try GM_SaveCustomJobs()
    catch as e {
        GM_Jobs.InsertAt(row, old)
        MsgBox("删除失败：" e.Message)
    }
}

GM_MoveCustomJob(dir) {
    global GM_Jobs, GM_Running, GM_Busy, GM_ManagerList
    row := GM_SelectedCustomRow()
    if !row || GM_Running || GM_Busy
        return
    dest := row + dir
    if dest < 1 || dest > GM_Jobs.Length
        return
    temp := GM_Jobs[row]
    GM_Jobs[row] := GM_Jobs[dest]
    GM_Jobs[dest] := temp
    try {
        GM_SaveCustomJobs()
        GM_ManagerList.Modify(dest, "Select Focus Vis")
    } catch as e {
        GM_Jobs[dest] := GM_Jobs[row]
        GM_Jobs[row] := temp
        MsgBox("移动失败：" e.Message)
    }
}

GM_GetChat() {
    global GM_ChatHwnd, GM_MainGui
    ; 已绑定的窗口优先，支持 Chrome/Edge 安装成应用的 Gemini。
    if (GM_ChatHwnd && WinExist("ahk_id " GM_ChatHwnd))
        return GM_ChatHwnd
    ; 自动寻找标题包含 Gemini 的窗口；若失败，按 Ctrl+Alt+0 手动绑定。
    try {
        active := WinGetID("A")
        if GM_IsGeminiWindow(active)
            return active
    }
    for h in WinGetList() {
        if GM_IsGeminiWindow(h)
            return h
    }
    return 0
}

GM_IsGeminiWindow(h) {
    global GM_MainGui
    if !h || (h = GM_MainGui.Hwnd)
        return false
    try {
        title := StrLower(WinGetTitle("ahk_id " h))
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "explorer.exe" || exe = "chatgpt.exe" || InStr(exe, "autohotkey"))
            return false
        return InStr(title, "gemini") > 0
    }
    return false
}

GM_BindGeminiWindow(*) {
    global GM_ChatHwnd, GM_MainGui
    try {
        h := WinGetID("A")
        if !h || h = GM_MainGui.Hwnd {
            MsgBox("先切换到 Gemini 桌面应用窗口，再按 Ctrl+Alt+0。", "窗口未绑定")
            return
        }
        title := WinGetTitle("ahk_id " h)
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "chatgpt.exe" || exe = "explorer.exe" || InStr(exe, "autohotkey")) {
            MsgBox("当前窗口看起来不是 Gemini，请切换到 Gemini 应用再试。", "绑定失败")
            return
        }
        if !InStr(StrLower(title), "gemini") {
            if MsgBox("当前窗口标题不含 Gemini：`n" title "`n确定把它当作 Gemini 目标窗口吗？", "确认绑定", "YesNo Icon?") != "Yes"
                return
        }
        GM_ChatHwnd := h
        ToolTip("已绑定 Gemini 窗口；现在校准附件＋、上传菜单、输入框")
        SetTimer(() => ToolTip(), -2300)
        GM_UpdateCalibration()
    } catch as e {
        MsgBox("绑定失败：" e.Message)
    }
}

GM_ActivateChat() {
    global GM_ChatHwnd
    h := GM_GetChat()
    if !h
        throw Error("找不到 Gemini 窗口；打开 Gemini 应用，切入目标对话并按 Ctrl+Alt+0 绑定")
    GM_ChatHwnd := h
    WinActivate("ahk_id " h)
    if !WinWaitActive("ahk_id " h, , 5)
        throw Error("无法激活 Gemini 窗口")
    return h
}

GM_Calibrate(which) {
    global GM_PlusX, GM_PlusY, GM_UploadX, GM_UploadY, GM_InputX, GM_InputY, GM_AttachedInputX, GM_AttachedInputY, GM_PrefPath
    h := GM_GetChat()
    if !h {
        MsgBox("先打开 Gemini 桌面端，并按 Ctrl+Alt+0 绑定窗口，再将鼠标悬停在要校准的位置。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx - wx
    ry := my - wy
    if (which = "plus") {
        GM_PlusX := rx, GM_PlusY := ry
        IniWrite(rx, GM_PrefPath, "coords", "plusX")
        IniWrite(ry, GM_PrefPath, "coords", "plusY")
        title := "附件＋号"
    } else if (which = "upload") {
        GM_UploadX := rx, GM_UploadY := ry
        IniWrite(rx, GM_PrefPath, "coords", "uploadX")
        IniWrite(ry, GM_PrefPath, "coords", "uploadY")
        title := "上传文件菜单"
    } else if (which = "attached_input") {
        GM_AttachedInputX := rx, GM_AttachedInputY := ry
        IniWrite(rx, GM_PrefPath, "coords", "attachedInputX")
        IniWrite(ry, GM_PrefPath, "coords", "attachedInputY")
        title := "PDF已附加时的输入框"
    } else {
        GM_InputX := rx, GM_InputY := ry
        IniWrite(rx, GM_PrefPath, "coords", "inputX")
        IniWrite(ry, GM_PrefPath, "coords", "inputY")
        title := "普通聊天输入框"
    }
    GM_UpdateCalibration()
    ToolTip("已保存：" title "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -1800)
}

GM_UpdateCalibration() {
    global GM_CalText, GM_PlusX, GM_UploadX, GM_InputX, GM_AttachedInputX, GM_FreshPlusX, GM_FreshUploadX, GM_FreshInputX, GM_NewChatX
    GM_CalText.Text := "定位状态：附件＋ " (GM_PlusX = "" ? "未设" : "✓")
        . "   上传菜单 " (GM_UploadX = "" ? "未设" : "✓")
        . "   普通输入框 " (GM_InputX = "" ? "未设" : "✓")
        . "   附件输入框 " (GM_AttachedInputX = "" ? "自动估计" : "✓")
        . "`n新对话：附件＋ " (GM_FreshPlusX = "" ? "待校准5" : "✓")
        . "  上传菜单 " (GM_FreshUploadX = "" ? "待校准6" : "✓")
        . "  输入框 " (GM_FreshInputX = "" ? "待校准7" : "✓")
        . "  自动新建 " (GM_NewChatX = "" ? "未校准9" : "✓")
}

GM_ClickChat(which) {
    global GM_InFreshComposer
    global GM_PlusX, GM_PlusY, GM_UploadX, GM_UploadY, GM_InputX, GM_InputY, GM_AttachedInputX, GM_AttachedInputY
    global GM_FreshPlusX, GM_FreshPlusY, GM_FreshUploadX, GM_FreshUploadY, GM_FreshInputX, GM_FreshInputY, GM_FreshAttachedX, GM_FreshAttachedY
    global GM_NewChatX, GM_NewChatY
    h := GM_ActivateChat()
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    if which = "new_chat" {
        rx := GM_NewChatX, ry := GM_NewChatY
    } else if GM_InFreshComposer {
        if which = "plus"
            rx := GM_FreshPlusX, ry := GM_FreshPlusY
        else if which = "upload"
            rx := GM_FreshUploadX, ry := GM_FreshUploadY
        else if which = "attached_input" {
            if GM_FreshAttachedX != "" && GM_FreshAttachedY != ""
                rx := GM_FreshAttachedX, ry := GM_FreshAttachedY
            else if GM_FreshPlusX != "" && GM_FreshPlusY != ""
                rx := Number(GM_FreshPlusX)+145, ry := Number(GM_FreshPlusY)-100
            else
                rx := "", ry := ""
        } else
            rx := GM_FreshInputX, ry := GM_FreshInputY
    } else {
        if which = "plus"
            rx := GM_PlusX, ry := GM_PlusY
        else if which = "upload"
            rx := GM_UploadX, ry := GM_UploadY
        else if which = "attached_input" {
            if GM_AttachedInputX != "" && GM_AttachedInputY != ""
                rx := GM_AttachedInputX, ry := GM_AttachedInputY
            else if GM_PlusX != "" && GM_PlusY != ""
                rx := Number(GM_PlusX)+145, ry := Number(GM_PlusY)-100
            else
                rx := GM_InputX, ry := GM_InputY
        } else
            rx := GM_InputX, ry := GM_InputY
    }
    if rx = "" || ry = ""
        throw Error("当前" (GM_InFreshComposer ? "空白新对话" : "旧对话") "尚未校准：" which "。请使用脚本上方对应快捷键校准。")
    Click(wx+Number(rx), wy+Number(ry))
}

GM_PutClipboard(text) {
    old := ClipboardAll()
    try {
        A_Clipboard := ""
        A_Clipboard := text
        if !ClipWait(3)
            throw Error("写入剪贴板失败")
        Send("^v")
        ; Gemini有时延迟读取粘贴文本，不能过早还原剪贴板。
        Sleep(1100)
    } finally {
        A_Clipboard := old
    }
}

GM_NormalizeGeminiMessage(s) {
    ; 统一浏览器编辑框常见的换行、不可见字符和不换行空格。
    ; 不改动正文标点，避免校验时把合法话语误判成不同内容。
    s := StrReplace(StrReplace(s, "`r`n", "`n"), "`r", "`n")
    s := StrReplace(s, Chr(0xA0), " ")
    s := StrReplace(s, Chr(0x200B), "")
    s := StrReplace(s, Chr(0xFEFF), "")
    return Trim(s, " `t`r`n")
}

GM_GeminiMessagesEquivalent(actual, expected) {
    return GM_NormalizeGeminiMessage(actual) == GM_NormalizeGeminiMessage(expected)
}

GM_WriteGeminiUIAScript() {
    global GM_PrefDir
    path := GM_PrefDir "\Gemini_输入定位_DualV101.ps1"
    ps := ""
    ps .= "param([Int64]$WindowHandle, [string]$Action = 'locate')" "`r`n"
    ps .= "$ErrorActionPreference = 'Stop'" "`r`n"
    ps .= "try {" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationClient" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationTypes" "`r`n"
    ps .= "    $root = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$WindowHandle)" "`r`n"
    ps .= "    if ($null -eq $root) { Write-Output 'ERROR|no-window'; exit 0 }" "`r`n"
    ps .= "    $win = $root.Current.BoundingRectangle" "`r`n"
    ps .= "    $minY = $win.Top + $win.Height * 0.37" "`r`n"
    ps .= "    $scope = [System.Windows.Automation.TreeScope]::Descendants" "`r`n"
    ps .= "    $cond = [System.Windows.Automation.Condition]::TrueCondition" "`r`n"
    ps .= "    if ($Action -eq 'focus') {" "`r`n"
    ps .= "        $el = [System.Windows.Automation.AutomationElement]::FocusedElement" "`r`n"
    ps .= "        $walker = [System.Windows.Automation.TreeWalker]::RawViewWalker" "`r`n"
    ps .= "        for ($depth=0; $depth -lt 7 -and $null -ne $el; $depth++) {" "`r`n"
    ps .= "            try {" "`r`n"
    ps .= "                $type = $el.Current.ControlType.ProgrammaticName" "`r`n"
    ps .= "                $r = $el.Current.BoundingRectangle" "`r`n"
    ps .= "                if (($type -eq 'ControlType.Edit' -or ($type -eq 'ControlType.Document' -and $r.Width -lt $win.Width * 0.95 -and $r.Top -gt $win.Top + $win.Height * 0.30)) -and !$r.IsEmpty -and $r.Width -gt 85 -and $r.Height -gt 14 -and $r.Bottom -gt ($win.Top + $win.Height * 0.30) -and $r.Left -ge $win.Left - 12 -and $r.Right -gt ($win.Left + $win.Width * 0.55) -and $r.Right -le $win.Right + 12) {" "`r`n"
    ps .= "                    Write-Output 'FOCUSOK'; exit 0" "`r`n"
    ps .= "                }" "`r`n"
    ps .= "            } catch {}" "`r`n"
    ps .= "            $el = $walker.GetParent($el)" "`r`n"
    ps .= "        }" "`r`n"
    ps .= "        Write-Output 'FOCUSNONE'; exit 0" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    $all = $root.FindAll($scope, $cond)" "`r`n"
    ps .= "    $items = New-Object 'System.Collections.Generic.List[object]'" "`r`n"
    ps .= "    for ($i=0; $i -lt $all.Count; $i++) {" "`r`n"
    ps .= "        try {" "`r`n"
    ps .= "            $e = $all.Item($i)" "`r`n"
    ps .= "            if ($e.Current.IsOffscreen) { continue }" "`r`n"
    ps .= "            $r = $e.Current.BoundingRectangle" "`r`n"
    ps .= "            if ($r.IsEmpty -or $r.Width -lt 16 -or $r.Height -lt 14) { continue }" "`r`n"
    ps .= "            $type = $e.Current.ControlType.ProgrammaticName" "`r`n"
    ps .= "            $name = [string]$e.Current.Name" "`r`n"
    ps .= "            $cx = ($r.Left + $r.Right) / 2" "`r`n"
    ps .= "            $cy = ($r.Top + $r.Bottom) / 2" "`r`n"
    ps .= "            if ($Action -eq 'locate') {" "`r`n"
    ps .= "                if (($type -ne 'ControlType.Edit' -and !($type -eq 'ControlType.Document' -and $r.Width -lt $win.Width * 0.95 -and $r.Top -gt $win.Top + $win.Height * 0.30)) -or $r.Width -lt 150 -or $r.Bottom -lt $minY -or $r.Right -gt $win.Right + 12) { continue }" "`r`n"
    ps .= "                $score = $r.Bottom / 100.0" "`r`n"
    ps .= "                if ($name -match '(?i)gemini|ask|prompt|message|提问|询问|输入|消息') { $score += 1000 }" "`r`n"
    ps .= "                if ($r.Height -gt 140) { $score -= 30 }" "`r`n"
    ps .= "                $x = [int][Math]::Min($r.Right-38, $r.Left + [Math]::Min(200, $r.Width*0.38))" "`r`n"
    ps .= "                $y = [int][Math]::Max($r.Top+18, $r.Bottom-[Math]::Min(110, $r.Height*0.42))" "`r`n"
    ps .= "                $items.Add([pscustomobject]@{ Score=$score; X=$x; Y=$y })" "`r`n"
    ps .= "            } elseif ($Action -eq 'plus') {" "`r`n"
    ps .= "                if ($cx -gt $win.Left + $win.Width*0.65 -or $cy -lt $win.Top + $win.Height*0.23) { continue }" "`r`n"
    ps .= "                if ($name -match '(?i)^add$|add (files|attachment|photos)|attach|附件|添加文件|添加照片|上传文件|更多|^\+$') {" "`r`n"
    ps .= "                    $score=1000-($cx-$win.Left)*0.2+($cy-$win.Top)*0.05" "`r`n"
    ps .= "                    $items.Add([pscustomobject]@{ Score=$score; X=[int]$cx; Y=[int]$cy })" "`r`n"
    ps .= "                }" "`r`n"
    ps .= "            } elseif ($Action -eq 'upload') {" "`r`n"
    ps .= "                if ($cy -lt $win.Top + $win.Height*0.32 -or $cx -gt $win.Left + $win.Width*0.84) { continue }" "`r`n"
    ps .= "                if ($name -match '(?i)upload (file|from|photo)|upload$|上传文件|上传图片|上传照片|从设备|添加照片和文件|upload files') {" "`r`n"
    ps .= "                    $score=900" "`r`n"
    ps .= "                    if ($type -match 'MenuItem|Button') { $score += 100 }" "`r`n"
    ps .= "                    $items.Add([pscustomobject]@{ Score=$score; X=[int]$cx; Y=[int]$cy })" "`r`n"
    ps .= "                }" "`r`n"
    ps .= "            }" "`r`n"
    ps .= "        } catch { continue }" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    if ($items.Count -gt 0) {" "`r`n"
    ps .= "        $best = @($items | Sort-Object Score -Descending)[0]" "`r`n"
    ps .= "        Write-Output ('POINT|{0}|{1}' -f $best.X,$best.Y)" "`r`n"
    ps .= "    } else { Write-Output 'NOPOINT' }" "`r`n"
    ps .= "} catch {" "`r`n"
    ps .= "    Write-Output ('ERROR|' + ($_.Exception.Message -replace '[|\r\n]',' '))" "`r`n"
    ps .= "}" "`r`n"
    ; 版本化辅助脚本首次生成；无需每次定位都重写，避免杀毒软件文件占用。
    if !FileExist(path)
        FileAppend(ps, path, "UTF-8")
    return path
}

GM_DiagSafe(value) {
    t := StrReplace(StrReplace(String(value), "`r", " "), "`n", " ")
    return SubStr(t, 1, 210)
}

GM_DiagActiveWindow() {
    try {
        h := WinGetID("A")
        exe := WinGetProcessName("ahk_id " h)
        return "hwnd=" h " exe=" exe
    } catch {
        return "active=unknown"
    }
}

GM_DiagLog(tag, info := "") {
    global GM_DebugPath, GM_DebugSeq, GM_DiagSession, GM_Mode, GM_Stage, GM_JobIndex, GM_Jobs
    global GM_InFreshComposer, GM_ChatHwnd, GM_LastDiagProblem
    try {
        GM_DebugSeq += 1
        jobName := GM_JobIndex >= 1 && GM_JobIndex <= GM_Jobs.Length ? GM_Jobs[GM_JobIndex].name : "(none)"
        line := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "." Format("{:03}", Mod(A_TickCount, 1000))
            . " [" GM_DiagSession " #" GM_DebugSeq "] " tag
            . " | job=" GM_JobIndex "/" GM_Jobs.Length "(" GM_DiagSafe(jobName) ") mode=" GM_Mode
            . " stage=" GM_Stage " fresh=" (GM_InFreshComposer ? "yes" : "no")
            . " target_hwnd=" GM_ChatHwnd " " GM_DiagActiveWindow()
            . " | " GM_DiagSafe(info) "`r`n"
        if FileExist(GM_DebugPath) && FileGetSize(GM_DebugPath) > 2500000
            FileMove(GM_DebugPath, GM_DebugPath ".old", 1)
        FileAppend(line, GM_DebugPath, "UTF-8")
        if InStr(tag, "FAIL") || InStr(tag, "ERROR") || InStr(tag, "TIMEOUT")
            GM_LastDiagProblem := tag " | " GM_DiagSafe(info)
    } catch {
        ; 日志写入失败不能阻止既有PDF任务运行。
    }
}

GM_OpenDiagnosticLog(*) {
    global GM_DebugPath
    try {
        if !FileExist(GM_DebugPath)
            FileAppend("Gemini V4.9.5 诊断日志`r`n", GM_DebugPath, "UTF-8")
        Run('notepad.exe "' DebugPath '"')
    } catch as e {
        ToolTip("打开日志失败：" e.Message)
        SetTimer(() => ToolTip(), -2800)
    }
}

GM_CopyDiagnosticSummary(*) {
    global GM_DebugPath, GM_LastDiagProblem
    try {
        if !FileExist(GM_DebugPath)
            throw Error("还没有诊断日志，请先运行一次F8。")
        rawText := FileRead(GM_DebugPath, "UTF-8")
        A_Clipboard := "Gemini V4.9.5 诊断摘要（请检查是否含私人文件名）`r`n最近错误："
            . GM_LastDiagProblem "`r`n------ 末尾日志 ------`r`n" SubStr(rawText, -15000)
        ToolTip("诊断摘要已复制；可粘贴到ChatGPT发给我。")
        SetTimer(() => ToolTip(), -2800)
    } catch as e {
        ToolTip("复制失败：" e.Message)
        SetTimer(() => ToolTip(), -2800)
    }
}

GM_GeminiHiddenPowerShellCapture(script, args, timeoutMs := 10000) {
    global GM_PrefDir
    exe := A_WinDir "\System32\WindowsPowerShell\v1.0\powershell.exe"
    if !FileExist(exe)
        return "ERROR|PowerShell unavailable"
    resultFile := GM_PrefDir "\Gemini_隐藏检测_" A_TickCount "_" Random(10000,99999) ".tmp"
    ; /S /C 后的双引号结构与 Windows cmd.exe 的路径加引号格式匹配。
    cmd := '"' A_ComSpec '" /D /S /C ""' exe '" -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' script '" ' args ' > "' resultFile '" 2>&1"'
    startedAt := A_TickCount
    SplitPath(script, &scriptName)
    GM_DiagLog("PS_START", "script=" scriptName " options=" args " timeout_ms=" timeoutMs)
    try {
        Run(cmd, , "Hide", &childPid)
        GM_DiagLog("PS_PROCESS", "pid=" childPid)
        ; AutoHotkey v2 ProcessWaitClose: 0 = 已关闭（成功），非零PID = 超时仍运行。
        ; 旧版错误地使用 !，使所有正常完成的检测都被当作 UIA timeout。
        waitResult := ProcessWaitClose(childPid, timeoutMs / 1000)
        if (waitResult != 0) {
            try ProcessClose(childPid)
            GM_DiagLog("PS_TIMEOUT", "pid=" childPid " waited_ms=" (A_TickCount-startedAt) " still_running=" waitResult)
            return "ERROR|UIA timeout"
        }
        GM_DiagLog("PS_EXIT_OK", "pid=" childPid " elapsed_ms=" (A_TickCount-startedAt))
        if !FileExist(resultFile) {
            GM_DiagLog("PS_ERROR", "检测进程已退出但没有结果文件 elapsed_ms=" (A_TickCount-startedAt))
            return "ERROR|UIA output missing"
        }
        ; Windows PowerShell 5.1 的控制台重定向使用 OEM 编码；协议关键字均为 ASCII。
        output := Trim(FileRead(resultFile, "CP0"), " `t`r`n")
        GM_DiagLog("PS_RESULT", "elapsed_ms=" (A_TickCount-startedAt) " response=" output)
        return output = "" ? "ERROR|UIA output empty" : output
    } catch as e {
        GM_DiagLog("PS_ERROR", "运行异常 elapsed_ms=" (A_TickCount-startedAt) " " e.Message)
        return "ERROR|" e.Message
    } finally {
        try FileDelete(resultFile)
    }
}

GM_GeminiUIA(action, hwnd) {
    ; UIA 查询不再使用会弹控制台窗口的 WScript.Shell.Exec。
    try {
        script := GM_WriteGeminiUIAScript()
        return GM_GeminiHiddenPowerShellCapture(script, "-WindowHandle " hwnd " -Action " action, 10000)
    } catch as e {
        return "ERROR|" e.Message
    }
}

GM_GeminiUIAPoint(action, hwnd) {
    result := GM_GeminiUIA(action, hwnd)
    GM_DiagLog("UIA_POINT", "action=" action " hwnd=" hwnd " response=" result)
    if !RegExMatch(result, "^POINT\|(-?\d+)\|(-?\d+)$", &m)
        return 0
    return {x: Number(m[1]), y: Number(m[2])}
}

GM_GeminiComposerPoints(withAttachment, hwnd) {
    global GM_InFreshComposer, GM_AttachedInputX, GM_AttachedInputY, GM_FreshAttachedX, GM_FreshAttachedY
    global GM_InputX, GM_InputY, GM_FreshInputX, GM_FreshInputY
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    points := [], seen := Map()
    ; UI Automation会根据当前Gemini窗口的实际编辑框位置重新定位，适配新/旧对话和缩放。
    u := GM_GeminiUIAPoint("locate", hwnd)
    if IsObject(u) {
        points.Push({x:u.x, y:u.y, label:"UIA编辑框", calibrated:false})
        seen[u.x "|" u.y] := true
    }
    ; UIA不可用时只信任用户明确校准的输入框坐标，不向网页猜测位置粘贴探针。
    if GM_InFreshComposer {
        rx := withAttachment ? GM_FreshAttachedX : GM_FreshInputX
        ry := withAttachment ? GM_FreshAttachedY : GM_FreshInputY
    } else {
        rx := withAttachment ? GM_AttachedInputX : GM_InputX
        ry := withAttachment ? GM_AttachedInputY : GM_InputY
    }
    if rx != "" && ry != "" && RegExMatch(String(rx), "^-?\d+$") && RegExMatch(String(ry), "^-?\d+$") {
        ax := wx+Number(rx), ay := wy+Number(ry)
        if ax >= wx+65 && ax <= wx+ww-20 && ay >= wy+wh*0.23 && ay <= wy+wh-20 && !seen.Has(ax "|" ay) {
            points.Push({x:ax, y:ay, label:"人工校准编辑框", calibrated:true})
            seen[ax "|" ay] := true
        }
    }
    ; V4.9.8：绝不跨布局借用另一套手工输入坐标（新对话和旧对话可能位于不同高度）。
    ; 另一布局的落点可能在Gemini历史文本，Ctrl+A会选中整张网页。
    return points
}

GM_GeminiClipboardReadAll() {
    global GM_ChatHwnd
    MergedRequireFocus("gemini", GM_ChatHwnd)
    A_Clipboard := ""
    Send("^a")
    Sleep(180)
    Send("^c")
    if !ClipWait(2)
        return ""
    return GM_NormalizeGeminiMessage(A_Clipboard)
}

GM_SendChatText(message, withAttachment := false) {
    global GM_InFreshComposer, GM_PrefPath, GM_AttachedInputX, GM_AttachedInputY, GM_FreshAttachedX, GM_FreshAttachedY
    global GM_InputX, GM_InputY, GM_FreshInputX, GM_FreshInputY
    if Trim(message) = "" && !withAttachment
        throw Error("不能发送空白话语。")
    onlyPDF := withAttachment && Trim(message) = ""
    hwnd := GM_ActivateChat()
    GM_DiagLog("TEXT_BEGIN", "with_pdf=" (withAttachment ? "yes" : "no") " chars=" StrLen(message))
    points := GM_GeminiComposerPoints(withAttachment, hwnd)
    GM_DiagLog("TEXT_CANDIDATES", "count=" points.Length)
    if points.Length = 0
        throw Error("未找到Gemini实际输入框。请在附件下方校准 Ctrl+Alt+4（新对话Ctrl+Alt+8）。")
    oldClipboard := ClipboardAll()
    try {
        lastReason := ""
        for p in points {
            GM_DiagLog("TEXT_FOCUS_TRY", "source=" p.label " point=" p.x "," p.y)
            GM_ActivateChat()
            Click(p.x, p.y)
            Sleep(300)
            focusState := GM_GeminiUIA("focus", hwnd)
            GM_DiagLog("TEXT_FOCUS_RESULT", "source=" p.label " result=" focusState)
            ; UIA 的 FocusedElement 在附件上传完成后的短暂过渡期可能仍指向旧控件。
            ; 给当前点一次短暂重试，避免偶发 FOCUSNONE 直接中断发送。
            if focusState = "FOCUSNONE" || focusState = "NOPOINT" {
                Sleep(400)
                focusState := GM_GeminiUIA("focus", hwnd)
                GM_DiagLog("TEXT_FOCUS_RETRY", "source=" p.label " result=" focusState)
            }
            ; 手工校准输入框是用户确认过的点：当Electron返回FOCUSNONE/NOPOINT时，
            ; 允许走严格草稿读取、粘贴后Ctrl+C等值核验；核验失败绝不按Enter。
            ; 没有校准的UIA猜测点仍必须得到FOCUSOK。
            manuallyTrusted := p.calibrated && (focusState = "FOCUSNONE" || focusState = "NOPOINT" || SubStr(focusState, 1, 6) = "ERROR|")
            if (focusState != "FOCUSOK" && !manuallyTrusted) {
                lastReason := p.label " 未聚焦到文字编辑框（" focusState "）"
                continue
            }
            if !WinActive("ahk_id " hwnd)
                throw Error("准备读取Gemini草稿前窗口焦点已丢失，已停止发送")
            if manuallyTrusted
                GM_DiagLog("TEXT_MANUAL_FOCUS_FALLBACK", "UIA无法确认焦点，仅信任人工输入坐标并进行完整剪贴板核验")
            ; 不再插入 __AHK_GEMINI_TEXT_CHECK__ 等探针，防止文字污染和误选网页。
            ; 只在通过焦点检查后读取当前草稿；非空且与目标不同则停止，避免覆盖用户草稿。
            existing := GM_GeminiClipboardReadAll()
            GM_DiagLog("TEXT_DRAFT_READ", "current_chars=" StrLen(existing) " expected_chars=" StrLen(GM_NormalizeGeminiMessage(message)))
            if (existing != "" && !GM_GeminiMessagesEquivalent(existing, message)) {
                throw Error("Gemini输入框已有其他草稿，已停止以避免覆盖：" SubStr(existing, 1, 65))
            }
            if !onlyPDF && existing = "" {
                A_Clipboard := ""
                A_Clipboard := message
                if !ClipWait(3)
                    throw Error("剪贴板写入失败")
                SendEvent("^v")
                ; Gemini 上传附件后有时要较长时间把剪贴板内容写入 contenteditable。
                ; 回读最多三次，且允许浏览器重排空白；正文字符不一致仍然停止。
                copied := ""
                pasteMatch := false
                Loop 3 {
                    Sleep(A_Index = 1 ? 900 : 450)
                    copied := GM_GeminiClipboardReadAll()
                    if GM_GeminiMessagesEquivalent(copied, message) {
                        pasteMatch := true
                        break
                    }
                }
                GM_DiagLog("TEXT_PASTE_RESULT", "copied_chars=" StrLen(copied) " expected_chars=" StrLen(GM_NormalizeGeminiMessage(message)) " match=" (pasteMatch ? "yes" : "no"))
                if !pasteMatch
                    throw Error("Gemini文字粘贴后核对不一致，尚未按Enter。请检查附件下方输入框。")
            } else if onlyPDF && existing != "" {
                throw Error("本PDF设置为不发说明，但输入框已有草稿，已停止避免误发送。")
            }
            MergedRequireFocus("gemini", hwnd)
            SendEvent("{End}")
            Sleep(220)
            MergedBeforeSend("gemini", hwnd)
            SendEvent("{Enter}")
            GM_DiagLog("TEXT_ENTER_SENT", "待核实；未推进任务且不会自动再次Enter")
            throw Error("已按Enter，待核实页面是否出现附件和话语；请用主窗口核实按钮继续")
        }
        throw Error("Gemini话语未聚焦到编辑框，未粘贴也未按Enter；" lastReason ". 请在PDF下方校准Ctrl+Alt+4（新对话Ctrl+Alt+8）。")
    } finally {
        A_Clipboard := oldClipboard
    }
}

GM_CalibrateCleanupRemove(*) {
    global GM_PrefPath, GM_InFreshComposer, GM_CleanupRemoveX, GM_CleanupRemoveY
    global GM_FreshCleanupRemoveX, GM_FreshCleanupRemoveY
    h := GM_GetChat()
    if !h {
        MsgBox("请先打开并绑定 Gemini 窗口，再把鼠标指向附件卡片右上角的删除×。", "附件清理校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx-wx, ry := my-wy
    if GM_InFreshComposer {
        GM_FreshCleanupRemoveX := rx, GM_FreshCleanupRemoveY := ry
        key := "freshCleanupRemove"
    } else {
        GM_CleanupRemoveX := rx, GM_CleanupRemoveY := ry
        key := "cleanupRemove"
    }
    IniWrite(String(rx), GM_PrefPath, "coords", key "X")
    IniWrite(String(ry), GM_PrefPath, "coords", key "Y")
    ToolTip("已保存" (GM_InFreshComposer ? "空白新对话" : "已有消息对话") "的残留附件删除×位置")
    SetTimer(() => ToolTip(), -2500)
}

GM_ConfirmSkipCleanupOnce(*) {
    global GM_SkipCleanupOnce
    answer := MsgBox("只有在你已亲眼确认 Gemini 输入框中没有待发送PDF附件时才能跳过。`n这会跳过下一次上传前的残留检测一次，不会清空旧PDF。`n`n确认跳过一次？", "手动跳过检测", "YesNo Icon!")
    if answer = "Yes" {
        GM_SkipCleanupOnce := true
        GM_SetStatus("本次清理检测已由你确认跳过一次；按F8继续，下一份自动恢复检测。")
    }
}

GM_WriteCleanupPowerShell() {
    global GM_PrefDir
    path := GM_PrefDir "\Gemini_附件卡片检测.ps1"
    ps := ""
    ps .= "param(" "`r`n"
    ps .= "    [Int64]$WindowHandle," "`r`n"
    ps .= "    [int]$AnchorX," "`r`n"
    ps .= "    [int]$AnchorY," "`r`n"
    ps .= "    [string]$Action = 'scan'," "`r`n"
    ps .= "    [string]$PriorFile = ''" "`r`n"
    ps .= ")" "`r`n"
    ps .= "$ErrorActionPreference = 'Stop'" "`r`n"
    ps .= "try {" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationClient" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationTypes" "`r`n"
    ps .= "    $root = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$WindowHandle)" "`r`n"
    ps .= "    if ($null -eq $root) { Write-Output 'UNKNOWN|UIA: no window'; exit 0 }" "`r`n"
    ps .= "    $children = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)" "`r`n"
    ps .= "    $matches = New-Object 'System.Collections.Generic.List[object]'" "`r`n"
    ps .= "    $buttons = New-Object 'System.Collections.Generic.List[object]'" "`r`n"
    ps .= "    for ($i=0; $i -lt $children.Count; $i++) {" "`r`n"
    ps .= "        try {" "`r`n"
    ps .= "            $el = $children.Item($i)" "`r`n"
    ps .= "            $r = $el.Current.BoundingRectangle" "`r`n"
    ps .= "            if ($r.IsEmpty -or $r.Width -lt 7 -or $r.Height -lt 7) { continue }" "`r`n"
    ps .= "            $cx = ($r.Left + $r.Right) / 2" "`r`n"
    ps .= "            $cy = ($r.Top + $r.Bottom) / 2" "`r`n"
    ps .= "            # Composer PDF chips appear near the + button. Exclude the sent chat bubble higher up / to the right." "`r`n"
    ps .= "            if ($cx -lt ($AnchorX - 95) -or $cx -gt ($AnchorX + 410)) { continue }" "`r`n"
    ps .= "            if ($cy -lt ($AnchorY - 375) -or $cy -gt ($AnchorY - 65)) { continue }" "`r`n"
    ps .= "            $name = [string]$el.Current.Name" "`r`n"
    ps .= "            if ([string]::IsNullOrWhiteSpace($name)) { continue }" "`r`n"
    ps .= "            $typ = [string]$el.Current.ControlType.ProgrammaticName" "`r`n"
    ps .= "            if ($name -match '(?i)^(pdf|pdf file)$' -and $r.Width -le 150 -and $r.Height -lt 100) {" "`r`n"
    ps .= "                $matches.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name;Score=3})" "`r`n"
    ps .= "            } elseif ($name -match '(?i)\.pdf\b' -and $r.Width -le 440 -and $r.Height -lt 115) {" "`r`n"
    ps .= "                $matches.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name;Score=4})" "`r`n"
    ps .= "            } elseif ($PriorFile -and $name.Contains($PriorFile) -and $r.Width -le 440 -and $r.Height -lt 115) {" "`r`n"
    ps .= "                $matches.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name;Score=5})" "`r`n"
    ps .= "            }" "`r`n"
    ps .= "            if ($name -match '(?i)^(remove|remove file|remove attachment|delete|delete file|close|取消附加|移除|移除附件|删除附件|删除文件|移除文件|关闭|×|✕)$' -and $r.Width -le 90 -and $r.Height -le 90) {" "`r`n"
    ps .= "                $buttons.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name})" "`r`n"
    ps .= "            }" "`r`n"
    ps .= "        } catch { continue }" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    if ($Action -eq 'remove') {" "`r`n"
    ps .= "        if ($buttons.Count -gt 0) {" "`r`n"
    ps .= "            $chosen = @($buttons | Sort-Object @{Expression={ [Math]::Abs($_.Y - ($AnchorY - 305)) + [Math]::Abs($_.X - ($AnchorX + 140)) }})[0]" "`r`n"
    ps .= "            Write-Output ('REMOVE|{0}|{1}|{2}' -f $chosen.X,$chosen.Y,$chosen.Name)" "`r`n"
    ps .= "        } else { Write-Output 'NO_REMOVE' }" "`r`n"
    ps .= "        exit 0" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    if ($matches.Count -gt 0) {" "`r`n"
    ps .= "        $chosen = @($matches | Sort-Object -Property Score -Descending)[0]" "`r`n"
    ps .= "        Write-Output ('FOUND|{0}|{1}|{2}' -f $chosen.X,$chosen.Y,$chosen.Name)" "`r`n"
    ps .= "    } else { Write-Output 'EMPTY' }" "`r`n"
    ps .= "} catch {" "`r`n"
    ps .= "    Write-Output ('UNKNOWN|' + ($_.Exception.Message -replace '[|\r\n]',' '))" "`r`n"
    ps .= "}" "`r`n"
    if !FileExist(path)
        FileAppend(ps, path, "UTF-8")
    return path
}

GM_CleanupAnchor() {
    global GM_InFreshComposer, GM_FreshPlusX, GM_FreshPlusY, GM_PlusX, GM_PlusY
    h := GM_ActivateChat()
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " h)
    if GM_InFreshComposer {
        rx := GM_FreshPlusX, ry := GM_FreshPlusY
    } else {
        rx := GM_PlusX, ry := GM_PlusY
    }
    if rx = "" || ry = ""
        throw Error("附件检测需要先校准当前对话的＋按钮位置（旧对话Ctrl+Alt+1，新对话Ctrl+Alt+5）")
    return {h: h, x: wx + Number(rx), y: wy + Number(ry), wx:wx, wy:wy, w:ww, hgt:wh}
}

GM_RunCleanupUIA(action, anchor, priorName := "") {
    ; 与 GM_GeminiUIA 使用同一种隐藏执行方式：检测到残留时也不会弹终端。
    try {
        script := GM_WriteCleanupPowerShell()
        result := GM_GeminiHiddenPowerShellCapture(script,
            "-WindowHandle " anchor.h " -AnchorX " anchor.x " -AnchorY " anchor.y " -Action " action, 10000)
        GM_DiagLog("CLEAN_UIA", "action=" action " response=" result)
        return SubStr(result, 1, 6) = "ERROR|" ? "UNKNOWN|" result : result
    } catch as e {
        return "UNKNOWN|" e.Message
    }
}

GM_ColorDelta(c1, c2) {
    return Abs((c1 >> 16 & 255)-(c2 >> 16 & 255))
        + Abs((c1 >> 8 & 255)-(c2 >> 8 & 255))
        + Abs((c1 & 255)-(c2 & 255))
}

GM_DetectAttachmentPixel(anchor) {
    ; Gemini PDF卡片位于底部＋按钮上方约170~310像素，左边灰色方块在＋按钮右侧。
    ; 同时要求相邻两个采样点颜色近似、并与卡片外部背景明显不同，减少误报。
    bgx := anchor.x + 315
    if bgx >= anchor.wx + anchor.w - 24
        return false
    strongRows := 0
    for height in [175, 195, 215, 235, 255, 275, 295] {
        y := anchor.y-height
        x := anchor.x+76
        if x < anchor.wx+12 || x+46 >= anchor.wx+anchor.w-22
            continue
        if y-14 < anchor.wy+12 || y+14 >= anchor.wy+anchor.hgt-18
            continue
        try {
            c1 := PixelGetColor(x,y,"RGB")
            c2 := PixelGetColor(x+16,y,"RGB")
            c3 := PixelGetColor(x+34,y,"RGB")
            bg1 := PixelGetColor(bgx,y,"RGB")
            bg2 := PixelGetColor(bgx,y+11,"RGB")
            if GM_ColorDelta(c1,c2) <= 33 && GM_ColorDelta(c2,c3) <= 33
                && GM_ColorDelta(c1,bg1) >= 40 && GM_ColorDelta(bg1,bg2) <= 40
                strongRows += 1
        } catch {
            continue
        }
    }
    return strongRows >= 2
}

GM_CleanupInt(value) {
    value := Trim(String(value))
    return RegExMatch(value,"^-?\d+$") ? Number(value) : ""
}

GM_InspectComposerAttachment(anchor) {
    result := GM_RunCleanupUIA("scan",anchor)
    parts := StrSplit(result,"|")
    if parts.Length >= 3 && parts[1] = "FOUND" {
        cx := GM_CleanupInt(parts[2]), cy := GM_CleanupInt(parts[3])
        if cx != "" && cy != ""
            && cx >= anchor.x-95 && cx <= anchor.x+410
            && cy >= anchor.y-385 && cy <= anchor.y-55
            return {state:"FOUND",x:cx,y:cy,method:"UIA"}
    }
    ; UIA对Gemini的卡片有时不会返回可访问的文字，用视觉二次确认。
    if GM_DetectAttachmentPixel(anchor)
        return {state:"FOUND",x:anchor.x+90,y:anchor.y-235,method:"像素多点"}
    if parts[1] = "EMPTY"
        return {state:"EMPTY",method:"UIA及像素"}
    return {state:"UNKNOWN",reason:result}
}

GM_GetCalibratedRemovePoint(anchor) {
    global GM_InFreshComposer, GM_CleanupRemoveX, GM_CleanupRemoveY, GM_FreshCleanupRemoveX, GM_FreshCleanupRemoveY
    if GM_InFreshComposer {
        rx := GM_FreshCleanupRemoveX, ry := GM_FreshCleanupRemoveY
    } else {
        rx := GM_CleanupRemoveX, ry := GM_CleanupRemoveY
    }
    if rx = "" || ry = ""
        return false
    x := anchor.wx+Number(rx), y := anchor.wy+Number(ry)
    ; 坐标必须落在输入框附件所在的小区域，禁止误按到聊天历史或导航。
    if x < anchor.x-85 || x > anchor.x+315 || y < anchor.y-375 || y > anchor.y-65
        throw Error("保存的附件删除×坐标不在输入框附件区域，请重新悬停在×上按Ctrl+Shift+Alt+R")
    return {x:x, y:y}
}

GM_CleanupPendingAttachments() {
    global GM_SkipCleanupOnce
    if GM_SkipCleanupOnce {
        GM_SkipCleanupOnce := false
        GM_WriteLog("V4.8：用户跳过一次残留检测，继续发送")
        return true
    }
    ; 不要因检测失败而中断整个批次：用户要求残留清理尽力而为，最后继续上传。
    try {
        anchor := GM_CleanupAnchor()
        GM_DiagLog("CLEAN_START", "anchor=" anchor.x "," anchor.y " window=" anchor.w "x" anchor.hgt)
    } catch as e {
        GM_WriteLog("V4.8：无法取得附件检查区域，已跳过清理并继续：" e.Message)
        return false
    }
    cleanCount := 0, unknownCount := 0, foundCount := 0, removalCount := 0
    ; 同一轮内至少二次确认EMPTY，避免Gemini界面短暂变化造成一次漏检。
    ; 有残留则多轮尝试；最多7轮，避免被清理卡住而无法执行后续PDF。
    Loop 7 {
        try {
            pending := GM_InspectComposerAttachment(anchor)
            GM_DiagLog("CLEAN_SCAN", "round=" A_Index " state=" pending.state " method=" (pending.HasOwnProp("method") ? pending.method : "unknown") " extra=" (pending.HasOwnProp("reason") ? pending.reason : ""))
        } catch as e {
            pending := {state:"UNKNOWN",reason:e.Message}
        }
        if pending.state = "EMPTY" {
            cleanCount += 1
            if cleanCount >= 2 {
                GM_WriteLog("V4.8：连续两次未检测到残留附件，继续上传；删除尝试=" removalCount)
                return true
            }
            Sleep(380)
            continue
        }
        cleanCount := 0
        if pending.state = "UNKNOWN" {
            unknownCount += 1
            ; 检测程序无法访问 Gemini 时最多重试三次，不再执行7次完整轮询。
            ; 依照用户原有要求：记录警告后继续上传，不因清理失败暂停。
            if unknownCount >= 3 && foundCount = 0 {
                GM_WriteLog("V4.9.4：附件状态连续3次无法识别，跳过本次清理继续上传：" pending.reason)
                return false
            }
            Sleep(440)
            continue
        }
        foundCount += 1
        GM_SetStatus("V4.8：检测到可能的旧PDF，自动第" foundCount "次清理并复查（总共至多7轮）……")
        try {
            GM_ActivateChat()
            MouseMove(pending.x,pending.y,0)
            Sleep(550) ; 让附件卡片右上角隐藏的×出现
            output := GM_RunCleanupUIA("remove",anchor)
            parts := StrSplit(output,"|")
            chosen := false
            if parts.Length >= 3 && parts[1] = "REMOVE" {
                rx := GM_CleanupInt(parts[2]), ry := GM_CleanupInt(parts[3])
                if rx != "" && ry != ""
                    && Abs(rx-pending.x) <= 240 && Abs(ry-pending.y) <= 175
                    && rx >= anchor.x-95 && rx <= anchor.x+410
                    && ry >= anchor.y-390 && ry <= anchor.y-60
                    chosen := {x:rx,y:ry,source:"UIA"}
            }
            ; UIA不能找到×时，使用用户校准的专属删除坐标；位置验证失败也不暂停。
            if !IsObject(chosen) {
                try chosen := GM_GetCalibratedRemovePoint(anchor)
                catch as e {
                    GM_WriteLog("V4.8：校准删除位置不可用：" e.Message)
                    chosen := false
                }
                if IsObject(chosen)
                    chosen.source := "校准点"
            }
            if IsObject(chosen) {
                Click(chosen.x,chosen.y)
                removalCount += 1
                GM_WriteLog("V4.8：第" removalCount "次尝试点击旧附件删除×（" chosen.source "）")
                Sleep(1050)
            } else {
                GM_WriteLog("V4.8：发现疑似旧附件，但本轮未获得可用删除×；继续复查")
                Sleep(550)
            }
        } catch as e {
            GM_WriteLog("V4.8：本轮附件清理出现异常但不会暂停：" e.Message)
            Sleep(450)
        }
    }
    ; 最终多核一次：结果不确定或清理不了，记录警告但不throw、不修改进度。
    try {
        last := GM_InspectComposerAttachment(anchor)
        if last.state = "EMPTY" {
            Sleep(380)
            last2 := GM_InspectComposerAttachment(anchor)
            if last2.state = "EMPTY" {
                GM_WriteLog("V4.8：最终复查两次均无旧附件，继续上传")
                return true
            }
        }
        GM_WriteLog("V4.8 警告：清理后可能还有旧PDF（" last.state "），已尝试删除" removalCount "次，按不中断要求继续上传下一份PDF")
    } catch as e {
        GM_WriteLog("V4.8 警告：附件复查异常；按不中断要求继续上传：" e.Message)
    }
    return false
}

GM_GeminiVisibleDialogs() {
    seen := Map()
    for d in WinGetList("ahk_class #32770") {
        try {
            if DllCall("User32\IsWindowVisible", "Ptr", d, "Int")
                seen[d] := true
        }
    }
    return seen
}

GM_GeminiWaitNewPicker(geminiHwnd, prior, timeoutMs := 4500) {
    ; 只认可点击后新出现的公共文件选择窗口，不能将已存在的其他应用对话框误认作成功。
    started := A_TickCount
    geminiPID := WinGetPID("ahk_id " geminiHwnd)
    Loop {
        for d in WinGetList("ahk_class #32770") {
            try {
                if prior.Has(d) || !DllCall("User32\IsWindowVisible", "Ptr", d, "Int")
                    continue
                dialogPID := WinGetPID("ahk_id " d)
                ; 原生Windows文件选择窗口通常归Gemini进程所有；跨进程时还须真正位于前台。
                if (dialogPID != geminiPID && !WinActive("ahk_id " d))
                    continue
                GM_DiagLog("PICKER_DISCOVERED", "hwnd=" d " pid=" dialogPID " gemini_pid=" geminiPID)
                return d
            }
        }
        if A_TickCount - started >= timeoutMs
            break
        Sleep(170)
    }
    return 0
}

GM_GeminiWindowGeometry(hwnd) {
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    dpi := "unknown"
    try dpi := DllCall("User32\GetDpiForWindow", "Ptr", hwnd, "UInt")
    GM_DiagLog("WINDOW_GEOMETRY", "hwnd=" hwnd " x=" wx " y=" wy " w=" ww " h=" wh " dpi=" dpi " screen=" A_ScreenWidth "x" A_ScreenHeight)
    return {x:wx,y:wy,w:ww,h:wh}
}

GM_GeminiPointBelongsToWindow(hwnd, x, y) {
    ; MouseGetPos 的坐标与 CoordMode Mouse Screen 完全一致；越界坐标不点击。
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    if x < wx+2 || y < wy+2 || x >= wx+ww-2 || y >= wy+wh-2
        return false
    ; 位置可能被其他置顶软件遮挡，尽量不要误点击它。
    MouseMove(x, y, 0)
    Sleep(100)
    MouseGetPos(, , &hoveredHwnd)
    if !hoveredHwnd
        return false
    try {
        if hoveredHwnd = hwnd || WinGetPID("ahk_id " hoveredHwnd) = WinGetPID("ahk_id " hwnd)
            return true
        ; 允许 WebView 子窗口（进程不同但顶层祖先仍属于Gemini窗口）。
        root := DllCall("User32\GetAncestor", "Ptr", hoveredHwnd, "UInt", 2, "Ptr")
        if root = hwnd
            return true
    }
    return false
}

GM_GeminiMenuPixelSignature(x, y) {
    ; 取菜单文字附近多点颜色，仅用于辅助诊断，不用颜色结果冒险猜新的点击位置。
    values := []
    for dy in [-25,-8,8,25] {
        for dx in [-60,-25,10,45,80] {
            try {
                values.Push(PixelGetColor(x+dx, y+dy, "RGB"))
            } catch {
                values.Push("")
            }
        }
    }
    return values
}

GM_GeminiPixelDifferences(before, after) {
    different := 0, available := 0
    Loop Min(before.Length, after.Length) {
        i := A_Index
        if before[i] != "" && after[i] != "" {
            available += 1
            if GM_ColorDelta(before[i], after[i]) >= 42
                different += 1
        }
    }
    return {changed:different,total:available}
}

GM_GeminiClickUploadAndWait(hwnd, x, y, label) {
    global GM_InFreshComposer, GM_FreshUploadX, GM_FreshUploadY, GM_UploadX, GM_UploadY, GM_LastUploadProbe
    GM_LastUploadProbe := "点击前"
    GM_DiagLog("UPLOAD_PLUS_BEFORE", "point=" x "," y " candidate=" label " target=" hwnd)
    GM_ActivateChat()
    geom := GM_GeminiWindowGeometry(hwnd)
    rx := GM_InFreshComposer ? GM_FreshUploadX : GM_UploadX
    ry := GM_InFreshComposer ? GM_FreshUploadY : GM_UploadY
    if !GM_GeminiCoordSet(rx, ry) {
        GM_DiagLog("UPLOAD_MENU_NOT_CALIBRATED", "profile=" (GM_InFreshComposer ? "fresh" : "old"))
        return 0
    }
    mx := geom.x + Number(rx), my := geom.y + Number(ry)
    if mx < geom.x+4 || my < geom.y+4 || mx >= geom.x+geom.w-4 || my >= geom.y+geom.h-4
        throw Error("上传菜单校准坐标已超出Gemini窗口。窗口移动/尺寸改变后请核对当前布局的校准点。")
    GM_DiagLog("UPLOAD_MENU_TARGET", "rel=" rx "," ry " abs=" mx "," my " delta_from_plus=" mx-x "," my-y)
    prior := GM_GeminiVisibleDialogs()
    ; 优先先消除旧弹层，后检查目标处于当前Gemini窗口，而不是盲目点击。
    SendEvent("{Esc}")
    Sleep(230)
    GM_ActivateChat()
    if !GM_GeminiPointBelongsToWindow(hwnd, x, y) {
        GM_DiagLog("UPLOAD_PLUS_BLOCKED", "plus=" x "," y " 当前点不属于已绑定Gemini窗口")
        throw Error("附件＋位置被其他窗口遮挡或坐标已失效；已中止点击，保护任务。")
    }
    pre := GM_GeminiMenuPixelSignature(mx, my)
    ; SendEvent 释放热键修饰键并逐次投递鼠标动作；部分Electron页面对SendInput点击不敏感。
    SendEvent("{Click " x " " y "}")
    Sleep(950)
    GM_DiagLog("UPLOAD_PLUS_AFTER", "point=" x "," y " source=" label " active=" GM_DiagActiveWindow())
    post := GM_GeminiMenuPixelSignature(mx, my)
    delta := GM_GeminiPixelDifferences(pre, post)
    GM_LastUploadProbe := "菜单附近像素变化 " delta.changed "/" delta.total
    GM_DiagLog("UPLOAD_MENU_APPEARANCE", "pixel_changed=" delta.changed "/" delta.total " (参考诊断，不能单凭像素证明菜单已打开)")
    if !WinActive("ahk_id " hwnd) {
        GM_DiagLog("UPLOAD_FOCUS_LOST", "after_plus=" GM_DiagActiveWindow())
        return GM_GeminiWaitNewPicker(hwnd, prior, 800)
    }
    ; 多点像素均不变时，可能根本没打开菜单。此时不盲点已保存位置。
    ; 像素只作为保护性启发式；不宣称绝对识别了Gemini菜单。
    if delta.total >= 12 && delta.changed = 0 {
        GM_DiagLog("UPLOAD_MENU_UNCHANGED", "校准菜单位置附近未发现显著变化；跳过可能误击")
    } else if !GM_GeminiPointBelongsToWindow(hwnd, mx, my) {
        GM_DiagLog("UPLOAD_MENU_BLOCKED", "target=" mx "," my " 非Gemini窗口")
        return 0
    } else {
        GM_DiagLog("UPLOAD_MENU_MANUAL", "rel=" rx "," ry " abs=" mx "," my)
        SendEvent("{Click " mx " " my "}")
        dialog := GM_GeminiWaitNewPicker(hwnd, prior, 5000)
        if dialog {
            GM_DiagLog("UPLOAD_DIALOG_MANUAL", "dialog_hwnd=" dialog)
            return dialog
        }
        GM_DiagLog("UPLOAD_NO_DIALOG_MANUAL", "point=" mx "," my " active=" GM_DiagActiveWindow())
    }
    ; 人工菜单未命中时再重新展开 +，仅查找一次可访问菜单，不乱点周边图标。
    try {
        GM_ActivateChat()
        SendEvent("{Esc}")
        Sleep(220)
        if GM_GeminiPointBelongsToWindow(hwnd, x, y) {
            SendEvent("{Click " x " " y "}")
            Sleep(650)
            p := GM_GeminiUIAPoint("upload", hwnd)
            if IsObject(p) && GM_GeminiPointBelongsToWindow(hwnd, p.x, p.y) {
                GM_DiagLog("UPLOAD_MENU_UIA_FALLBACK", "point=" p.x "," p.y)
                SendEvent("{Click " p.x " " p.y "}")
                dialog := GM_GeminiWaitNewPicker(hwnd, prior, 4500)
                if dialog
                    return dialog
            } else
                GM_DiagLog("UPLOAD_MENU_UIA_MISS", "未找到菜单，停止盲点")
        }
    } catch as e {
        GM_DiagLog("UPLOAD_MENU_UIA_ERROR", e.Message)
    }
    return 0
}

GM_GeminiPlusCandidates(hwnd, useUIA := false) {
    global GM_InFreshComposer, GM_PlusX, GM_PlusY, GM_FreshPlusX, GM_FreshPlusY
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    points := [], seen := Map()
    ; 旧版保存的+按钮优先，UIA识别按钮兜底，避免触摸菜单外的错误位置。
    rx := GM_InFreshComposer ? GM_FreshPlusX : GM_PlusX
    ry := GM_InFreshComposer ? GM_FreshPlusY : GM_PlusY
    if rx != "" && ry != "" && RegExMatch(String(rx), "^-?\d+$") && RegExMatch(String(ry), "^-?\d+$") {
        x := wx+Number(rx), y := wy+Number(ry)
        ; 空白新对话输入区通常位于页面中部，不能套用旧对话“下半屏55%”过滤。
        minY := GM_InFreshComposer ? wy+wh*0.22 : wy+wh*0.50
        if x >= wx+5 && x <= wx+ww*0.80 && y >= minY && y <= wy+wh-8 {
            points.Push({x:x,y:y,label:"人工校准+"})
            seen[x "|" y] := true
        }
    }
    if useUIA || points.Length = 0 {
        p := GM_GeminiUIAPoint("plus", hwnd)
        if IsObject(p) && !seen.Has(p.x "|" p.y) {
            points.Push({x:p.x,y:p.y,label:"UIA定位+"})
            seen[p.x "|" p.y] := true
        }
    }
    ; 不能跨布局借用坐标：新对话的＋在另一位置，旧坐标导致点不到附件。
    ; 特别禁止 fresh=yes 时把旧 GM_PlusX 当作候选。（用户日志证实此错误。）
    GM_DiagLog("PLUS_CANDIDATES", "count=" points.Length " window_pos=" wx "," wy " size=" ww "x" wh)
    for p in points
        GM_DiagLog("PLUS_CANDIDATE", "source=" p.label " point=" p.x "," p.y)
    return points
}

GM_GeminiCoordSet(x, y) {
    return x != "" && y != "" && RegExMatch(String(x), "^-?\d+$") && RegExMatch(String(y), "^-?\d+$")
}

GM_GeminiValidateUploadCalibration() {
    global GM_InFreshComposer, GM_FreshPlusX, GM_FreshPlusY, GM_FreshUploadX, GM_FreshUploadY
    global GM_PlusX, GM_PlusY, GM_UploadX, GM_UploadY, GM_Stage, GM_Jobs, GM_JobIndex
    ; 只有当前任务真的需要上传时检查；不影响已附加附件的 upload_ready 重试。
    if GM_Stage != "upload" || GM_JobIndex > GM_Jobs.Length || GM_Jobs[GM_JobIndex].path = ""
        return true
    if GM_InFreshComposer {
        if !GM_GeminiCoordSet(GM_FreshPlusX, GM_FreshPlusY) || !GM_GeminiCoordSet(GM_FreshUploadX, GM_FreshUploadY) {
            GM_DiagLog("CALIBRATION_MISSING", "fresh=yes freshPlus=" GM_GeminiCoordSet(GM_FreshPlusX, GM_FreshPlusY) " freshUpload=" GM_GeminiCoordSet(GM_FreshUploadX, GM_FreshUploadY))
            throw Error("当前是【空白新对话】，但未完整保存新对话的附件坐标。`n请把鼠标放在新对话＋号上按 Ctrl+Alt+5；手动点开＋菜单，鼠标移到【上传文件】按 Ctrl+Alt+6。`n然后在高级设置点击【测试上传按钮】，成功后按F8。`n不会使用旧对话坐标冒险点击，也不会清空PDF任务。")
        }
    } else if !GM_GeminiCoordSet(GM_PlusX, GM_PlusY) || !GM_GeminiCoordSet(GM_UploadX, GM_UploadY) {
        GM_DiagLog("CALIBRATION_MISSING", "fresh=no plus=" GM_GeminiCoordSet(GM_PlusX, GM_PlusY) " upload=" GM_GeminiCoordSet(GM_UploadX, GM_UploadY))
        throw Error("当前是【已有消息的旧对话】，请先分别按 Ctrl+Alt+1 校准附件＋、Ctrl+Alt+2 校准【上传文件】菜单，再测试上传按钮。")
    }
    return true
}

GM_TestGeminiUploadPicker(*) {
    global GM_Busy, GM_Running, GM_InFreshComposer, GM_StartProfileBox, GM_MainGui, GM_AdvancedGui
    global GM_FreshPlusX, GM_FreshPlusY, GM_FreshUploadX, GM_FreshUploadY
    global GM_PlusX, GM_PlusY, GM_UploadX, GM_UploadY, GM_LastUploadProbe, GM_TestResultText
    if GM_Running || GM_Busy {
        GM_SetStatus("请先按 F9 暂停，再测试附件菜单；不会清除任务或进度。")
        return
    }
    oldProfile := GM_InFreshComposer
    GM_Busy := true
    try {
        GM_InFreshComposer := GM_StartProfileBox.Value = 2
        ; 点击测试前暂时隐藏两个置顶脚本窗口，避免它们挡住 Gemini ＋按钮和上传菜单。
        GM_AdvancedGui.Hide()
        GM_MainGui.Hide()
        Sleep(180)
        ; 不通过UIA或者另一种布局的备用坐标；只使用本布局的校准点。
        h := GM_ActivateChat()
        if GM_InFreshComposer {
            if !GM_GeminiCoordSet(GM_FreshPlusX, GM_FreshPlusY) || !GM_GeminiCoordSet(GM_FreshUploadX, GM_FreshUploadY)
                throw Error("新对话缺少专属＋/上传菜单校准。请按 Ctrl+Alt+5 和 Ctrl+Alt+6。")
            px := Number(GM_FreshPlusX), py := Number(GM_FreshPlusY)
        } else {
            if !GM_GeminiCoordSet(GM_PlusX, GM_PlusY) || !GM_GeminiCoordSet(GM_UploadX, GM_UploadY)
                throw Error("旧对话缺少＋/上传菜单校准。请按 Ctrl+Alt+1 和 Ctrl+Alt+2。")
            px := Number(GM_PlusX), py := Number(GM_PlusY)
        }
        WinGetPos(&wx, &wy,,, "ahk_id " h)
        dialog := GM_GeminiClickUploadAndWait(h, wx+px, wy+py, "校准测试")
        if !dialog
            throw Error("没有打开文件选择窗口。诊断：" GM_LastUploadProbe "。请核对实际弹出的菜单位置；仅在位置确实改变时重新校准上传菜单。")
        GM_DiagLog("CALIBRATION_TEST_OK", "dialog=" dialog " profile=" (GM_InFreshComposer ? "fresh" : "old"))
        ; 测试只开文件窗口，按 Escape 退出，不选择或发送任何文件。
        WinActivate("ahk_id " dialog)
        Sleep(220)
        SendEvent("{Esc}")
        if !WinWaitClose("ahk_id " dialog, , 3)
            throw Error("文件选择窗口已成功打开，但测试未能自动取消；请手动按Esc关闭后再测试。")
        GM_SetStatus("✓ 已实测打开并取消文件选择窗口；没有上传PDF，也没有修改任务与进度。")
        GM_TestResultText.Text := "测试成功：文件选择窗口确实出现且已取消。可以在现有任务上继续。"
    } catch as e {
        GM_DiagLog("CALIBRATION_TEST_FAIL", e.Message)
        GM_SetStatus("⚠ 附件校准测试失败：" e.Message)
        GM_TestResultText.Text := "测试失败：" SubStr(e.Message, 1, 150)
    } finally {
        GM_InFreshComposer := oldProfile
        GM_Busy := false
        GM_MainGui.Show()
        GM_AdvancedGui.Show()
    }
}

GM_AttachPDF(path) {
    global GM_LastUploadProbe, GM_Stage
    SplitPath(path, &pdfName)
    GM_DiagLog("UPLOAD_BEGIN", "pdf=" pdfName " exists=" (FileExist(path) ? "yes" : "no"))
    if !FileExist(path)
        throw Error("PDF文件不存在：" path)
    GM_GeminiValidateUploadCalibration()
    h := GM_ActivateChat()
    points := GM_GeminiPlusCandidates(h)
    if points.Length = 0
        throw Error("无法定位Gemini附件＋按钮，请先校准 Ctrl+Alt+1（空白新对话 Ctrl+Alt+5）。")
    dialog := 0
    ; 先使用现有手工坐标；失败后才扩充一次UIA + 号候选。
    ; 当前对话与新对话坐标分别保存，避免 UIA 始终阻断人工已校准路径。
    Loop 2 {
        round := A_Index
        ; 当前 Gemini.exe 的 UIA 对 +/菜单始终返回 NOPOINT：无须第二轮反复调用PowerShell。
        ; 只对用户校准过的准确坐标重试一次。
        GM_DiagLog("UPLOAD_ROUND", "round=" round " candidates=" points.Length)
        for p in points {
            dialog := GM_GeminiClickUploadAndWait(h, p.x, p.y, p.label)
            if dialog
                break
        }
        if dialog
            break
        Sleep(550)
    }
    if !dialog {
        GM_DiagLog("UPLOAD_FAIL", "校准点击和一次UIA检查均未打开文件窗口；" GM_LastUploadProbe)
        throw Error("没有打开Gemini文件选择窗口：" GM_LastUploadProbe "。请先使用【测试上传按钮】确认实际菜单是否展开，再核对本布局＋/上传菜单位置。未上传PDF，未推进进度。")
    }
    GM_DiagLog("UPLOAD_FILE_DIALOG", "dialog_hwnd=" dialog " pdf=" pdfName)
    target := "ahk_id " dialog
    WinActivate(target)
    if !WinWaitActive(target, , 3)
        throw Error("文件选择窗口未取得焦点，已停止以防PDF路径进入Gemini文本框")
    ; Windows 11 / Electron通用文件窗口的文件名栏可能不是 Edit1，优先Alt+N。
    ; 用户指定文件的绝对路径在对话框前台粘贴，不直接操作聊天编辑框。
    oldClipboard := ClipboardAll()
    try {
        SendEvent("!n")
        Sleep(350)
        A_Clipboard := path
        if !ClipWait(3)
            throw Error("写入PDF路径到剪贴板失败")
        SendEvent("^a")
        SendEvent("^v")
        Sleep(350)
        if !WinActive(target)
            throw Error("文件选择窗口意外失去焦点，取消后续提交")
        SendEvent("{Enter}")
    } finally {
        A_Clipboard := oldClipboard
    }
    if !WinWaitClose(target, , 16) {
        GM_DiagLog("UPLOAD_FAIL", "文件选择窗口没有在16秒内关闭")
        throw Error("文件选择窗口未关闭，未确认PDF已附加")
    }
    GM_DiagLog("UPLOAD_DIALOG_CLOSED", "文件选择窗口关闭；此处尚不能证明Gemini已接收附件")
    GM_Stage := "upload_ready"
    GM_SaveProgress()
    Sleep(12000) ; 保留原有上传准备时间，适合较大的PDF。
}

GM_ToChinese(n) {
    chars := ["零","一","二","三","四","五","六","七","八","九"]
    if (n < 10)
        return chars[n+1]
    if (n < 20)
        return "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 100)
        return chars[Floor(n/10)+1] "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 1000) {
        r := Mod(n, 100)
        return chars[Floor(n/100)+1] "百" (r = 0 ? "" : (r < 10 ? "零" chars[r+1] : GM_ToChinese(r)))
    }
    return String(n)
}

GM_ParseQuestions(spec, lineNo) {
    result := []
    seen := Map()
    for item in StrSplit(StrReplace(spec, "，", ","), ",") {
        item := Trim(item)
        if item = ""
            continue
        item := StrReplace(StrReplace(item, "—", "-"), "–", "-")
        if RegExMatch(item, "^\d+$") {
            n := Number(item)
            if (n < 1 || n > 9999)
                throw Error("第" lineNo "行题号超出范围")
            if !seen.Has(n) {
                result.Push(n)
                seen[n] := true
            }
        } else if RegExMatch(item, "^\d+\s*-\s*\d+$") {
            segments := StrSplit(item, "-")
            a := Number(Trim(segments[1]))
            b := Number(Trim(segments[2]))
            if (a < 1 || a > b || b > 9999 || b-a > 500)
                throw Error("第" lineNo "行题号范围无效或过大：" item)
            Loop b-a+1 {
                n := a+A_Index-1
                if !seen.Has(n) {
                    result.Push(n)
                    seen[n] := true
                }
            }
        } else
            throw Error("第" lineNo "行的题号格式错误：" item)
    }
    if !result.Length
        throw Error("第" lineNo "行没有有效题号")
    return result
}

GM_ManifestId(src) {
    ; 用于防止任务清单变更后误用旧进度。轻量非安全哈希。
    h := 2166136261
    Loop Parse src {
        h := Mod(((h ^ Ord(A_LoopField)) * 16777619), 4294967296)
    }
    return Format("{:08X}", h)
}

GM_ReloadJobs(*) {
    global GM_Busy
    if GM_Busy
        return
    global GM_Jobs, GM_TaskPath, GM_Signature, GM_Running, GM_Busy, GM_CountText, GM_Mode, GM_UploadIntroGui, GM_StatePath
    if GM_Running || GM_Busy {
        MsgBox("请先按 F9 暂停，并等待当前发送操作结束，再刷新任务。")
        return
    }
    raw := FileRead(GM_TaskPath, "UTF-8")
    freshJobs := []
    lineNo := 0
    for line in StrSplit(raw, "`n") {
        lineNo++
        line := Trim(line, " `t`r`n")
        if (line = "" || SubStr(line, 1, 1) = "#")
            continue
        msgs := []
        if GM_Mode = "questions" {
            parts := StrSplit(line, "|")
            if (parts.Length != 2)
                throw Error("任务清单第" lineNo "行须用 | 分隔PDF路径和题号")
            path := Trim(parts[1], " `t`r`n" Chr(34))
            if !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            qs := GM_ParseQuestions(Trim(parts[2]), lineNo)
            SplitPath(path, &name)
        } else if (GM_Mode = "custom" || GM_Mode = "together") {
            parts := StrSplit(line, "|")
            if parts.Length < 2
                throw Error("自定义任务第" lineNo "行缺少话语。请用【管理每份PDF的话语】编辑。")
            path := GM_UnescapeCustomField(parts[1])
            if path = "@NO_PDF"
                path := ""
            if path != "" && !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            if GM_Mode = "together" && path = ""
                throw Error("功能三必须指定真实PDF：第" lineNo "行")
            name := "当前对话（无需上传PDF）"
            if path != ""
                SplitPath(path, &name)
            Loop parts.Length - 1 {
                message := GM_UnescapeCustomField(parts[A_Index + 1])
                if GM_Mode = "custom" && parts.Length = 2 && (parts[2] = "%00" || parts[2] = "")
                    continue  ; 功能二无后续话语的明确空白状态，兼容早期结尾|

                if Trim(message) = ""
                    throw Error("自定义任务第" lineNo "行有空话语")
                msgs.Push(message)
            }
            if GM_Mode = "together" && msgs.Length != 1
                throw Error("功能三第" lineNo "行必须恰好设置一句话")
            qs := []
            Loop msgs.Length
                qs.Push(A_Index)
        } else {
            ; 功能一：固定话语，每份PDF只发送同一句。
            if line = "@NO_PDF" {
                path := ""
                name := "当前对话（无需上传PDF）"
            } else {
                path := Trim(line, " `t`r`n" Chr(34))
                if !FileExist(path)
                    throw Error("找不到第" lineNo "行的PDF：" path)
                SplitPath(path, &name)
            }
            qs := [1]
        }
        freshJobs.Push({path: path, name: name, qs: qs, msgs: msgs})
    }
    newSignature := GM_ManifestId(raw)
    oldSignature := IniRead(GM_StatePath, "progress", "task_id", "")
    if (oldSignature != "" && newSignature != oldSignature) {
        ; V4.9.2：选定并加入PDF或保存修改后的任务直接生效，无“是/否”二次确认。
        ; 新清单与已有发送进度不同，自动从第一条重新开始，避免使用旧断点。
        if MsgBox("任务清单发生变化。是否从第一条重新开始？选择否保留现有断点。", "任务清单变更", "YesNo Icon?") != "Yes"
            return
        GM_ResetState(newSignature)
        try GM_WriteLog("任务清单已更新；自动重置当前模式的发送进度，无需二次确认。")
    }
    GM_Jobs := freshJobs
    GM_Signature := newSignature
    GM_RestoreProgress()
    total := 0
    for job in GM_Jobs
        total += job.qs.Length
    GM_CountText.Text := "已载入：" GM_Jobs.Length " 份任务，共 " total " 条" (GM_Mode = "questions" ? "逐题提问" : "话语") "。当前模式：" (GM_Mode = "together" ? "PDF+一句同时发送" : GM_Mode = "custom" ? "每PDF自定义" : GM_Mode = "single" ? "固定话语" : "原版逐题")
    GM_ShowProgress()
    if GM_Mode = "custom" || GM_Mode = "together"
        GM_RefreshCustomManager()
    if IsObject(GM_UploadIntroGui)
        GM_RefreshUploadIntroManager()
}

GM_ClearTaskList(*) {
    global GM_TaskPath, GM_Running, GM_Busy
    if (GM_Running || GM_Busy) {
        MsgBox("先按 F9 暂停，等当前上传或发送结束后再清空任务。", "任务正在运行")
        return
    }
    try {
        ; 保留一份旧清单备份，以免误点后无法找回任务路径。
        oldContent := FileRead(GM_TaskPath, "UTF-8")
        backup := ""
        if RegExMatch(oldContent, "m)^\s*[^#\s].*$") {
            backup := A_ScriptDir "\Gemini_PDF任务清单_备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") "_" A_TickCount ".txt"
            FileCopy(GM_TaskPath, backup)
        }
        ; 只保留格式说明。原PDF文件、计时与校准设置不会被删除。
        starter := GM_TaskTemplate()
        temp := GM_TaskPath ".new"
        if FileExist(temp)
            FileDelete(temp)
        FileAppend(starter, temp, "UTF-8")
        FileMove(temp, GM_TaskPath, 1)

        ; 写入新空清单的标识，重置进度，再按旧逻辑重新读取。
        GM_ResetState(GM_ManifestId(FileRead(GM_TaskPath, "UTF-8")))
        GM_ReloadJobs()
        msg := "✓ 旧PDF任务已清空，发送进度已重置。`n点击【添加 PDF 任务】录入新PDF即可。原PDF和时间/坐标设置未改变。"
        if (backup != "")
            msg .= "`n已自动备份原任务清单：" backup
        GM_SetStatus(msg)
    } catch as e {
        MsgBox("清空任务失败：" e.Message, "错误")
        GM_SetStatus("⚠ 清空任务失败。请检查任务文件是否被占用；旧任务可能未更改。")
    }
}

GM_AddPdfJob(button := 0, *) {
    global GM_TaskPath, GM_Running, GM_Mode, GM_Busy, GM_Jobs, GM_EditorOpen
    ; AHK v2 的 +OwnDialogs 必须在本次按钮事件线程内启用；
    ; 选择PDF窗口和题号对话框保持在置顶脚本窗口前面。
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    if GM_Running || GM_Busy || GM_EditorOpen {
        MsgBox("请先F9暂停并结束编辑，再添加PDF。")
        return
    }
    chosen := GM_Mode = "questions" ? FileSelect(1, , "选择要上传的PDF", "PDF 文件 (*.pdf)") : FileSelect("M1", , "可按 Ctrl 多选PDF，依次加入任务", "PDF 文件 (*.pdf)")
    if !chosen
        return
    if GM_Mode = "questions" {
        box := InputBox("输入这份PDF要提问的题号。例如：8-10,12,15-17", "设置题号", "w460 h150", "8-10")
        if box.Result != "OK"
            return
        try GM_ParseQuestions(box.Value, 1)
        catch as e {
            MsgBox(e.Message, "题号格式错误")
            return
        }
        FileAppend(chosen "|" box.Value "`r`n", GM_TaskPath, "UTF-8")
        GM_ReloadJobs()
        return
    }
    files := chosen is Array ? chosen : [chosen]
    if GM_Mode = "custom" || GM_Mode = "together" {
        for pdf in files {
            SplitPath(pdf, &name)
            GM_Jobs.Push({path: pdf, name: name, qs: [1], msgs: [GM_DefaultCustomMessage()]})
        }
        try {
            GM_SaveCustomJobs()
            GM_OpenCustomManager()
        } catch as e
            MsgBox("添加PDF失败：" e.Message)
    } else {
        for pdf in files
            FileAppend(pdf "`r`n", GM_TaskPath, "UTF-8")
        GM_ReloadJobs()
    }
}

GM_EditJobs(*) {
    global GM_TaskPath, GM_Mode
    if GM_Mode = "custom" || GM_Mode = "together" {
        GM_OpenCustomManager()
        return
    }
    Run('notepad.exe "' TaskPath '"')
}

GM_ResetState(sig) {
    global GM_StatePath, GM_StartProfileBox
    IniWrite(sig, GM_StatePath, "progress", "task_id")
    IniWrite("1", GM_StatePath, "progress", "job")
    IniWrite("1", GM_StatePath, "progress", "question")
    IniWrite("upload", GM_StatePath, "progress", "stage")
    IniWrite("", GM_StatePath, "progress", "until")
    IniWrite("1", GM_StatePath, "progress", "chat_group_start")
    IniWrite("0", GM_StatePath, "progress", "awaiting_new_chat")
    IniWrite(String(GM_StartProfileBox.Value = 2 ? 1 : 0), GM_StatePath, "progress", "fresh_profile")
}

GM_ResetProgress(button := 0, *) {
    global GM_Busy
    if GM_Busy
        return
    global GM_Running, GM_Busy, GM_Signature, GM_Jobs
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    if GM_Running || GM_Busy {
        MsgBox("先按 F9 暂停并等待当前上传或发送完全结束，才能重置进度。")
        return
    }
    if MsgBox("确定把发送进度清零吗？注意：重置后会重新上传第一份PDF、重新发送话语或题目。", "重置进度", "YesNo Icon!") != "Yes"
        return
    GM_ResetState(GM_Signature)
    GM_RestoreProgress()
    GM_ShowProgress()
}

GM_RestoreProgress() {
    global GM_StatePath, GM_JobIndex, GM_QuestionIndex, GM_Stage, GM_WaitUntil, GM_ChatGroupStartJob, GM_NeedManualNewChat, GM_InFreshComposer, GM_StartProfileBox
    GM_JobIndex := GM_GeminiSafeInteger(IniRead(GM_StatePath, "progress", "job", "1"), 1, 1, 100000)
    GM_QuestionIndex := GM_GeminiSafeInteger(IniRead(GM_StatePath, "progress", "question", "1"), 1, 1, 100000)
    GM_Stage := IniRead(GM_StatePath, "progress", "stage", "upload")
    GM_WaitUntil := IniRead(GM_StatePath, "progress", "until", "")
    GM_ChatGroupStartJob := GM_GeminiSafeInteger(IniRead(GM_StatePath, "progress", "chat_group_start", "1"), 1, 1, 100000)
    GM_NeedManualNewChat := IniRead(GM_StatePath, "progress", "awaiting_new_chat", "0") = "1"
    GM_InFreshComposer := IniRead(GM_StatePath, "progress", "fresh_profile", GM_StartProfileBox.Value = 2 ? "1" : "0") = "1"
}

GM_SaveProgress() {
    global GM_StatePath, GM_Signature, GM_JobIndex, GM_QuestionIndex, GM_Stage, GM_WaitUntil, GM_ChatGroupStartJob, GM_NeedManualNewChat, GM_InFreshComposer
    IniWrite(GM_Signature, GM_StatePath, "progress", "task_id")
    IniWrite(String(GM_JobIndex), GM_StatePath, "progress", "job")
    IniWrite(String(GM_QuestionIndex), GM_StatePath, "progress", "question")
    IniWrite(GM_Stage, GM_StatePath, "progress", "stage")
    IniWrite(GM_WaitUntil, GM_StatePath, "progress", "until")
    IniWrite(String(GM_ChatGroupStartJob), GM_StatePath, "progress", "chat_group_start")
    IniWrite(GM_NeedManualNewChat ? "1" : "0", GM_StatePath, "progress", "awaiting_new_chat")
    IniWrite(GM_InFreshComposer ? "1" : "0", GM_StatePath, "progress", "fresh_profile")
}

GM_SetStatus(info) {
    global GM_StatusText
    GM_StatusText.Text := info
}

GM_ShowProgress() {
    global GM_Jobs, GM_JobIndex, GM_QuestionIndex, GM_Stage, GM_WaitUntil, GM_Running, GM_Mode
    if (GM_Stage = "done") {
        GM_SetStatus("✓ 全部PDF及对应提问已经发送完毕。注意这只代表脚本完成发送，不代表回答已结束。")
        return
    }
    if GM_Jobs.Length = 0 {
        GM_SetStatus("还没有任务。请点击【添加PDF任务】；功能一、二可选择只发文字。")
        return
    }
    if (GM_JobIndex > GM_Jobs.Length) {
        GM_SetStatus("进度超出任务数量，请重置进度。")
        return
    }
    j := GM_Jobs[GM_JobIndex]
    qText := GM_Mode = "together" ? "PDF与话语同发" : (GM_QuestionIndex <= j.qs.Length ? (GM_Mode = "questions" ? "第" j.qs[GM_QuestionIndex] "题" : "第" GM_QuestionIndex "/" j.qs.Length "条话语") : "无后续话语/等待切换")
    msg := (GM_Running ? "运行中" : "未运行/已暂停") "｜PDF " GM_JobIndex "/" GM_Jobs.Length "：" j.name
        . "`n当前阶段：" GM_Stage "｜" qText
    if (GM_Stage = "upload_wait" || GM_Stage = "question_wait" || GM_Stage = "pdf_wait") {
        secs := GM_WaitUntil != "" ? Max(0, DateDiff(GM_WaitUntil, A_Now, "Seconds")) : 0
        msg .= "｜剩余约" secs "秒"
    }
    GM_SetStatus(msg)
}

GM_ValidateTimers() {
    global GM_QBox, GM_PBox, GM_UBox, GM_QWait, GM_PDFWait, GM_UploadWait, GM_PrefPath
    qText := Trim(GM_QBox.Value)
    pText := Trim(GM_PBox.Value)
    uText := Trim(GM_UBox.Value)
    if !RegExMatch(qText, "^\d+$") || !RegExMatch(pText, "^\d+$") || !RegExMatch(uText, "^\d+$")
        throw Error("等待时间请输入整数")
    q := Number(qText), p := Number(pText), u := Number(uText)
    if (q < 1 || q > 120 || p < 1 || p > 120 || u < 15 || u > 3600)
        throw Error("每题及PDF间隔为1~120分钟；上传后的等待为15~3600秒")
    GM_QWait := q, GM_PDFWait := p, GM_UploadWait := u
    IniWrite(String(q), GM_PrefPath, "timing", "question_minutes")
    IniWrite(String(p), GM_PrefPath, "timing", "pdf_minutes")
    IniWrite(String(u), GM_PrefPath, "timing", "upload_seconds")
}

GM_StartRun() {
    global GM_Busy
    if GM_Busy
        return
    global GM_EditorOpen, GM_ManagerGui
    if GM_EditorOpen || IsObject(GM_ManagerGui)
        throw Error("请先关闭话语编辑窗口")
    if SubStr(GM_Stage, 1, 7) = "verify_"
        throw Error("有待核实操作，请使用主窗口的核实按钮")
    global GM_Running, GM_Jobs, GM_Stage, GM_ChatHwnd, GM_Busy, GM_Mode, GM_Msg1Box, GM_SendMsg1, GM_NeedManualNewChat, GM_ChatGroupStartJob, GM_JobIndex, GM_InFreshComposer, GM_UploadIntroGui, GM_MainGui
    if GM_Busy {
        GM_SetStatus("正在完成上一条上传或发送操作。请等当前操作结束后再按 F8。")
        return
    }
    try GM_MainGui.Opt("+OwnDialogs")
    if IsObject(GM_UploadIntroGui) {
        MsgBox("请先关闭【每份PDF上传说明】管理窗口，然后按F8开始。")
        return
    }
    if GM_Running {
        GM_ShowProgress()
        return
    }
    if !GM_Jobs.Length {
        MsgBox("先添加至少一份PDF任务。", "没有任务")
        return
    }
    if GM_Stage = "done" {
        MsgBox("任务已经完成。若要从头来，请使用‘重置发送进度’。")
        return
    }
    try {
        GM_ValidateTimers()
        GM_SaveConversationOptions()
        GM_SaveMessageSettings()
        GM_SendMsg1 := Trim(GM_Msg1Box.Value)
        if GM_Mode = "single" && GM_SendMsg1 = ""
            throw Error("功能一请填写固定话语")
        if GM_Mode = "together" {
            for job in GM_Jobs {
                if job.path = "" || job.msgs.Length != 1 || Trim(job.msgs[1]) = ""
                    throw Error("功能三有PDF没有设置唯一的话语：" job.name)
            }
        }
        if GM_NeedManualNewChat {
            answer := MsgBox("此处必须开始一个全新的Gemini对话。`n`n请先在Gemini中手动点击【新建聊天】，确认页面空白；必要时按Ctrl+Alt+0绑定窗口。`n`n已经进入新的空白对话了吗？", "确认切换新对话", "YesNo Icon?")
            if answer != "Yes"
                return
            GM_NeedManualNewChat := false
            GM_ChatGroupStartJob := GM_JobIndex
            GM_InFreshComposer := true
            GM_SaveProgress()
        }
        ; V4.9.7：首份PDF在上传阶段按界面下拉框确定新旧对话，不再沿用上一轮进度里的过期 fresh 标记。
        ; 仅作用于第一组首份，不干预第11份等自动新建对话时的 fresh 标记。
        if (GM_JobIndex = 1 && GM_Stage = "upload" && GM_ChatGroupStartJob = 1) {
            GM_InFreshComposer := GM_StartProfileBox.Value = 2
            GM_SaveProgress()
        }
        GM_GeminiValidateUploadCalibration()
        GM_ChatHwnd := GM_ActivateChat()
        GM_Running := true
        GM_ShowProgress()


    } catch as e {
        GM_Running := false
        MsgBox(e.Message, "无法开始")
    }
}

GM_PauseRun() {
    global GM_Running
    GM_Running := false
    GM_ShowProgress()
}

GM_FastForward() {
    global GM_Running, GM_Stage, GM_WaitUntil
    if (GM_Stage != "upload_wait" && GM_Stage != "question_wait" && GM_Stage != "pdf_wait") {
        GM_SetStatus("当前不在等待阶段，F10不会跳过PDF或题目。")
        return
    }
    if !GM_Running
        GM_StartRun()
    if !GM_Running
        return
    GM_WaitUntil := A_Now
    GM_SaveProgress()


}

GM_BeginWait(nextStage, seconds) {
    global GM_Stage, GM_WaitUntil
    GM_Stage := nextStage
    GM_WaitUntil := DateAdd(A_Now, seconds, "Seconds")
    GM_SaveProgress()
}

GM_FinishOnePDF() {
    global GM_Jobs, GM_JobIndex, GM_Running, GM_Stage, GM_WaitUntil, GM_PDFWait
    if GM_JobIndex < GM_Jobs.Length
        GM_BeginWait("pdf_wait", GM_PDFWait*60)
    else {
        GM_Stage := "done"
        GM_WaitUntil := ""
        GM_SaveProgress()
        GM_Running := false
    }
}

GM_TickCore(*) {
    global GM_Running, GM_Busy, GM_Jobs, GM_JobIndex, GM_QuestionIndex, GM_Stage, GM_WaitUntil, GM_Mode, GM_SendMsg1
    global GM_UploadWait, GM_QWait, GM_PDFWait, GM_InFreshComposer, GM_ChatGroupStartJob, GM_NeedManualNewChat
    global GM_MaxPDFBox, GM_AutoSwitchBox, GM_NewChatX, GM_NewChatY
    if !GM_Running || GM_Busy
        return
    if !GM_Jobs.Length || GM_Stage = "done"
        return
    GM_Busy := true
    try {
        if (GM_Stage = "upload_wait" || GM_Stage = "question_wait" || GM_Stage = "pdf_wait") {
            if (GM_WaitUntil != "" && DateDiff(GM_WaitUntil, A_Now, "Seconds") > 0) {
                GM_ShowProgress()
                return
            }
            GM_WaitUntil := ""
            if GM_Stage = "upload_wait"
                GM_Stage := "question"
            else if GM_Stage = "question_wait"
                GM_Stage := "question"
            else {
                GM_JobIndex += 1
                GM_QuestionIndex := 1
                GM_Stage := "upload"
            }
            GM_SaveProgress()
        }

        if (GM_JobIndex > GM_Jobs.Length) {
            GM_Stage := "done"
            GM_SaveProgress()
            GM_Running := false
            GM_ShowProgress()
            return
        }
        job := GM_Jobs[GM_JobIndex]
        if (GM_Stage = "upload") {
            limit := Number(Trim(GM_MaxPDFBox.Value) = "" ? "0" : GM_MaxPDFBox.Value)
            if limit > 0 && GM_JobIndex > 1 && Mod(GM_JobIndex-1, limit) = 0 && GM_ChatGroupStartJob != GM_JobIndex {
                ; 在下一份PDF上传之前切换新聊天，避免把第11份误发到已满的旧聊天。
                if GM_AutoSwitchBox.Value && GM_NewChatX != "" && GM_NewChatY != "" {
                    GM_SetStatus("已达" limit "份PDF：尝试自动新建Gemini对话（请不要操作窗口）")
                    GM_ClickChat("new_chat")
                    Sleep(2600)
                    GM_ChatGroupStartJob := GM_JobIndex
                    GM_InFreshComposer := true
                    GM_SaveProgress()
                    GM_WriteLog("已点击新建Gemini对话，后续按新对话布局发送第" GM_JobIndex "份PDF")
                } else {
                    GM_NeedManualNewChat := true
                    GM_Running := false
                    GM_SaveProgress()
                    GM_SetStatus("⏸ 已完成前" (GM_JobIndex-1) "份PDF；请在Gemini手动新建空白聊天、Ctrl+Alt+0绑定并按F8。`n不会重发先前的PDF，也不会清空任务。")
                    return
                }
            }
            if (GM_Mode = "questions" || job.path != "") {
                GM_SetStatus("正在上传PDF " GM_JobIndex "/" GM_Jobs.Length "：" job.name "`n不要操作鼠标或键盘……")
                ; V4.7：只有准备上传下一份时才清理。upload_ready表示本份已附加待重试，绝不清它。
                GM_DiagLog("JOB_UPLOAD_START", "准备扫描残留并上传下一份PDF")
                if (GM_InFreshComposer && GM_JobIndex = GM_ChatGroupStartJob) {
                    ; 当前刚进入全新的空白会话，尚未添加本组PDF，不必重复调用耗时的旧附件检测。
                    GM_DiagLog("CLEAN_SKIP_FRESH_FIRST", "新建空白对话的首份PDF，无旧附件清理步骤；直接进入上传")
                } else {
                    try GM_CleanupPendingAttachments()
                    catch as cleanupErr {
                        GM_DiagLog("CLEAN_ERROR", cleanupErr.Message)
                        GM_WriteLog("V4.8：清理函数意外异常，但按照设定继续：" cleanupErr.Message)
                    }
                }
                GM_DiagLog("JOB_CLEAN_FINISHED", "开始附件上传尝试")
                GM_AttachPDF(job.path)
                GM_Stage := "upload_ready"
                GM_SaveProgress() ; PDF已附加，若文字发送失败，F8只重试话语，不重复附加PDF。
                if GM_Mode = "together"
                    GM_SendChatText(job.msgs[1], true) ; 与PDF一起送出，只发一次，跳过独立说明+后续提问
                else
                    GM_SendChatText(GM_GetUploadIntro(job), true)
                GM_InFreshComposer := false
                if GM_Mode = "together" || (GM_Mode = "custom" && job.msgs.Length = 0)
                    GM_FinishOnePDF()
                else
                    GM_BeginWait("upload_wait", GM_UploadWait)
                GM_WriteLog("已发送PDF：" job.path)
            } else {
                ; 当前对话已有资料时可不再次上传PDF、不发介绍语。
                GM_BeginWait("upload_wait", 1)
                GM_WriteLog("纯文字任务准备开始")
            }
        } else if (GM_Stage = "upload_ready") {
            ; 上一次PDF已经成功添加，但话语没有通过焦点验证时，可安全恢复。
            GM_SetStatus("PDF已附加，正在重试发送附件消息：" job.name)
            if GM_Mode = "together"
                GM_SendChatText(job.msgs[1], true)
            else
                GM_SendChatText(GM_GetUploadIntro(job), true)
            GM_InFreshComposer := false
            if GM_Mode = "together" || (GM_Mode = "custom" && job.msgs.Length = 0)
                GM_FinishOnePDF()
            else
                GM_BeginWait("upload_wait", GM_UploadWait)
            GM_WriteLog("重试后按Enter发送PDF消息：" job.path)
        } else if (GM_Stage = "question") {
            if GM_Mode = "questions" {
                q := job.qs[GM_QuestionIndex]
                msg := "这份PDF第" GM_ToChinese(q) "题没懂"
            } else if GM_Mode = "single"
                msg := GM_SendMsg1
            else
                msg := job.msgs[GM_QuestionIndex]
            GM_SetStatus("正在发送：" job.name " → " msg)
            GM_SendChatText(msg)
            GM_InFreshComposer := false
            GM_WriteLog("已发送提问：" job.name "：" msg)
            if (GM_QuestionIndex < job.qs.Length) {
                GM_QuestionIndex += 1
                GM_BeginWait("question_wait", GM_QWait*60)
            } else if (GM_JobIndex < GM_Jobs.Length) {
                GM_BeginWait("pdf_wait", GM_PDFWait*60)
            } else {
                GM_Stage := "done"
                GM_WaitUntil := ""
                GM_SaveProgress()
                GM_Running := false
            }
        }
        GM_ShowProgress()
    } catch as e {
        GM_Running := false
        GM_DiagLog("JOB_FAIL", "error=" e.Message " extra=" e.What " line=" e.Line)
        GM_WriteLog("失败：" e.Message)
        GM_SetStatus("⚠ 已暂停：" e.Message "`n请检查Gemini是否正常、PDF是否上传成功、消息是否已发送。排查后按F8恢复；必要时重置进度。")
    } finally {
        GM_Busy := false
    }
}

GM_WriteLog(info) {
    global GM_LogPath
    FileAppend(FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " " info "`r`n", GM_LogPath, "UTF-8")
}


GM_Tick(*) {
    global MergedLockOwner, MergedInChildCall
    if MergedInChildCall && MergedLockOwner = "gemini"
        GM_TickCore()
}

