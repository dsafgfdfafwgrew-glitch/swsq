﻿#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
SetTitleMatchMode(2)
SendMode("Input")
CoordMode("Mouse", "Screen") ; 以下保存/点击的都是屏幕绝对坐标
CoordMode("Pixel", "Screen") ; 残留附件图块检测使用屏幕坐标

; Windows AutoHotkey v2 | Gemini 桌面端多 PDF 顺序上传与逐题发送
; 不调用 API，不读取 PDF 题目内容。使用桌面窗口坐标定位附件按钮、上传菜单、输入框。
; 暂停/恢复依靠进度.ini；允许新对话首发，也允许按每对话PDF数自动/手动切换。
; 若 Gemini 不是独立 exe，而是 Chrome/Edge 安装的桌面应用，可先按 Ctrl+Alt+0 绑定当前 Gemini 窗口。
; 仅当附件按钮能调出 Windows 文件选择对话框时上传流程可用。

baseDir := A_ScriptDir
global TaskPath := baseDir "\Gemini_PDF任务清单.txt"
; V4.4：设置不再存放在脚本所在目录，避免每次下载到不同文件夹被误认为重置。
; 首次启用会自动导入当前脚本文件夹的旧设置（如存在）。任务/进度仍沿用 V3/V4 原文件夹，不做清空。
global PrefDir := A_AppData "\Gemini_MultiPDF_AutoSend"
DirCreate(PrefDir)
legacyPrefPath := baseDir "\Gemini_设置.ini"
global PrefPath := PrefDir "\Gemini_设置.ini"
if !FileExist(PrefPath) && FileExist(legacyPrefPath)
    FileCopy(legacyPrefPath, PrefPath)
global StatePath := baseDir "\Gemini_多PDF进度.ini"
global LogPath := baseDir "\Gemini_运行日志.txt"
; V4.9.5 将详细诊断日志放在稳定的 AppData 目录，与已有任务/进度文件分离。
global DebugPath := PrefDir "\Gemini_V4.9.5_详细诊断日志.txt"
global DebugSeq := 0
global LastDiagProblem := "尚无故障记录"
global DiagSession := FormatTime(A_Now, "yyyyMMdd-HHmmss")
; V4 新增固定话语与每PDF自定义模式，仅在选中模式时启用，原逐题逻辑和旧任务文件保留。
global Mode := "questions"
global SendMsg1 := ""
global OriginalTaskPath := TaskPath
global OriginalStatePath := StatePath
global FixedTaskPath := baseDir "\Gemini_固定话语任务清单.txt"
global FixedStatePath := baseDir "\Gemini_固定话语进度.ini"
global CustomTaskPath := baseDir "\Gemini_自定义话语任务清单.txt"
global CustomStatePath := baseDir "\Gemini_自定义话语进度.ini"
; V4.9.4：修复检测时弹出 PowerShell 窗口抢走焦点；保留 V4.9.3 上传和话语定位改进。
; 保留 V4.9.1 的任务、进度及设置路径。
global TogetherTaskPath := baseDir "\Gemini_同步上传话语任务清单.txt"
global TogetherStatePath := baseDir "\Gemini_同步上传话语进度.ini"
global ManagerGui := 0
global ManagerList := 0
global EditorOpen := false
global Jobs := []
global Signature := ""
global JobIndex := 1
global QuestionIndex := 1
global Stage := "upload"   ; upload / upload_ready / upload_wait / question / question_wait / pdf_wait / done
global WaitUntil := ""
global Running := false
global Busy := false
global LastUploadProbe := "尚未测试"
global ChatHwnd := 0
global PlusX := IniRead(PrefPath, "coords", "plusX", "")
global PlusY := IniRead(PrefPath, "coords", "plusY", "")
global UploadX := IniRead(PrefPath, "coords", "uploadX", "")
global UploadY := IniRead(PrefPath, "coords", "uploadY", "")
global InputX := IniRead(PrefPath, "coords", "inputX", "")
global InputY := IniRead(PrefPath, "coords", "inputY", "")
; Gemini附加PDF后会把输入行向上抬高，因此与普通文字输入使用不同的落点。
; 未校准时按照附件＋号自动估计；按Ctrl+Alt+4可对含PDF的输入行精确校准。
global AttachedInputX := IniRead(PrefPath, "coords", "attachedInputX", "")
global AttachedInputY := IniRead(PrefPath, "coords", "attachedInputY", "")
global QWait := 30  ; 分钟
global PDFWait := 60 ; 分钟
global UploadWait := 30 ; 秒：PDF消息发送完到首题之间
; V4.4: 旧对话坐标不变，新增空白新对话独立坐标；全部保存在原 Gemini_设置.ini。
global FreshPlusX := IniRead(PrefPath, "coords", "freshPlusX", "")
global FreshPlusY := IniRead(PrefPath, "coords", "freshPlusY", "")
global FreshUploadX := IniRead(PrefPath, "coords", "freshUploadX", "")
global FreshUploadY := IniRead(PrefPath, "coords", "freshUploadY", "")
global FreshInputX := IniRead(PrefPath, "coords", "freshInputX", "")
global FreshInputY := IniRead(PrefPath, "coords", "freshInputY", "")
global FreshAttachedX := IniRead(PrefPath, "coords", "freshAttachedX", "")
global FreshAttachedY := IniRead(PrefPath, "coords", "freshAttachedY", "")
global NewChatX := IniRead(PrefPath, "coords", "newChatX", "")
global NewChatY := IniRead(PrefPath, "coords", "newChatY", "")
global InFreshComposer := false
; 当前模式进度分别保存这些字段，不会改动V3的原有任务清单字段。
global ChatGroupStartJob := 1
; 需要手动新建对话时，不会发送下一份PDF，直到用户确认后按F8。
global NeedManualNewChat := false
; V4.6：上传PDF时发送的“请接收这份PDF……”按PDF路径分别保存，所有模式共用。
; 仅改变首条上传说明，不改变原版逐题、功能一或功能二的正式话语。
global UploadIntroPath := PrefDir "\Gemini_每份PDF上传说明.txt"
global UploadIntroMap := Map()
global UploadIntroGui := 0
global UploadIntroList := 0
global UploadIntroEditor := 0

; V4.8：每份新PDF上传前多轮检测/重复清理残留输入框附件；清理异常只写日志不暂停。
; UIA自动识别/移除优先；若Gemini没有提供可访问的删除按钮，可校准一次卡片上的×。
global CleanupRemoveX := IniRead(PrefPath, "coords", "cleanupRemoveX", "")
global CleanupRemoveY := IniRead(PrefPath, "coords", "cleanupRemoveY", "")
global FreshCleanupRemoveX := IniRead(PrefPath, "coords", "freshCleanupRemoveX", "")
global FreshCleanupRemoveY := IniRead(PrefPath, "coords", "freshCleanupRemoveY", "")
global SkipCleanupOnce := false


if !FileExist(TaskPath)
    FileAppend("# 每行格式：PDF完整路径|题号，例如：D:\资料\第一讲.pdf|8-10,12,16-18`r`n# 可点脚本窗口里的【添加 PDF 任务】，无须手工写路径。`r`n", TaskPath, "UTF-8")

; V4.9.8.2：处理空白/损坏的INI数值，防止Number("")造成启动中断；不写回、不重置任务。
GeminiSafeInteger(raw, fallback, minimum, maximum) {
    val := Trim(String(raw))
    if !RegExMatch(val, "^\d+$") || StrLen(val) > 8
        return fallback
    n := Number(val)
    return (n >= minimum && n <= maximum) ? n : fallback
}

; V4.3：主窗口缩小为紧凑可调整大小的界面；高级设置独立弹窗。
; 不改动上传、发送、任务、等待、校准和进度的实际处理函数。
global MainGui := Gui("+AlwaysOnTop +Resize +MinSize590x395", "Gemini 多PDF自动发送 · V4.9.8.3 发送可靠性修复版")
MainGui.SetFont("s9", "Microsoft YaHei")
MainGui.MarginX := 12
MainGui.MarginY := 10
global CountText := MainGui.AddText("xm w650 h26", "正在载入任务……")
MainGui.AddText("xm y+8", "每条话语间隔(分)：")
global QBox := MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(PrefPath, "timing", "question_minutes", "30"))
MainGui.AddText("x+14 yp+3", "每份PDF间隔(分)：")
global PBox := MainGui.AddEdit("x+5 yp-3 w55 Number", IniRead(PrefPath, "timing", "pdf_minutes", "60"))
MainGui.AddText("x+14 yp+3", "上传后等待(秒)：")
global UBox := MainGui.AddEdit("x+5 yp-3 w60 Number", IniRead(PrefPath, "timing", "upload_seconds", "30"))
QBox.OnEvent("Change", SaveTimersOnEdit)
PBox.OnEvent("Change", SaveTimersOnEdit)
UBox.OnEvent("Change", SaveTimersOnEdit)
MainGui.AddText("xm y+12", "首次使用的 Gemini 对话：")
global StartProfileBox := MainGui.AddDropDownList("x+7 yp-4 w215", ["已有消息的旧对话", "空白新对话（首发PDF）"])
StartProfileBox.Choose(GeminiSafeInteger(IniRead(PrefPath, "chat", "start_profile", "1"), 1, 1, 2))
StartProfileBox.OnEvent("Change", SaveStartProfile)
global AdvBtn := MainGui.AddButton("x+17 yp-1 w137 h27", "高级设置 / 定位")
AdvBtn.OnEvent("Click", ShowAdvancedSettings)
global SavePrefsBtn := MainGui.AddButton("x+8 yp w105 h27", "保存全部设置")
SavePrefsBtn.OnEvent("Click", (*) => SaveAllSettings(true))
MainGui.AddText("xm y+12", "发送模式：")
global ModeBox := MainGui.AddDropDownList("x+6 yp-4 w565", ["原版：PDF逐题提问", "功能一：所有PDF共用一条固定话语", "功能二：每份PDF自定义1~多条话语", "功能三：PDF和一句话同时发送"])
ModeBox.Choose(GeminiSafeInteger(IniRead(PrefPath, "messages", "mode_index", "1"), 1, 1, 4))
ModeBox.OnEvent("Change", SwitchMode)
global Msg1Label := MainGui.AddText("xm y+9 w650", "功能一专用：所有PDF共用的固定话语（可修改）：")
global Msg1Box := MainGui.AddEdit("xm y+4 w650", IniRead(PrefPath, "messages", "first", "请帮我整理申论，生成word"))
Msg1Box.OnEvent("Change", SaveMessageSettings)
addBtn := MainGui.AddButton("xm y+11 w142 h29", "添加 PDF 任务")
addBtn.OnEvent("Click", AddPdfJob)
editBtn := MainGui.AddButton("x+7 yp w142 h29", "编辑任务清单")
editBtn.OnEvent("Click", EditJobs)
reloadBtn := MainGui.AddButton("x+7 yp w142 h29", "刷新任务（不清空）")
reloadBtn.OnEvent("Click", ReloadJobs)
resetBtn := MainGui.AddButton("x+7 yp w142 h29", "重置发送进度")
resetBtn.OnEvent("Click", ResetProgress)
; 在紧凑主窗口第一排末尾增加日志入口，不弹出需要确认的模态对话框。
MainGui.AddButton("x+7 yp w72 h29", "诊断日志").OnEvent("Click", OpenDiagnosticLog)
noPdfBtn := MainGui.AddButton("xm y+7 w250 h29", "只发话语（不重新上传PDF）")
noPdfBtn.OnEvent("Click", AddTextOnlyJob)
global NoPdfBtn := noPdfBtn
global CustomManageBtn := MainGui.AddButton("x+8 yp w250 h29", "管理每份PDF的话语")
CustomManageBtn.OnEvent("Click", OpenCustomManager)
; 不需要切换功能一/功能二：三个模式都可以单独改“上传PDF时的说明”。
global IntroManageBtn := MainGui.AddButton("x+8 yp w155 h29", "每份PDF上传说明")
IntroManageBtn.OnEvent("Click", OpenUploadIntroManager)
MainGui.AddText("xm y+10 w650", "F8 开始/继续　F9 暂停　F10 跳过等待　F12 退出")
global StatusText := MainGui.AddText("xm y+8 w650 h83", "添加PDF任务，校准 Gemini 窗口后按 F8。")
MainGui.OnEvent("Size", CompactWindowResized)
MainGui.OnEvent("Close", SafeExit)

; 以下设置被移入弹出的高级窗口，仍沿用原变量和原保存逻辑。
global AdvancedGui := Gui("+AlwaysOnTop", "Gemini · 高级设置与坐标定位")
AdvancedGui.SetFont("s9", "Microsoft YaHei")
AdvancedGui.MarginX := 14
AdvancedGui.MarginY := 13
AdvancedGui.AddText("xm w640", "快捷键校准：把鼠标放到 Gemini 目标位置后按组合键，位置自动保存。")
AdvancedGui.AddText("xm y+9 w670", "Ctrl+Alt+0 绑定窗口； 1 附件＋； 2 上传菜单； 3 普通输入框； 4 附件后输入框")
AdvancedGui.AddText("xm y+6 w670", "新对话专用：Ctrl+Alt+5 附件＋； 6 上传菜单； 7 普通输入框； 8 附件后输入框")
AdvancedGui.AddText("xm y+6 w670", "Ctrl+Alt+9：新建聊天按钮（若需自动切换对话，必须先校准）")
AdvancedGui.AddText("xm y+6 w690", "残留PDF清理：自动多次识别和清除；清理失败写日志但不中断。Ctrl+Shift+Alt+R 校准删除×")
global CalText := AdvancedGui.AddText("xm y+12 w665 h56", "正在读取定位状态……")
AdvancedGui.AddText("xm y+12", "每个对话最多处理PDF数量（0 = 不换）：")
global MaxPDFBox := AdvancedGui.AddEdit("x+8 yp-3 w64 Number", IniRead(PrefPath, "chat", "max_pdfs", "0"))
MaxPDFBox.OnEvent("Change", SaveConversationOptions)
global AutoSwitchBox := AdvancedGui.AddCheckBox("xm y+13", "到上限自动点击【新建聊天】（需要 Ctrl+Alt+9 已校准）")
AutoSwitchBox.Value := GeminiSafeInteger(IniRead(PrefPath, "chat", "auto_switch", "0"), 0, 0, 1)
AutoSwitchBox.OnEvent("Click", SaveConversationOptions)
AdvancedGui.AddText("xm y+12 w670", "不勾选时到上限将安全暂停，手动打开新聊天并按 Ctrl+Alt+0、F8 继续。")
AdvancedGui.AddText("xm y+9 w670", "V4.4：设置保存在 Windows AppData，移动或升级脚本也不会重置。")
AdvancedGui.AddText("xm y+5 w670", "设置文件：" PrefPath)
AdvancedGui.AddButton("xm y+12 w125 h28", "保存全部设置").OnEvent("Click", (*) => SaveAllSettings(true))
AdvancedGui.AddButton("x+8 yp w125 h28", "导入旧设置").OnEvent("Click", ImportLegacySettings)
AdvancedGui.AddButton("x+8 yp w125 h28", "打开设置文件夹").OnEvent("Click", OpenPrefsFolder)
AdvancedGui.AddButton("x+8 yp w125 h28", "关闭高级设置").OnEvent("Click", HideAdvancedSettings)
AdvancedGui.AddButton("x+8 yp w132 h28", "复制故障摘要").OnEvent("Click", CopyDiagnosticSummary)
; V4.9.7：校准后可直接试开文件选择窗口，不触碰任务进度、不上传PDF。
AdvancedGui.AddButton("xm y+11 w225 h30", "测试上传按钮（不上传PDF）").OnEvent("Click", TestGeminiUploadPicker)
AdvancedGui.AddText("x+12 yp+7 w430", "新对话请先 Ctrl+Alt+5 校准＋，Ctrl+Alt+6 校准上传菜单。")
global TestResultText := AdvancedGui.AddText("xm y+9 w675 h40", "测试结果显示在这里。测试独立于41份任务，不上传文件、不推进进度。")
AdvancedGui.OnEvent("Close", HideAdvancedSettings)
MainGui.Show("w700 h430")

F8::StartRun()
F9::PauseRun()
F10::FastForward()
F12::SafeExit()
^!0::BindGeminiWindow()
^!1::Calibrate("plus")
^!2::Calibrate("upload")
^!3::Calibrate("input")
^!4::Calibrate("attached_input")
^!5::CalibrateFresh("plus")
^!6::CalibrateFresh("upload")
^!7::CalibrateFresh("input")
^!8::CalibrateFresh("attached_input")
^!9::CalibrateFresh("new_chat")
^+!r::CalibrateCleanupRemove()
^+!s::ConfirmSkipCleanupOnce()
SetTimer(Tick, 1000)
InitSelectedMode()
try LoadUploadIntros()
catch as e
    SetStatus("PDF上传说明载入失败：" e.Message)
try ReloadJobs()
catch as e
    SetStatus("载入任务失败：" e.Message)
UpdateCalibration()
OnExit(OnScriptExit)
DiagLog("START", "V4.9.8.3已启动；修复附件后粘贴校验与发送焦点重试；原任务文件格式未变")


; 紧凑窗口支持拖动四角改变大小，正文和状态栏自动随宽度扩展。
CompactWindowResized(guiObj, minMax, width, height) {
    global CountText, ModeBox, Msg1Label, Msg1Box, StatusText
    if minMax = -1
        return
    contentWidth := Max(555, width - 27)
    try {
        CountText.Move(, , contentWidth)
        ModeBox.Move(, , Max(430, contentWidth - 89))
        Msg1Label.Move(, , contentWidth)
        Msg1Box.Move(, , contentWidth)
        StatusText.GetPos(&sx, &sy, &sw, &sh)
        StatusText.Move(, , contentWidth, Max(58, height - sy - 16))
    }
}

ShowAdvancedSettings(*) {
    global AdvancedGui
    AdvancedGui.Show("w760 h505")
}

HideAdvancedSettings(*) {
    global AdvancedGui
    try SaveConversationOptions()
    AdvancedGui.Hide()
}

; ===== V4：三个独立模式。原版模式仍使用 V3 原始的文件和完整调度。 =====
SaveTimersOnEdit(*) {
    ; 修改后立即保存，F12和右上角关闭也会再保存一次，避免退出重置。
    global QBox, PBox, UBox, PrefPath
    for t in [["question_minutes", QBox.Value, 1, 120], ["pdf_minutes", PBox.Value, 1, 120], ["upload_seconds", UBox.Value, 15, 3600]] {
        v := Trim(t[2])
        if RegExMatch(v, "^\d+$") && Number(v) >= t[3] && Number(v) <= t[4]
            IniWrite(String(Number(v)), PrefPath, "timing", t[1])
    }
}

SaveConversationOptions(*) {
    global PrefPath, MaxPDFBox, AutoSwitchBox
    n := Trim(MaxPDFBox.Value)
    if RegExMatch(n, "^\d+$") && Number(n) <= 1000
        IniWrite(String(Number(n)), PrefPath, "chat", "max_pdfs")
    IniWrite(String(AutoSwitchBox.Value), PrefPath, "chat", "auto_switch")
}

SaveStartProfile(*) {
    global StartProfileBox, PrefPath, JobIndex, Stage, InFreshComposer, Running
    IniWrite(String(StartProfileBox.Value), PrefPath, "chat", "start_profile")
    ; 仅尚未开始的第一份任务可切换开场界面，防止中途误覆盖现场状态。
    if !Running && JobIndex = 1 && Stage = "upload" {
        InFreshComposer := StartProfileBox.Value = 2
        SaveProgress()
    }
}

; 下面的统一保存也会在按 F12 和点窗口 X 时执行；不会清空任务或进度。
SafeExit(*) {
    SaveAllSettings(false)
    ExitApp()
}

; OnExit回调必须返回0，否则返回true会阻止程序退出。
OnScriptExit(*) {
    SaveAllSettings(false)
    return 0
}

; 手动保存：先检查三个间隔及PDF上限，再写入同一个 AppData 配置文件并读回确认。
SaveAllSettings(showNotice := true) {
    global PrefPath, QBox, PBox, UBox, MaxPDFBox, AutoSwitchBox, StartProfileBox, ModeBox, Msg1Box
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY, FreshInputX, FreshInputY
    global FreshAttachedX, FreshAttachedY, NewChatX, NewChatY
    global CleanupRemoveX, CleanupRemoveY, FreshCleanupRemoveX, FreshCleanupRemoveY
    try {
        ValidateTimers()
        n := Trim(MaxPDFBox.Value)
        if !RegExMatch(n, "^\d+$") || Number(n) > 1000
            throw Error("每个对话的PDF数量必须是0～1000之间的整数")
        SaveConversationOptions()
        SaveMessageSettings()
        IniWrite(String(StartProfileBox.Value), PrefPath, "chat", "start_profile")
        IniWrite(String(ModeBox.Value), PrefPath, "messages", "mode_index")
        values := Map(
            "plusX", PlusX, "plusY", PlusY, "uploadX", UploadX, "uploadY", UploadY,
            "inputX", InputX, "inputY", InputY,
            "attachedInputX", AttachedInputX, "attachedInputY", AttachedInputY,
            "freshPlusX", FreshPlusX, "freshPlusY", FreshPlusY,
            "freshUploadX", FreshUploadX, "freshUploadY", FreshUploadY,
            "freshInputX", FreshInputX, "freshInputY", FreshInputY,
            "freshAttachedX", FreshAttachedX, "freshAttachedY", FreshAttachedY,
            "newChatX", NewChatX, "newChatY", NewChatY,
            "cleanupRemoveX", CleanupRemoveX, "cleanupRemoveY", CleanupRemoveY,
            "freshCleanupRemoveX", FreshCleanupRemoveX, "freshCleanupRemoveY", FreshCleanupRemoveY)
        for key, value in values {
            if value != ""
                IniWrite(String(value), PrefPath, "coords", key)
        }
        if IniRead(PrefPath, "timing", "question_minutes", "") != String(Number(Trim(QBox.Value)))
            throw Error("每条话语间隔未能读回，请检查写入权限")
        if IniRead(PrefPath, "timing", "pdf_minutes", "") != String(Number(Trim(PBox.Value)))
            throw Error("每份PDF间隔未能读回，请检查写入权限")
        if IniRead(PrefPath, "timing", "upload_seconds", "") != String(Number(Trim(UBox.Value)))
            throw Error("上传后等待时间未能读回，请检查写入权限")
        if IniRead(PrefPath, "chat", "max_pdfs", "") != String(Number(n))
            throw Error("每个对话PDF数量未能读回，请检查写入权限")
        for key, value in values {
            if value != "" && IniRead(PrefPath, "coords", key, "") != String(value)
                throw Error("定位设置 " key " 未能读回，请检查写入权限")
        }
        if showNotice
            SetStatus("✓ 全部设置已保存并核对成功。间隔与坐标下次启动继续有效。")
        return true
    } catch as e {
        if showNotice
            MsgBox("保存未完成：" e.Message "`n请不要退出，先检查填写和目录权限。`n" PrefPath, "保存失败", "Iconx")
        return false
    }
}

; 旧版本的ini往往存放于各个下载文件夹。可选择其中一份导入，当前配置先备份。
ImportLegacySettings(button := 0, *) {
    global PrefPath, Running, Busy, QBox, PBox, UBox, MaxPDFBox, AutoSwitchBox
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    global StartProfileBox, Msg1Box, ModeBox, PrefDir
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY, FreshInputX, FreshInputY
    global FreshAttachedX, FreshAttachedY, NewChatX, NewChatY
    global CleanupRemoveX, CleanupRemoveY, FreshCleanupRemoveX, FreshCleanupRemoveY
    if Running || Busy {
        MsgBox("请先按 F9 暂停任务，再导入旧设置。")
        return
    }
    selected := FileSelect(1, A_ScriptDir, "选择旧版 Gemini_设置.ini", "INI 设置文件 (*.ini)")
    if selected = ""
        return
    if StrLower(selected) = StrLower(PrefPath) {
        MsgBox("你选的就是当前设置文件，不需要重复导入。")
        return
    }
    if MsgBox("将读取所选旧设置，替换当前的间隔、定位坐标和模式设置。`n当前设置会先自动备份；PDF任务和发送进度不删除。`n`n继续？", "确认导入", "YesNo Icon?") != "Yes"
        return
    try {
        if FileExist(PrefPath)
            FileCopy(PrefPath, PrefDir "\Gemini_设置_导入前备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") ".ini")
        FileCopy(selected, PrefPath, true)
        QBox.Value := IniRead(PrefPath, "timing", "question_minutes", "30")
        PBox.Value := IniRead(PrefPath, "timing", "pdf_minutes", "60")
        UBox.Value := IniRead(PrefPath, "timing", "upload_seconds", "30")
        MaxPDFBox.Value := IniRead(PrefPath, "chat", "max_pdfs", "0")
        AutoSwitchBox.Value := GeminiSafeInteger(IniRead(PrefPath, "chat", "auto_switch", "0"), 0, 0, 1)
        StartProfileBox.Choose(GeminiSafeInteger(IniRead(PrefPath, "chat", "start_profile", "1"), 1, 1, 2))
        Msg1Box.Value := IniRead(PrefPath, "messages", "first", "请帮我整理申论，生成word")
        ModeBox.Choose(GeminiSafeInteger(IniRead(PrefPath, "messages", "mode_index", "1"), 1, 1, 4))
        ; 发送模式的实际任务列表保持不动；重新打开脚本时才切到导入的模式。
        PlusX := IniRead(PrefPath, "coords", "plusX", "")
        PlusY := IniRead(PrefPath, "coords", "plusY", "")
        UploadX := IniRead(PrefPath, "coords", "uploadX", "")
        UploadY := IniRead(PrefPath, "coords", "uploadY", "")
        InputX := IniRead(PrefPath, "coords", "inputX", "")
        InputY := IniRead(PrefPath, "coords", "inputY", "")
        AttachedInputX := IniRead(PrefPath, "coords", "attachedInputX", "")
        AttachedInputY := IniRead(PrefPath, "coords", "attachedInputY", "")
        FreshPlusX := IniRead(PrefPath, "coords", "freshPlusX", "")
        FreshPlusY := IniRead(PrefPath, "coords", "freshPlusY", "")
        FreshUploadX := IniRead(PrefPath, "coords", "freshUploadX", "")
        FreshUploadY := IniRead(PrefPath, "coords", "freshUploadY", "")
        FreshInputX := IniRead(PrefPath, "coords", "freshInputX", "")
        FreshInputY := IniRead(PrefPath, "coords", "freshInputY", "")
        FreshAttachedX := IniRead(PrefPath, "coords", "freshAttachedX", "")
        FreshAttachedY := IniRead(PrefPath, "coords", "freshAttachedY", "")
        NewChatX := IniRead(PrefPath, "coords", "newChatX", "")
        NewChatY := IniRead(PrefPath, "coords", "newChatY", "")
        CleanupRemoveX := IniRead(PrefPath, "coords", "cleanupRemoveX", "")
        CleanupRemoveY := IniRead(PrefPath, "coords", "cleanupRemoveY", "")
        FreshCleanupRemoveX := IniRead(PrefPath, "coords", "freshCleanupRemoveX", "")
        FreshCleanupRemoveY := IniRead(PrefPath, "coords", "freshCleanupRemoveY", "")
        UpdateCalibration()
        ; 导入的发送模式下次重启会恢复，这里不强制切换正在编辑的任务模式。
        if SaveAllSettings(false)
            MsgBox("导入成功！已加载旧设置并保存到固定位置。`n`n旧设置内的发送模式将在下次启动时恢复。`n" PrefPath, "导入完成", "Iconi")
        else
            MsgBox("已读入旧INI，但有字段无效。请检查三个间隔及PDF上限，并点击【保存全部设置】。", "需要检查")
    } catch as e {
        MsgBox("导入失败：" e.Message, "错误", "Iconx")
    }
}

OpenPrefsFolder(*) {
    global PrefDir
    Run(PrefDir)
}

CalibrateFresh(which) {
    global PrefPath, FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY
    global FreshInputX, FreshInputY, FreshAttachedX, FreshAttachedY, NewChatX, NewChatY
    h := GetChat()
    if !h {
        MsgBox("请先切换到Gemini窗口并按 Ctrl+Alt+0 绑定后再校准。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx-wx, ry := my-wy
    if which = "plus" {
        FreshPlusX := rx, FreshPlusY := ry
        key := "freshPlus", label := "新对话附件＋"
    } else if which = "upload" {
        FreshUploadX := rx, FreshUploadY := ry
        key := "freshUpload", label := "新对话上传菜单"
    } else if which = "input" {
        FreshInputX := rx, FreshInputY := ry
        key := "freshInput", label := "新对话普通输入框"
    } else if which = "attached_input" {
        FreshAttachedX := rx, FreshAttachedY := ry
        key := "freshAttached", label := "新对话带PDF的输入框"
    } else {
        NewChatX := rx, NewChatY := ry
        key := "newChat", label := "新建聊天按钮"
    }
    IniWrite(String(rx), PrefPath, "coords", key "X")
    IniWrite(String(ry), PrefPath, "coords", key "Y")
    UpdateCalibration()
    ToolTip("已保存：" label "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -2200)
}

; 切到新对话后，只有第一条带附件的PDF消息使用居中的新对话坐标。
; 第一条实际发出以后立即恢复原来已经校准好的旧对话坐标。

ModeIndex() {
    global Mode
    return Mode = "single" ? 2 : (Mode = "custom" ? 3 : (Mode = "together" ? 4 : 1))
}

TaskTemplate() {
    global Mode
    if Mode = "questions"
        return "# 每行：PDF完整路径|题号，如 D:\第一讲.pdf|8-10,12`r`n"
    if Mode = "single"
        return "# 每行一个PDF完整路径；或 @NO_PDF 代表在当前对话直接发一次固定话语。`r`n"
    if Mode = "together"
        return "# 功能三：每个PDF附带且只发送一句专属话语；PDF路径|话语，使用窗口编辑。`r`n"
    return "# 功能二：每个PDF可设置多句；PDF路径|第1句|第2句；末尾单独|表示不发送后续话语。`r`n"
}

InitSelectedMode() {
    global ModeBox
    SelectMode(ModeBox.Value, false)
}

SelectMode(idx, reload := true) {
    global Mode, TaskPath, StatePath, OriginalTaskPath, OriginalStatePath, CustomTaskPath, CustomStatePath
    global FixedTaskPath, FixedStatePath, TogetherTaskPath, TogetherStatePath, PrefPath, NoPdfBtn, CustomManageBtn, IntroManageBtn, Msg1Label, Msg1Box
    idx := idx >= 1 && idx <= 4 ? idx : 1
    Mode := idx = 1 ? "questions" : (idx = 2 ? "single" : (idx = 3 ? "custom" : "together"))
    TaskPath := idx = 1 ? OriginalTaskPath : (idx = 2 ? FixedTaskPath : (idx = 3 ? CustomTaskPath : TogetherTaskPath))
    StatePath := idx = 1 ? OriginalStatePath : (idx = 2 ? FixedStatePath : (idx = 3 ? CustomStatePath : TogetherStatePath))
    if !FileExist(TaskPath)
        FileAppend(TaskTemplate(), TaskPath, "UTF-8")
    NoPdfBtn.Enabled := idx = 2 || idx = 3
    IntroManageBtn.Enabled := idx != 4 ; 功能三不使用单独上传说明
    CustomManageBtn.Enabled := idx = 3 || idx = 4
    Msg1Box.Enabled := idx = 2
    Msg1Label.Text := idx = 4 ? "功能三：每份PDF只发一条消息，请点【管理每份PDF的话语】修改。" : (idx = 3 ? "功能二：请点【管理每份PDF的话语】，每份单独编辑；支持批量设空白。" : "功能一专用：所有PDF共用的固定话语（可修改）：")
    IniWrite(String(idx), PrefPath, "messages", "mode_index")
    if reload
        ReloadJobs()
}

SwitchMode(*) {
    global Running, Busy, ModeBox, EditorOpen, ManagerGui, UploadIntroGui
    if Running || Busy || EditorOpen || IsObject(ManagerGui) || IsObject(UploadIntroGui) {
        MsgBox("请先暂停并关闭自定义任务管理/编辑窗口，再切换模式。", "暂时不能切换")
        ModeBox.Choose(ModeIndex())
        return
    }
    try SelectMode(ModeBox.Value)
    catch as e {
        MsgBox("切换模式失败：" e.Message, "错误")
        ModeBox.Choose(ModeIndex())
    }
}

SaveMessageSettings(*) {
    global Msg1Box, PrefPath
    IniWrite(Trim(Msg1Box.Value), PrefPath, "messages", "first")
}

AddTextOnlyJob(*) {
    global TaskPath, Running, Busy, Mode, Jobs, EditorOpen, Msg1Box
    if Mode = "questions" {
        MsgBox("原版逐题模式不支持纯文字任务，请选择固定或自定义话语模式。")
        return
    }
    if Running || Busy || EditorOpen {
        MsgBox("请先暂停并关闭话语编辑窗口，再添加任务。")
        return
    }
    if Mode = "custom" {
        Jobs.Push({path: "", name: "当前对话（不上传PDF）", qs: [1], msgs: [DefaultCustomMessage()]})
        try {
            SaveCustomJobs()
            OpenCustomManager()
        } catch as e
            MsgBox("添加失败：" e.Message)
    } else {
        FileAppend("@NO_PDF`r`n", TaskPath, "UTF-8")
        ReloadJobs()
    }
}

; ===== V4.6：管理每份PDF上传时的说明（独立于三种正式话语模式） =====
; 没有为某PDF设置专属说明时，严格保持V4.5原始上传话语。
DefaultUploadIntro(job) {
    return "请接收这份PDF《" job.name "》，后续提问均针对这份PDF。"
}

UploadIntroKey(path) {
    return StrLower(Trim(path))
}

GetUploadIntro(job) {
    global UploadIntroMap
    if job.path = ""
        return ""
    key := UploadIntroKey(job.path)
    return UploadIntroMap.Has(key) ? UploadIntroMap[key] : DefaultUploadIntro(job)
}

; 文件存放在AppData，而不是脚本当前文件夹；换V4.x版本也不会丢失。
; 路径和话语都编码为一行，支持中文、|、%、换行。
LoadUploadIntros() {
    global UploadIntroPath, UploadIntroMap
    UploadIntroMap := Map()
    if !FileExist(UploadIntroPath)
        return
    for line in StrSplit(StrReplace(FileRead(UploadIntroPath, "UTF-8"), "`r", ""), "`n") {
        if Trim(line) = "" || SubStr(line, 1, 1) = "#"
            continue
        sep := InStr(line, "|")
        if !sep
            continue
        path := UnescapeCustomField(SubStr(line, 1, sep-1))
        msg := UnescapeCustomField(SubStr(line, sep+1))
        ; 有路径且分隔符存在，即使说明为空也保留这条自定义记录。
        ; "路径|" 代表不发送上传说明（只发送PDF），与"未设置"严格区分。
        if path != ""
            UploadIntroMap[UploadIntroKey(path)] := msg
    }
}

SaveUploadIntros() {
    global UploadIntroMap, UploadIntroPath
    content := "# Gemini V4.6 每份PDF上传说明。请在脚本窗口里编辑；不同发送模式共享同一PDF的上传说明。`r`n"
    for path, msg in UploadIntroMap {
        ; 空白说明是允许的：仍然写出路径|，下次启动不会恢复默认话语。
        content .= EscapeCustomField(path) "|" EscapeCustomField(msg) "`r`n"
    }
    temp := UploadIntroPath ".new"
    if FileExist(temp)
        FileDelete(temp)
    FileAppend(content, temp, "UTF-8")
    FileMove(temp, UploadIntroPath, 1)
    ; 保存后立即读取磁盘，检查写入是否成功，避免退出后丢失。
    if !FileExist(UploadIntroPath)
        throw Error("上传说明未写入磁盘")
}

OpenUploadIntroManager(*) {
    global UploadIntroGui, UploadIntroList, UploadIntroEditor, Jobs, Running, Busy, ManagerGui, EditorOpen
    if Running || Busy {
        MsgBox("请先F9暂停发送，再修改PDF的上传说明。")
        return
    }
    if EditorOpen || IsObject(ManagerGui) {
        MsgBox("请先关闭功能二的话语管理窗口。")
        return
    }
    if IsObject(UploadIntroGui) {
        WinActivate("ahk_id " UploadIntroGui.Hwnd)
        return
    }
    hasPdf := false
    for job in Jobs {
        if job.path != "" {
            hasPdf := true
            break
        }
    }
    if !hasPdf {
        MsgBox("当前模式还没有PDF任务，请先点击【添加 PDF 任务】。")
        return
    }
    uploadIntroManagerWin := Gui("+AlwaysOnTop", "每份PDF上传说明 · 独立编辑")
    uploadIntroManagerWin.SetFont("s9", "Microsoft YaHei")
    uploadIntroManagerWin.AddText("xm w770", "这里修改的是上传PDF时的第一句说明，不是上传后的逐题提问/固定话语。每份PDF可设置不同内容。")
    UploadIntroList := uploadIntroManagerWin.AddListView("xm y+8 w770 r10 Grid Checked +Multi", ["序号", "PDF", "状态", "上传说明预览"])
    UploadIntroList.ModifyCol(1, 45)
    UploadIntroList.ModifyCol(2, 205)
    UploadIntroList.ModifyCol(3, 65)
    UploadIntroList.ModifyCol(4, 440)
    UploadIntroList.OnEvent("DoubleClick", (control, clickedRow) => EditUploadIntro(clickedRow))
    uploadIntroManagerWin.AddButton("xm y+10 w150 h30 Default", "编辑选中PDF说明").OnEvent("Click", (*) => EditUploadIntro())
    uploadIntroManagerWin.AddButton("x+9 yp w135 h30", "恢复选中PDF默认").OnEvent("Click", (*) => ResetUploadIntro())
    uploadIntroManagerWin.AddButton("x+9 yp w120 h30", "刷新列表").OnEvent("Click", RefreshUploadIntroManager)
    uploadIntroManagerWin.AddButton("x+9 yp w115 h30", "关闭管理窗口").OnEvent("Click", CloseUploadIntroManager)
    uploadIntroManagerWin.AddButton("xm y+8 w110 h29", "全选PDF").OnEvent("Click", (*) => SelectAllListRows(UploadIntroList))
    uploadIntroManagerWin.AddButton("x+8 yp w110 h29", "取消全选").OnEvent("Click", (*) => ClearAllListRows(UploadIntroList))
    uploadIntroManagerWin.AddButton("x+8 yp w165 h29", "批量同一句上传说明").OnEvent("Click", OpenBulkUploadIntroEditor)
    uploadIntroManagerWin.AddButton("x+8 yp w145 h29", "批量设为空白").OnEvent("Click", (*) => ApplyBulkUploadIntro(""))
    uploadIntroManagerWin.AddText("xm y+10 w770", "推荐勾选每行左侧方框来指定PDF；也支持Ctrl/Shift高亮。勾选优先；全选/取消全选可见。")
    uploadIntroManagerWin.OnEvent("Close", CloseUploadIntroManager)
    UploadIntroGui := uploadIntroManagerWin
    RefreshUploadIntroManager()
    uploadIntroManagerWin.Show("w800 h440")
}

RefreshUploadIntroManager(*) {
    global UploadIntroGui, UploadIntroList, UploadIntroMap, Jobs
    if !IsObject(UploadIntroGui)
        return
    ; 保存已经勾选的任务序号，不要在保存后刷新列表时丢掉选择。
    marked := Map()
    previous := 0
    while previous := UploadIntroList.GetNext(previous, "Checked") {
        identifier := Trim(UploadIntroList.GetText(previous, 1))
        if RegExMatch(identifier, "^\d+$")
            marked[identifier] := true
    }
    UploadIntroList.Delete()
    for i, job in Jobs {
        if job.path = ""
            continue
        msg := GetUploadIntro(job)
        customized := !UploadIntroMap.Has(UploadIntroKey(job.path)) ? "默认" : (Trim(msg) = "" ? "不发说明" : "自定义")
        preview := Trim(msg) = "" ? "（仅发送PDF；跳过上传说明）" : SubStr(StrReplace(msg, "`n", " "), 1, 90)
        UploadIntroList.Add(marked.Has(String(i)) ? "Check" : "", i, job.name, customized, preview)
    }
}

SelectedUploadIntroJob(preferredRow := 0) {
    global UploadIntroList, Jobs
    row := preferredRow > 0 ? preferredRow : 0
    if !row {
        markedRow := UploadIntroList.GetNext(0, "Checked")
        if markedRow && UploadIntroList.GetNext(markedRow, "Checked") {
            MsgBox("勾选了多份PDF。单独编辑请只勾一份，或者直接双击你要编辑的PDF那一行。")
            return 0
        }
        row := markedRow ? markedRow : UploadIntroList.GetNext()
    }
    if !row
        row := UploadIntroList.GetNext(0, "Focused")
    if !row {
        MsgBox("请点选该PDF所在行，或在它左侧勾选方框。")
        return 0
    }
    identifier := Trim(UploadIntroList.GetText(row, 1))
    if !RegExMatch(identifier, "^\d+$")
        return 0
    index := Number(identifier)
    if index < 1 || index > Jobs.Length || Jobs[index].path = ""
        return 0
    return index
}

; V4.9：选择多行后的索引由第一列任务号决定（避免忽略无PDF任务时错行）。
SelectedJobIndices(view, includeNoPdf := false) {
    global Jobs
    result := []
    seen := Map()
    ; 若至少有一个方框被勾选，只处理被勾选的PDF，避免误用旧的高亮行。
    selectionType := view.GetNext(0, "Checked") ? "Checked" : ""
    row := 0
    while row := view.GetNext(row, selectionType) {
        val := Trim(view.GetText(row, 1))
        if !RegExMatch(val, "^\d+$")
            continue
        i := Number(val)
        if i >= 1 && i <= Jobs.Length && (includeNoPdf || Jobs[i].path != "") && !seen.Has(i) {
            result.Push(i)
            seen[i] := true
        }
    }
    return result
}

SelectAllListRows(view) {
    if view.GetCount() = 0
        return
    view.Modify(0, "Select Check")
    view.Modify(1, "Focus Vis")
    if view.GetNext(0, "Checked") = 0
        MsgBox("没有成功勾选。请检查列表是否可操作。")
}

ClearAllListRows(view) {
    view.Modify(0, "-Select -Check")
}

OpenBulkUploadIntroEditor(*) {
    global UploadIntroList, UploadIntroEditor
    if IsObject(UploadIntroEditor)
        return
    indices := SelectedJobIndices(UploadIntroList)
    if indices.Length = 0 {
        MsgBox("请先在列表里选中若干份PDF，或点【全选PDF】。")
        return
    }
    ed := Gui("+AlwaysOnTop", "批量设置 " indices.Length " 份PDF的上传说明")
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w630", "下面文字将同时应用到选中的PDF；留空=只上传PDF，不附带上传说明。")
    field := ed.AddEdit("xm y+8 w630 r7 VScroll")
    ed.AddButton("xm y+10 w150 Default", "批量保存").OnEvent("Click", (*) => ApplyBulkUploadIntro(field.Value, indices, ed))
    ed.AddButton("x+8 yp w120", "取消").OnEvent("Click", (*) => CloseUploadIntroEditor(ed))
    ed.OnEvent("Close", (*) => CloseUploadIntroEditor(ed))
    UploadIntroEditor := ed
    ed.Show("w670 h300")
}

ApplyBulkUploadIntro(textValue, selected := 0, editor := 0) {
    global UploadIntroList, UploadIntroMap, Jobs, Running, Busy, UploadIntroGui
    try {
        if IsObject(editor)
            editor.Opt("+OwnDialogs")
        else if IsObject(UploadIntroGui)
            UploadIntroGui.Opt("+OwnDialogs")
    }
    if Running || Busy {
        MsgBox("请先按F9暂停后再批量编辑。")
        return
    }
    indices := selected is Array ? selected : SelectedJobIndices(UploadIntroList)
    if indices.Length = 0 {
        MsgBox("请先选择PDF，或点击【全选PDF】。")
        return
    }
    msg := Trim(textValue, " `t`r`n")
    ; V4.9.2：批量保存按钮本身就是确认，不再另外弹“是/否”。
    previous := Map()
    for i in indices {
        key := UploadIntroKey(Jobs[i].path)
        if !previous.Has(key)
            previous[key] := UploadIntroMap.Has(key) ? {exists: true, value: UploadIntroMap[key]} : {exists: false}
        UploadIntroMap[key] := msg
    }
    try {
        SaveUploadIntros()
        LoadUploadIntros()
        for i in indices {
            key := UploadIntroKey(Jobs[i].path)
            if !UploadIntroMap.Has(key) || UploadIntroMap[key] != msg
                throw Error("写入后读回不一致：" Jobs[i].name)
        }
        if IsObject(editor)
            CloseUploadIntroEditor(editor)
        RefreshUploadIntroManager()
        SetStatus("✓ 批量保存完成：" indices.Length " 份PDF上传说明" (msg = "" ? "（只发PDF）" : "") "。")
    } catch as e {
        for key, old in previous {
            if old.exists
                UploadIntroMap[key] := old.value
            else if UploadIntroMap.Has(key)
                UploadIntroMap.Delete(key)
        }
        try SaveUploadIntros()
        MsgBox("批量保存失败：" e.Message, "错误", "Iconx")
    }
}

EditUploadIntro(clickedRow := 0) {
    global UploadIntroGui, UploadIntroEditor, Jobs, Running, Busy
    if Running || Busy || IsObject(UploadIntroEditor)
        return
    i := SelectedUploadIntroJob(clickedRow)
    if !i
        return
    job := Jobs[i]
    editor := Gui("+AlwaysOnTop", "编辑第" i "份PDF的上传说明：" job.name)
    editor.SetFont("s10", "Microsoft YaHei")
    editor.AddText("xm w765", "这里填写上传说明；可以完全留空：届时只发送PDF，不发任何上传说明。其他PDF不受影响。")
    field := editor.AddEdit("xm y+9 w765 r6 VScroll", GetUploadIntro(job))
    editor.AddButton("xm y+10 w145 h32 Default", "保存这份PDF说明").OnEvent("Click", (*) => SaveUploadIntroEditor(job, field.Value, editor))
    editor.AddButton("x+10 yp w135 h32", "取消不保存").OnEvent("Click", (*) => CloseUploadIntroEditor(editor))
    editor.OnEvent("Close", (*) => CloseUploadIntroEditor(editor))
    UploadIntroEditor := editor
    editor.Show("w800 h270")
}

SaveUploadIntroEditor(job, textValue, editor) {
    global UploadIntroMap, Running, Busy
    try editor.Opt("+OwnDialogs")
    if Running || Busy {
        MsgBox("请先F9暂停发送。")
        return
    }
    ; 空白＝明确选择不发上传说明；不等于恢复默认。
    message := Trim(textValue, " `t`r`n")
    key := UploadIntroKey(job.path)
    oldHad := UploadIntroMap.Has(key)
    oldValue := oldHad ? UploadIntroMap[key] : ""
    UploadIntroMap[key] := message
    try {
        SaveUploadIntros()
        ; 重新读取持久文件，确认这份PDF的内容确实保存一致。
        LoadUploadIntros()
        if !UploadIntroMap.Has(key) || UploadIntroMap[key] != message
            throw Error("保存后读取结果不一致")
        CloseUploadIntroEditor(editor)
        RefreshUploadIntroManager()
        SetStatus("✓ 《" job.name "》的上传说明已保存。" (message = "" ? "只发送PDF，不附加说明。" : ""))
    } catch as e {
        if oldHad
            UploadIntroMap[key] := oldValue
        else if UploadIntroMap.Has(key)
            UploadIntroMap.Delete(key)
        MsgBox("保存失败：" e.Message, "错误", "Iconx")
    }
}

ResetUploadIntro(*) {
    global UploadIntroMap, Running, Busy, Jobs
    if Running || Busy
        return
    i := SelectedUploadIntroJob()
    if !i
        return
    key := UploadIntroKey(Jobs[i].path)
    if !UploadIntroMap.Has(key) {
        MsgBox("这份PDF已经在使用默认说明。")
        return
    }
    ; 用户点击“恢复选中PDF默认”即视为确认。
    oldValue := UploadIntroMap[key]
    UploadIntroMap.Delete(key)
    try {
        SaveUploadIntros()
        RefreshUploadIntroManager()
    } catch as e {
        UploadIntroMap[key] := oldValue
        MsgBox("恢复默认失败：" e.Message, "错误", "Iconx")
    }
}

CloseUploadIntroEditor(editor) {
    global UploadIntroEditor
    if IsObject(UploadIntroEditor) {
        try editor.Destroy()
        UploadIntroEditor := 0
    }
}

CloseUploadIntroManager(*) {
    global UploadIntroGui, UploadIntroList, UploadIntroEditor
    if IsObject(UploadIntroEditor) {
        MsgBox("请先保存或关闭正在编辑的PDF上传说明。")
        return
    }
    if IsObject(UploadIntroGui) {
        UploadIntroGui.Destroy()
        UploadIntroGui := 0
        UploadIntroList := 0
    }
}

DefaultCustomMessage() {
    global PrefPath
    return IniRead(PrefPath, "custom", "default_message", "请帮我整理申论，生成Word")
}

; 任务清单编码，允许文字里包含竖线、百分号、逗号及换行；不会误分割话语。
EscapeCustomField(s) {
    s := StrReplace(s, "%", "%25")
    s := StrReplace(s, "|", "%7C")
    s := StrReplace(s, "`r", "%0D")
    return StrReplace(s, "`n", "%0A")
}
UnescapeCustomField(s) {
    s := StrReplace(s, "%0A", "`n")
    s := StrReplace(s, "%0D", "`r")
    s := StrReplace(s, "%7C", "|")
    return StrReplace(s, "%25", "%")
}

; 修改功能二任务后只重置功能二的进度，不触碰原版和功能一的进度。
SaveCustomJobs() {
    global Mode, Jobs, TaskPath, Running, Busy
    if (Mode != "custom" && Mode != "together") || Running || Busy
        throw Error("只能在已暂停的功能二/功能三下修改")
    content := TaskTemplate()
    for job in Jobs {
        if Mode = "together" && (job.path = "" || job.msgs.Length != 1 || Trim(job.msgs[1]) = "")
            throw Error("功能三每份PDF必须有且仅有一条非空话语：" job.name)
        if job.path = "" && job.msgs.Length = 0
            throw Error("纯文字任务必须至少有一句话：" job.name)
        line := EscapeCustomField(job.path = "" ? "@NO_PDF" : job.path)
        if job.msgs.Length = 0
            line .= "|%00"  ; 功能二：明确标记无后续话语，不依赖尾随分隔符解析
        for m in job.msgs {
            if Trim(m) = ""
                throw Error("PDF：" job.name " 有空白话语")
            line .= "|" EscapeCustomField(m)
        }
        content .= line "`r`n"
    }
    temp := TaskPath ".new"
    if FileExist(temp)
        FileDelete(temp)
    FileAppend(content, temp, "UTF-8")
    ; 写入完成才替换任务清单，并从真实文件重读校验（不能只相信内存）。
    saved := FileRead(temp, "UTF-8")
    if StrReplace(saved, "`r", "") != StrReplace(content, "`r", "")
        throw Error("临时任务文件写入校验失败")
    FileMove(temp, TaskPath, 1)
    saved := FileRead(TaskPath, "UTF-8")
    if StrReplace(saved, "`r", "") != StrReplace(content, "`r", "")
        throw Error("任务文件保存后读回不一致")
    ResetState(ManifestId(saved))
    ReloadJobs()
    RefreshCustomManager()
}

; 功能二不需要编辑代码，在管理窗口中选PDF、编辑/新增/删除话语即可。
OpenCustomManager(*) {
    global Mode, ManagerGui, ManagerList, MainGui, Running, Busy
    if Mode != "custom" && Mode != "together" {
        MsgBox("请先切换到功能二或功能三。")
        return
    }
    if IsObject(ManagerGui) {
        try WinActivate("ahk_id " ManagerGui.Hwnd)
        return
    }
    mgr := Gui("+AlwaysOnTop", Mode = "together" ? "功能三 · 每份PDF只上传并发送一句" : "功能二 · 每份PDF分别设置发送次数及话语")
    mgr.SetFont("s10", "Microsoft YaHei")
    mgr.AddText("xm w855", Mode = "together" ? "每份PDF只设置一句话，与PDF在同一条消息发送；可批量统一设置。" : "每份PDF可设置多句话；一行一条。批量清空后只发送上传说明，不再单独追问。")
    ManagerList := mgr.AddListView("xm y+8 w855 r11 Grid Checked +Multi", ["序号", "PDF", "话语数", "首句话预览"])
    ManagerList.ModifyCol(1, 48)
    ManagerList.ModifyCol(2, 295)
    ManagerList.ModifyCol(3, 75)
    ManagerList.ModifyCol(4, 425)
    ManagerList.OnEvent("DoubleClick", (control, clickedRow) => EditCustomJob(clickedRow))
    add := mgr.AddButton("xm y+12 w118", "添加PDF")
    add.OnEvent("Click", AddPdfJob)
    edit := mgr.AddButton("x+6 yp w128", "编辑这份话语")
    edit.OnEvent("Click", (*) => EditCustomJob())
    del := mgr.AddButton("x+6 yp w105", "删除这份PDF")
    del.OnEvent("Click", DeleteCustomJob)
    up := mgr.AddButton("x+6 yp w100", "向上移动")
    up.OnEvent("Click", (*) => MoveCustomJob(-1))
    down := mgr.AddButton("x+6 yp w100", "向下移动")
    down.OnEvent("Click", (*) => MoveCustomJob(1))
    mgr.AddButton("xm y+9 w110", "全选PDF").OnEvent("Click", (*) => SelectAllListRows(ManagerList))
    mgr.AddButton("x+7 yp w110", "取消全选").OnEvent("Click", (*) => ClearAllListRows(ManagerList))
    mgr.AddButton("x+7 yp w165", "批量设置相同话语").OnEvent("Click", OpenBulkCustomEditor)
    bulkClearBtn := mgr.AddButton("x+7 yp w145", "批量设为空白")
    bulkClearBtn.Enabled := Mode = "custom"
    bulkClearBtn.OnEvent("Click", (*) => ApplyBulkCustomMessages(""))
    mgr.AddText("xm y+9 w855", Mode = "together" ? "勾选指定PDF后批量设置；功能三每PDF只有一句，禁止空白。" : "勾选左侧复选框指定PDF，批量空白只清除功能二后续话语；支持Ctrl/Shift高亮。")
    mgr.OnEvent("Close", CloseCustomManager)
    ManagerGui := mgr
    RefreshCustomManager()
    mgr.Show("w880 h470")
}

CloseCustomManager(*) {
    global ManagerGui, ManagerList, EditorOpen
    if EditorOpen {
        MsgBox("请先保存或取消正在编辑的话语。")
        return
    }
    if IsObject(ManagerGui)
        ManagerGui.Destroy()
    ManagerGui := 0
    ManagerList := 0
}

RefreshCustomManager() {
    global Mode, Jobs, ManagerGui, ManagerList
    if (Mode != "custom" && Mode != "together") || !IsObject(ManagerGui)
        return
    marked := Map()
    previous := 0
    while previous := ManagerList.GetNext(previous, "Checked") {
        identifier := Trim(ManagerList.GetText(previous, 1))
        if RegExMatch(identifier, "^\d+$")
            marked[identifier] := true
    }
    ManagerList.Delete()
    for i, job in Jobs {
        preview := job.msgs.Length ? StrReplace(job.msgs[1], "`n", " ") : ""
        ManagerList.Add(marked.Has(String(i)) ? "Check" : "", i, job.name, job.msgs.Length, SubStr(preview, 1, 75))
    }
}

SelectedCustomRow(preferredRow := 0) {
    global ManagerGui, ManagerList, Jobs
    if !IsObject(ManagerGui)
        return 0
    row := preferredRow > 0 ? preferredRow : 0
    if !row {
        markedRow := ManagerList.GetNext(0, "Checked")
        if markedRow && ManagerList.GetNext(markedRow, "Checked") {
            MsgBox("勾选了多份PDF。单独编辑请只勾一份，或者直接双击要编辑的那一行。")
            return 0
        }
        row := markedRow ? markedRow : ManagerList.GetNext()
    }
    if !row
        row := ManagerList.GetNext(0, "Focused")
    if !row {
        MsgBox("请点击一份PDF所在行，或勾选左侧方框。")
        return 0
    }
    identifier := Trim(ManagerList.GetText(row, 1))
    if !RegExMatch(identifier, "^\d+$")
        return 0
    index := Number(identifier)
    if index < 1 || index > Jobs.Length
        return 0
    return index
}

JoinCustomMessages(msgs) {
    result := ""
    for m in msgs
        result .= (A_Index = 1 ? "" : "`r`n") m
    return result
}

EditCustomJob(clickedRow := 0) {
    global Mode, Jobs, EditorOpen, ManagerGui
    if (Mode != "custom" && Mode != "together") || EditorOpen
        return
    row := SelectedCustomRow(clickedRow)
    if !row
        return
    EditorOpen := true
    ed := Gui("+AlwaysOnTop", "编辑第" row "份PDF的话语：" Jobs[row].name)
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w795", Mode = "together" ? "只写一句话，PDF和这句一起发送。" : "一行 = 发送一次；留空则不发送后续话语。")
    field := ed.AddEdit("xm y+8 w795 r12 VScroll", JoinCustomMessages(Jobs[row].msgs))
    ; 保存按钮始终新起一行：修复功能三没有【再添加一句】时保存按钮被挤到屏幕外。
    save := ed.AddButton("xm y+12 w155 Default", "保存这份话语")
    save.OnEvent("Click", (*) => SaveCustomEditor(row, field.Value, ed))
    if Mode = "custom" {
        more := ed.AddButton("x+9 yp w140", "再添加一句")
        more.OnEvent("Click", (*) => AppendBlankMessage(field))
    }
    cancel := ed.AddButton("x+9 yp w110", "取消")
    cancel.OnEvent("Click", (*) => CloseCustomEditor(ed))
    ed.OnEvent("Close", (*) => CloseCustomEditor(ed))
    ed.Show("w825 h390")
}

AppendBlankMessage(field) {
    field.Value .= "`r`n"
    field.Focus()
    Send("^{End}")
}

CloseCustomEditor(editor) {
    global EditorOpen
    EditorOpen := false
    try editor.Destroy()
}

SaveCustomEditor(row, value, editor) {
    global Jobs, Running, Busy, Mode
    try editor.Opt("+OwnDialogs")
    if Running || Busy {
        MsgBox("正在发送，不能修改。请先F9暂停。")
        return
    }
    msgs := []
    for line in StrSplit(StrReplace(value, "`r", ""), "`n") {
        line := Trim(line, " `t`r`n")
        if line != ""
            msgs.Push(line)
    }
    if Mode = "together" && msgs.Length != 1 {
        MsgBox("功能三每份PDF只允许一句非空话语，请调整后保存。")
        return
    }
    ; V4.9.2：点击“保存这份话语”后立即保存并读回校验。
    old := Jobs[row].msgs
    Jobs[row].msgs := msgs
    try {
        SaveCustomJobs()
        CloseCustomEditor(editor)
        SetStatus("✓ 已保存第" row "份PDF的" msgs.Length "条话语；当前模式进度已重置。")
    } catch as e {
        Jobs[row].msgs := old
        MsgBox("保存失败：" e.Message)
    }
}

; V4.9：功能二批量多句/空白；功能三批量单句，均只重置当前模式的进度。
OpenBulkCustomEditor(*) {
    global Mode, ManagerList, EditorOpen
    if EditorOpen
        return
    indices := SelectedJobIndices(ManagerList, Mode = "custom")
    if indices.Length = 0 {
        MsgBox("请先多选PDF，或点【全选PDF】。")
        return
    }
    EditorOpen := true
    ed := Gui("+AlwaysOnTop", "批量修改" indices.Length "份PDF的话语")
    ed.SetFont("s10", "Microsoft YaHei")
    ed.AddText("xm w700", Mode = "together" ? "功能三：下面只能填一句话；每份PDF与它同时发出。" : "功能二：每行一句话，可写多行；完全留空=不发送后续话语。")
    field := ed.AddEdit("xm y+10 w700 r8 VScroll")
    ed.AddButton("xm y+10 w140 Default", "批量保存").OnEvent("Click", (*) => ApplyBulkCustomMessages(field.Value, indices, ed))
    ed.AddButton("x+8 yp w120", "取消").OnEvent("Click", (*) => CloseCustomEditor(ed))
    ed.OnEvent("Close", (*) => CloseCustomEditor(ed))
    ed.Show("w735 h335")
}

ApplyBulkCustomMessages(rawText, indices := 0, editor := 0) {
    global Mode, ManagerList, Jobs, Running, Busy, ManagerGui
    try {
        if IsObject(editor)
            editor.Opt("+OwnDialogs")
        else if IsObject(ManagerGui)
            ManagerGui.Opt("+OwnDialogs")
    }
    if Running || Busy {
        MsgBox("先F9暂停再修改。")
        return
    }
    if Mode != "custom" && Mode != "together"
        return
    indices := indices is Array ? indices : SelectedJobIndices(ManagerList, Mode = "custom")
    if indices.Length = 0 {
        MsgBox("请先在列表中选中PDF，或点击全选PDF。")
        return
    }
    msgs := []
    for line in StrSplit(StrReplace(rawText, "`r", ""), "`n") {
        line := Trim(line)
        if line != ""
            msgs.Push(line)
    }
    if Mode = "together" && msgs.Length != 1 {
        MsgBox("功能三必须且只能填写一句非空话语，不支持批量留空。")
        return
    }
    ; V4.9.2：点击“批量保存”即直接作用于当前勾选的PDF。
    old := Map()
    for i in indices {
        old[i] := Jobs[i].msgs
        Jobs[i].msgs := msgs.Clone()
    }
    try {
        SaveCustomJobs()
        if IsObject(editor)
            CloseCustomEditor(editor)
        SetStatus("✓ 批量保存成功：" indices.Length "份PDF，每份" msgs.Length "条话语；本模式进度已重置。")
    } catch as e {
        for i, messages in old
            Jobs[i].msgs := messages
        MsgBox("批量保存失败：" e.Message, "错误", "Iconx")
    }
}

DeleteCustomJob(button := 0, *) {
    global Jobs, Running, Busy
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    row := SelectedCustomRow()
    if !row || Running || Busy
        return
    if MsgBox("确定删除第" row "份PDF任务？`n只删除任务记录，不会删除PDF文件。功能二进度将重置。", "删除任务", "YesNo Icon!") != "Yes"
        return
    old := Jobs.RemoveAt(row)
    try SaveCustomJobs()
    catch as e {
        Jobs.InsertAt(row, old)
        MsgBox("删除失败：" e.Message)
    }
}

MoveCustomJob(dir) {
    global Jobs, Running, Busy, ManagerList
    row := SelectedCustomRow()
    if !row || Running || Busy
        return
    dest := row + dir
    if dest < 1 || dest > Jobs.Length
        return
    temp := Jobs[row]
    Jobs[row] := Jobs[dest]
    Jobs[dest] := temp
    try {
        SaveCustomJobs()
        ManagerList.Modify(dest, "Select Focus Vis")
    } catch as e {
        Jobs[dest] := Jobs[row]
        Jobs[row] := temp
        MsgBox("移动失败：" e.Message)
    }
}

GetChat() {
    global ChatHwnd, MainGui
    ; 已绑定的窗口优先，支持 Chrome/Edge 安装成应用的 Gemini。
    if (ChatHwnd && WinExist("ahk_id " ChatHwnd))
        return ChatHwnd
    ; 自动寻找标题包含 Gemini 的窗口；若失败，按 Ctrl+Alt+0 手动绑定。
    try {
        active := WinGetID("A")
        if IsGeminiWindow(active)
            return active
    }
    for h in WinGetList() {
        if IsGeminiWindow(h)
            return h
    }
    return 0
}

IsGeminiWindow(h) {
    global MainGui
    if !h || (h = MainGui.Hwnd)
        return false
    try {
        title := StrLower(WinGetTitle("ahk_id " h))
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "explorer.exe" || exe = "chatgpt.exe" || InStr(exe, "autohotkey"))
            return false
        return InStr(title, "gemini") > 0
    }
    return false
}

BindGeminiWindow(*) {
    global ChatHwnd, MainGui
    try {
        h := WinGetID("A")
        if !h || h = MainGui.Hwnd {
            MsgBox("先切换到 Gemini 桌面应用窗口，再按 Ctrl+Alt+0。", "窗口未绑定")
            return
        }
        title := WinGetTitle("ahk_id " h)
        exe := StrLower(WinGetProcessName("ahk_id " h))
        if (exe = "chatgpt.exe" || exe = "explorer.exe" || InStr(exe, "autohotkey")) {
            MsgBox("当前窗口看起来不是 Gemini，请切换到 Gemini 应用再试。", "绑定失败")
            return
        }
        if !InStr(StrLower(title), "gemini") {
            if MsgBox("当前窗口标题不含 Gemini：`n" title "`n确定把它当作 Gemini 目标窗口吗？", "确认绑定", "YesNo Icon?") != "Yes"
                return
        }
        ChatHwnd := h
        ToolTip("已绑定 Gemini 窗口；现在校准附件＋、上传菜单、输入框")
        SetTimer(() => ToolTip(), -2300)
        UpdateCalibration()
    } catch as e {
        MsgBox("绑定失败：" e.Message)
    }
}

ActivateChat() {
    global ChatHwnd
    h := GetChat()
    if !h
        throw Error("找不到 Gemini 窗口；打开 Gemini 应用，切入目标对话并按 Ctrl+Alt+0 绑定")
    ChatHwnd := h
    WinActivate("ahk_id " h)
    if !WinWaitActive("ahk_id " h, , 5)
        throw Error("无法激活 Gemini 窗口")
    return h
}

Calibrate(which) {
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY, PrefPath
    h := GetChat()
    if !h {
        MsgBox("先打开 Gemini 桌面端，并按 Ctrl+Alt+0 绑定窗口，再将鼠标悬停在要校准的位置。", "无法校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx - wx
    ry := my - wy
    if (which = "plus") {
        PlusX := rx, PlusY := ry
        IniWrite(rx, PrefPath, "coords", "plusX")
        IniWrite(ry, PrefPath, "coords", "plusY")
        title := "附件＋号"
    } else if (which = "upload") {
        UploadX := rx, UploadY := ry
        IniWrite(rx, PrefPath, "coords", "uploadX")
        IniWrite(ry, PrefPath, "coords", "uploadY")
        title := "上传文件菜单"
    } else if (which = "attached_input") {
        AttachedInputX := rx, AttachedInputY := ry
        IniWrite(rx, PrefPath, "coords", "attachedInputX")
        IniWrite(ry, PrefPath, "coords", "attachedInputY")
        title := "PDF已附加时的输入框"
    } else {
        InputX := rx, InputY := ry
        IniWrite(rx, PrefPath, "coords", "inputX")
        IniWrite(ry, PrefPath, "coords", "inputY")
        title := "普通聊天输入框"
    }
    UpdateCalibration()
    ToolTip("已保存：" title "（" rx ", " ry "）")
    SetTimer(() => ToolTip(), -1800)
}

UpdateCalibration() {
    global CalText, PlusX, UploadX, InputX, AttachedInputX, FreshPlusX, FreshUploadX, FreshInputX, NewChatX
    CalText.Text := "定位状态：附件＋ " (PlusX = "" ? "未设" : "✓")
        . "   上传菜单 " (UploadX = "" ? "未设" : "✓")
        . "   普通输入框 " (InputX = "" ? "未设" : "✓")
        . "   附件输入框 " (AttachedInputX = "" ? "自动估计" : "✓")
        . "`n新对话：附件＋ " (FreshPlusX = "" ? "待校准5" : "✓")
        . "  上传菜单 " (FreshUploadX = "" ? "待校准6" : "✓")
        . "  输入框 " (FreshInputX = "" ? "待校准7" : "✓")
        . "  自动新建 " (NewChatX = "" ? "未校准9" : "✓")
}

ClickChat(which) {
    global InFreshComposer
    global PlusX, PlusY, UploadX, UploadY, InputX, InputY, AttachedInputX, AttachedInputY
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY, FreshInputX, FreshInputY, FreshAttachedX, FreshAttachedY
    global NewChatX, NewChatY
    h := ActivateChat()
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    if which = "new_chat" {
        rx := NewChatX, ry := NewChatY
    } else if InFreshComposer {
        if which = "plus"
            rx := FreshPlusX, ry := FreshPlusY
        else if which = "upload"
            rx := FreshUploadX, ry := FreshUploadY
        else if which = "attached_input" {
            if FreshAttachedX != "" && FreshAttachedY != ""
                rx := FreshAttachedX, ry := FreshAttachedY
            else if FreshPlusX != "" && FreshPlusY != ""
                rx := Number(FreshPlusX)+145, ry := Number(FreshPlusY)-100
            else
                rx := "", ry := ""
        } else
            rx := FreshInputX, ry := FreshInputY
    } else {
        if which = "plus"
            rx := PlusX, ry := PlusY
        else if which = "upload"
            rx := UploadX, ry := UploadY
        else if which = "attached_input" {
            if AttachedInputX != "" && AttachedInputY != ""
                rx := AttachedInputX, ry := AttachedInputY
            else if PlusX != "" && PlusY != ""
                rx := Number(PlusX)+145, ry := Number(PlusY)-100
            else
                rx := InputX, ry := InputY
        } else
            rx := InputX, ry := InputY
    }
    if rx = "" || ry = ""
        throw Error("当前" (InFreshComposer ? "空白新对话" : "旧对话") "尚未校准：" which "。请使用脚本上方对应快捷键校准。")
    Click(wx+Number(rx), wy+Number(ry))
}

PutClipboard(text) {
    old := ClipboardAll()
    try {
        A_Clipboard := ""
        A_Clipboard := text
        if !ClipWait(3)
            throw Error("写入剪贴板失败")
        Send("^v")
        ; Gemini有时延迟读取粘贴文本，不能过早还原剪贴板。
        Sleep(1100)
    } finally {
        A_Clipboard := old
    }
}

NormalizeGeminiMessage(s) {
    ; 统一浏览器编辑框常见的换行、不可见字符和不换行空格。
    ; 不改动正文标点，避免校验时把合法话语误判成不同内容。
    s := StrReplace(StrReplace(s, "`r`n", "`n"), "`r", "`n")
    s := StrReplace(s, Chr(0xA0), " ")
    s := StrReplace(s, Chr(0x200B), "")
    s := StrReplace(s, Chr(0xFEFF), "")
    return Trim(s, " `t`r`n")
}

GeminiMessagesEquivalent(actual, expected) {
    ; Electron/contenteditable 可能把粘贴内容中的空白重新排版。
    ; 先做严格比较，再只忽略空白比较；正文字符和标点仍必须完全一致。
    a := NormalizeGeminiMessage(actual)
    e := NormalizeGeminiMessage(expected)
    if a = e
        return true
    a := RegExReplace(a, "[\s\x{00A0}]+", "")
    e := RegExReplace(e, "[\s\x{00A0}]+", "")
    return a = e
}

WriteGeminiUIAScript() {
    global PrefDir
    path := PrefDir "\Gemini_输入定位_V498.ps1"
    ps := ""
    ps .= "param([Int64]$WindowHandle, [string]$Action = 'locate')" "`r`n"
    ps .= "$ErrorActionPreference = 'Stop'" "`r`n"
    ps .= "try {" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationClient" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationTypes" "`r`n"
    ps .= "    $root = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$WindowHandle)" "`r`n"
    ps .= "    if ($null -eq $root) { Write-Output 'ERROR|no-window'; exit 0 }" "`r`n"
    ps .= "    $win = $root.Current.BoundingRectangle" "`r`n"
    ps .= "    $minY = $win.Top + $win.Height * 0.37" "`r`n"
    ps .= "    $scope = [System.Windows.Automation.TreeScope]::Descendants" "`r`n"
    ps .= "    $cond = [System.Windows.Automation.Condition]::TrueCondition" "`r`n"
    ps .= "    if ($Action -eq 'focus') {" "`r`n"
    ps .= "        $el = [System.Windows.Automation.AutomationElement]::FocusedElement" "`r`n"
    ps .= "        $walker = [System.Windows.Automation.TreeWalker]::RawViewWalker" "`r`n"
    ps .= "        for ($depth=0; $depth -lt 7 -and $null -ne $el; $depth++) {" "`r`n"
    ps .= "            try {" "`r`n"
    ps .= "                $type = $el.Current.ControlType.ProgrammaticName" "`r`n"
    ps .= "                $r = $el.Current.BoundingRectangle" "`r`n"
    ps .= "                if (($type -eq 'ControlType.Edit' -or ($type -eq 'ControlType.Document' -and $r.Width -lt $win.Width * 0.95 -and $r.Top -gt $win.Top + $win.Height * 0.30)) -and !$r.IsEmpty -and $r.Width -gt 85 -and $r.Height -gt 14 -and $r.Bottom -gt ($win.Top + $win.Height * 0.30) -and $r.Left -ge $win.Left - 12 -and $r.Right -gt ($win.Left + $win.Width * 0.55) -and $r.Right -le $win.Right + 12) {" "`r`n"
    ps .= "                    Write-Output 'FOCUSOK'; exit 0" "`r`n"
    ps .= "                }" "`r`n"
    ps .= "            } catch {}" "`r`n"
    ps .= "            $el = $walker.GetParent($el)" "`r`n"
    ps .= "        }" "`r`n"
    ps .= "        Write-Output 'FOCUSNONE'; exit 0" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    $all = $root.FindAll($scope, $cond)" "`r`n"
    ps .= "    $items = New-Object 'System.Collections.Generic.List[object]'" "`r`n"
    ps .= "    for ($i=0; $i -lt $all.Count; $i++) {" "`r`n"
    ps .= "        try {" "`r`n"
    ps .= "            $e = $all.Item($i)" "`r`n"
    ps .= "            if ($e.Current.IsOffscreen) { continue }" "`r`n"
    ps .= "            $r = $e.Current.BoundingRectangle" "`r`n"
    ps .= "            if ($r.IsEmpty -or $r.Width -lt 16 -or $r.Height -lt 14) { continue }" "`r`n"
    ps .= "            $type = $e.Current.ControlType.ProgrammaticName" "`r`n"
    ps .= "            $name = [string]$e.Current.Name" "`r`n"
    ps .= "            $cx = ($r.Left + $r.Right) / 2" "`r`n"
    ps .= "            $cy = ($r.Top + $r.Bottom) / 2" "`r`n"
    ps .= "            if ($Action -eq 'locate') {" "`r`n"
    ps .= "                if (($type -ne 'ControlType.Edit' -and !($type -eq 'ControlType.Document' -and $r.Width -lt $win.Width * 0.95 -and $r.Top -gt $win.Top + $win.Height * 0.30)) -or $r.Width -lt 150 -or $r.Bottom -lt $minY -or $r.Right -gt $win.Right + 12) { continue }" "`r`n"
    ps .= "                $score = $r.Bottom / 100.0" "`r`n"
    ps .= "                if ($name -match '(?i)gemini|ask|prompt|message|提问|询问|输入|消息') { $score += 1000 }" "`r`n"
    ps .= "                if ($r.Height -gt 140) { $score -= 30 }" "`r`n"
    ps .= "                $x = [int][Math]::Min($r.Right-38, $r.Left + [Math]::Min(200, $r.Width*0.38))" "`r`n"
    ps .= "                $y = [int][Math]::Max($r.Top+18, $r.Bottom-[Math]::Min(110, $r.Height*0.42))" "`r`n"
    ps .= "                $items.Add([pscustomobject]@{ Score=$score; X=$x; Y=$y })" "`r`n"
    ps .= "            } elseif ($Action -eq 'plus') {" "`r`n"
    ps .= "                if ($cx -gt $win.Left + $win.Width*0.65 -or $cy -lt $win.Top + $win.Height*0.23) { continue }" "`r`n"
    ps .= "                if ($name -match '(?i)^add$|add (files|attachment|photos)|attach|附件|添加文件|添加照片|上传文件|更多|^\+$') {" "`r`n"
    ps .= "                    $score=1000-($cx-$win.Left)*0.2+($cy-$win.Top)*0.05" "`r`n"
    ps .= "                    $items.Add([pscustomobject]@{ Score=$score; X=[int]$cx; Y=[int]$cy })" "`r`n"
    ps .= "                }" "`r`n"
    ps .= "            } elseif ($Action -eq 'upload') {" "`r`n"
    ps .= "                if ($cy -lt $win.Top + $win.Height*0.32 -or $cx -gt $win.Left + $win.Width*0.84) { continue }" "`r`n"
    ps .= "                if ($name -match '(?i)upload (file|from|photo)|upload$|上传文件|上传图片|上传照片|从设备|添加照片和文件|upload files') {" "`r`n"
    ps .= "                    $score=900" "`r`n"
    ps .= "                    if ($type -match 'MenuItem|Button') { $score += 100 }" "`r`n"
    ps .= "                    $items.Add([pscustomobject]@{ Score=$score; X=[int]$cx; Y=[int]$cy })" "`r`n"
    ps .= "                }" "`r`n"
    ps .= "            }" "`r`n"
    ps .= "        } catch { continue }" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    if ($items.Count -gt 0) {" "`r`n"
    ps .= "        $best = @($items | Sort-Object Score -Descending)[0]" "`r`n"
    ps .= "        Write-Output ('POINT|{0}|{1}' -f $best.X,$best.Y)" "`r`n"
    ps .= "    } else { Write-Output 'NOPOINT' }" "`r`n"
    ps .= "} catch {" "`r`n"
    ps .= "    Write-Output ('ERROR|' + ($_.Exception.Message -replace '[|\r\n]',' '))" "`r`n"
    ps .= "}" "`r`n"
    ; 版本化辅助脚本首次生成；无需每次定位都重写，避免杀毒软件文件占用。
    if !FileExist(path)
        FileAppend(ps, path, "UTF-8")
    return path
}

; V4.9.4：所有 UI Automation 检测统一以隐藏进程执行。
; 旧版 WScript.Shell.Exec(powershell.exe) 会显示控制台并夺取 Gemini 的前台焦点。
; 用隐藏的 cmd /c 重定向 PowerShell 结果文件，避免检测影响鼠标点击和后续输入。
; ===== V4.9.5 诊断辅助（不记录PDF正文或用户完整话语） =====
DiagSafe(value) {
    t := StrReplace(StrReplace(String(value), "`r", " "), "`n", " ")
    return SubStr(t, 1, 210)
}

DiagActiveWindow() {
    try {
        h := WinGetID("A")
        exe := WinGetProcessName("ahk_id " h)
        return "hwnd=" h " exe=" exe
    } catch {
        return "active=unknown"
    }
}

DiagLog(tag, info := "") {
    global DebugPath, DebugSeq, DiagSession, Mode, Stage, JobIndex, Jobs
    global InFreshComposer, ChatHwnd, LastDiagProblem
    try {
        DebugSeq += 1
        jobName := JobIndex >= 1 && JobIndex <= Jobs.Length ? Jobs[JobIndex].name : "(none)"
        line := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") "." Format("{:03}", Mod(A_TickCount, 1000))
            . " [" DiagSession " #" DebugSeq "] " tag
            . " | job=" JobIndex "/" Jobs.Length "(" DiagSafe(jobName) ") mode=" Mode
            . " stage=" Stage " fresh=" (InFreshComposer ? "yes" : "no")
            . " target_hwnd=" ChatHwnd " " DiagActiveWindow()
            . " | " DiagSafe(info) "`r`n"
        if FileExist(DebugPath) && FileGetSize(DebugPath) > 2500000
            FileMove(DebugPath, DebugPath ".old", 1)
        FileAppend(line, DebugPath, "UTF-8")
        if InStr(tag, "FAIL") || InStr(tag, "ERROR") || InStr(tag, "TIMEOUT")
            LastDiagProblem := tag " | " DiagSafe(info)
    } catch {
        ; 日志写入失败不能阻止既有PDF任务运行。
    }
}

OpenDiagnosticLog(*) {
    global DebugPath
    try {
        if !FileExist(DebugPath)
            FileAppend("Gemini V4.9.5 诊断日志`r`n", DebugPath, "UTF-8")
        Run('notepad.exe "' DebugPath '"')
    } catch as e {
        ToolTip("打开日志失败：" e.Message)
        SetTimer(() => ToolTip(), -2800)
    }
}

CopyDiagnosticSummary(*) {
    global DebugPath, LastDiagProblem
    try {
        if !FileExist(DebugPath)
            throw Error("还没有诊断日志，请先运行一次F8。")
        rawText := FileRead(DebugPath, "UTF-8")
        A_Clipboard := "Gemini V4.9.5 诊断摘要（请检查是否含私人文件名）`r`n最近错误："
            . LastDiagProblem "`r`n------ 末尾日志 ------`r`n" SubStr(rawText, -15000)
        ToolTip("诊断摘要已复制；可粘贴到ChatGPT发给我。")
        SetTimer(() => ToolTip(), -2800)
    } catch as e {
        ToolTip("复制失败：" e.Message)
        SetTimer(() => ToolTip(), -2800)
    }
}

GeminiHiddenPowerShellCapture(script, args, timeoutMs := 10000) {
    global PrefDir
    exe := A_WinDir "\System32\WindowsPowerShell\v1.0\powershell.exe"
    if !FileExist(exe)
        return "ERROR|PowerShell unavailable"
    resultFile := PrefDir "\Gemini_隐藏检测_" A_TickCount "_" Random(10000,99999) ".tmp"
    ; /S /C 后的双引号结构与 Windows cmd.exe 的路径加引号格式匹配。
    cmd := '"' A_ComSpec '" /D /S /C ""' exe '" -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' script '" ' args ' > "' resultFile '" 2>&1"'
    startedAt := A_TickCount
    SplitPath(script, &scriptName)
    DiagLog("PS_START", "script=" scriptName " options=" args " timeout_ms=" timeoutMs)
    try {
        Run(cmd, , "Hide", &childPid)
        DiagLog("PS_PROCESS", "pid=" childPid)
        ; AutoHotkey v2 ProcessWaitClose: 0 = 已关闭（成功），非零PID = 超时仍运行。
        ; 旧版错误地使用 !，使所有正常完成的检测都被当作 UIA timeout。
        waitResult := ProcessWaitClose(childPid, timeoutMs / 1000)
        if (waitResult != 0) {
            try ProcessClose(childPid)
            DiagLog("PS_TIMEOUT", "pid=" childPid " waited_ms=" (A_TickCount-startedAt) " still_running=" waitResult)
            return "ERROR|UIA timeout"
        }
        DiagLog("PS_EXIT_OK", "pid=" childPid " elapsed_ms=" (A_TickCount-startedAt))
        if !FileExist(resultFile) {
            DiagLog("PS_ERROR", "检测进程已退出但没有结果文件 elapsed_ms=" (A_TickCount-startedAt))
            return "ERROR|UIA output missing"
        }
        ; Windows PowerShell 5.1 的控制台重定向使用 OEM 编码；协议关键字均为 ASCII。
        output := Trim(FileRead(resultFile, "CP0"), " `t`r`n")
        DiagLog("PS_RESULT", "elapsed_ms=" (A_TickCount-startedAt) " response=" output)
        return output = "" ? "ERROR|UIA output empty" : output
    } catch as e {
        DiagLog("PS_ERROR", "运行异常 elapsed_ms=" (A_TickCount-startedAt) " " e.Message)
        return "ERROR|" e.Message
    } finally {
        try FileDelete(resultFile)
    }
}

GeminiUIA(action, hwnd) {
    ; UIA 查询不再使用会弹控制台窗口的 WScript.Shell.Exec。
    try {
        script := WriteGeminiUIAScript()
        return GeminiHiddenPowerShellCapture(script, "-WindowHandle " hwnd " -Action " action, 10000)
    } catch as e {
        return "ERROR|" e.Message
    }
}

GeminiUIAPoint(action, hwnd) {
    result := GeminiUIA(action, hwnd)
    DiagLog("UIA_POINT", "action=" action " hwnd=" hwnd " response=" result)
    if !RegExMatch(result, "^POINT\|(-?\d+)\|(-?\d+)$", &m)
        return 0
    return {x: Number(m[1]), y: Number(m[2])}
}

GeminiComposerPoints(withAttachment, hwnd) {
    global InFreshComposer, AttachedInputX, AttachedInputY, FreshAttachedX, FreshAttachedY
    global InputX, InputY, FreshInputX, FreshInputY
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    points := [], seen := Map()
    ; UI Automation会根据当前Gemini窗口的实际编辑框位置重新定位，适配新/旧对话和缩放。
    u := GeminiUIAPoint("locate", hwnd)
    if IsObject(u) {
        points.Push({x:u.x, y:u.y, label:"UIA编辑框", calibrated:false})
        seen[u.x "|" u.y] := true
    }
    ; UIA不可用时只信任用户明确校准的输入框坐标，不向网页猜测位置粘贴探针。
    if InFreshComposer {
        rx := withAttachment ? FreshAttachedX : FreshInputX
        ry := withAttachment ? FreshAttachedY : FreshInputY
    } else {
        rx := withAttachment ? AttachedInputX : InputX
        ry := withAttachment ? AttachedInputY : InputY
    }
    if rx != "" && ry != "" && RegExMatch(String(rx), "^-?\d+$") && RegExMatch(String(ry), "^-?\d+$") {
        ax := wx+Number(rx), ay := wy+Number(ry)
        if ax >= wx+65 && ax <= wx+ww-20 && ay >= wy+wh*0.23 && ay <= wy+wh-20 && !seen.Has(ax "|" ay) {
            points.Push({x:ax, y:ay, label:"人工校准编辑框", calibrated:true})
            seen[ax "|" ay] := true
        }
    }
    ; V4.9.8：绝不跨布局借用另一套手工输入坐标（新对话和旧对话可能位于不同高度）。
    ; 另一布局的落点可能在Gemini历史文本，Ctrl+A会选中整张网页。
    return points
}

GeminiClipboardReadAll() {
    A_Clipboard := ""
    Send("^a")
    Sleep(180)
    Send("^c")
    if !ClipWait(2)
        return ""
    return NormalizeGeminiMessage(A_Clipboard)
}

SendChatText(message, withAttachment := false) {
    global InFreshComposer, PrefPath, AttachedInputX, AttachedInputY, FreshAttachedX, FreshAttachedY
    global InputX, InputY, FreshInputX, FreshInputY
    if Trim(message) = "" && !withAttachment
        throw Error("不能发送空白话语。")
    onlyPDF := withAttachment && Trim(message) = ""
    hwnd := ActivateChat()
    DiagLog("TEXT_BEGIN", "with_pdf=" (withAttachment ? "yes" : "no") " chars=" StrLen(message))
    points := GeminiComposerPoints(withAttachment, hwnd)
    DiagLog("TEXT_CANDIDATES", "count=" points.Length)
    if points.Length = 0
        throw Error("未找到Gemini实际输入框。请在附件下方校准 Ctrl+Alt+4（新对话Ctrl+Alt+8）。")
    oldClipboard := ClipboardAll()
    try {
        lastReason := ""
        for p in points {
            DiagLog("TEXT_FOCUS_TRY", "source=" p.label " point=" p.x "," p.y)
            ActivateChat()
            Click(p.x, p.y)
            Sleep(300)
            focusState := GeminiUIA("focus", hwnd)
            DiagLog("TEXT_FOCUS_RESULT", "source=" p.label " result=" focusState)
            ; UIA 的 FocusedElement 在附件上传完成后的短暂过渡期可能仍指向旧控件。
            ; 给当前点一次短暂重试，避免偶发 FOCUSNONE 直接中断发送。
            if focusState = "FOCUSNONE" || focusState = "NOPOINT" {
                Sleep(400)
                focusState := GeminiUIA("focus", hwnd)
                DiagLog("TEXT_FOCUS_RETRY", "source=" p.label " result=" focusState)
            }
            ; 手工校准输入框是用户确认过的点：当Electron返回FOCUSNONE/NOPOINT时，
            ; 允许走严格草稿读取、粘贴后Ctrl+C等值核验；核验失败绝不按Enter。
            ; 没有校准的UIA猜测点仍必须得到FOCUSOK。
            manuallyTrusted := p.calibrated && (focusState = "FOCUSNONE" || focusState = "NOPOINT" || SubStr(focusState, 1, 6) = "ERROR|")
            if (focusState != "FOCUSOK" && !manuallyTrusted) {
                lastReason := p.label " 未聚焦到文字编辑框（" focusState "）"
                continue
            }
            if !WinActive("ahk_id " hwnd)
                throw Error("准备读取Gemini草稿前窗口焦点已丢失，已停止发送")
            if manuallyTrusted
                DiagLog("TEXT_MANUAL_FOCUS_FALLBACK", "UIA无法确认焦点，仅信任人工输入坐标并进行完整剪贴板核验")
            ; 不再插入 __AHK_GEMINI_TEXT_CHECK__ 等探针，防止文字污染和误选网页。
            ; 只在通过焦点检查后读取当前草稿；非空且与目标不同则停止，避免覆盖用户草稿。
            existing := GeminiClipboardReadAll()
            DiagLog("TEXT_DRAFT_READ", "current_chars=" StrLen(existing) " expected_chars=" StrLen(NormalizeGeminiMessage(message)))
            if (existing != "" && !GeminiMessagesEquivalent(existing, message)) {
                throw Error("Gemini输入框已有其他草稿，已停止以避免覆盖：" SubStr(existing, 1, 65))
            }
            if !onlyPDF && existing = "" {
                A_Clipboard := ""
                A_Clipboard := message
                if !ClipWait(3)
                    throw Error("剪贴板写入失败")
                SendEvent("^v")
                ; Gemini 上传附件后有时要较长时间把剪贴板内容写入 contenteditable。
                ; 回读最多三次，且允许浏览器重排空白；正文字符不一致仍然停止。
                copied := ""
                pasteMatch := false
                Loop 3 {
                    Sleep(A_Index = 1 ? 900 : 450)
                    copied := GeminiClipboardReadAll()
                    if GeminiMessagesEquivalent(copied, message) {
                        pasteMatch := true
                        break
                    }
                }
                DiagLog("TEXT_PASTE_RESULT", "copied_chars=" StrLen(copied) " expected_chars=" StrLen(NormalizeGeminiMessage(message)) " match=" (pasteMatch ? "yes" : "no"))
                if !pasteMatch
                    throw Error("Gemini文字粘贴后核对不一致，尚未按Enter。请检查附件下方输入框。")
            } else if onlyPDF && existing != "" {
                throw Error("本PDF设置为不发说明，但输入框已有草稿，已停止避免误发送。")
            }
            SendEvent("{End}")
            Sleep(220)
            SendEvent("{Enter}")
            DiagLog("TEXT_ENTER_SENT", "source=" p.label " 已按Enter，但还未从页面确认实际发出")
            Sleep(1750)
            ; 某些 Gemini 版本第一次 Enter 只让编辑框获得提交状态，文字仍会留在框内。
            ; 仅当焦点仍在编辑框且回读内容仍与目标完全相同，才补发一次 Enter，避免重复发送。
            if !onlyPDF {
                try {
                    afterFocus := GeminiUIA("focus", hwnd)
                    if afterFocus = "FOCUSOK" {
                        residual := GeminiClipboardReadAll()
                        if GeminiMessagesEquivalent(residual, message) {
                            DiagLog("TEXT_ENTER_RETRY", "第一次Enter后编辑框仍保留目标话语，补发Enter")
                            SendEvent("{End}")
                            Sleep(180)
                            SendEvent("{Enter}")
                            Sleep(1000)
                        } else {
                            DiagLog("TEXT_SEND_CHECK", "第一次Enter后编辑框已清空或内容已变化")
                        }
                    }
                } catch as sendCheckErr {
                    DiagLog("TEXT_SEND_CHECK_ERROR", sendCheckErr.Message)
                }
            }
            ; 仅在经过校验后记录坐标；此处不宣称从Gemini接口确认已发出消息。
            WinGetPos(&wx, &wy,,, "ahk_id " hwnd)
            if InFreshComposer {
                section := withAttachment ? "freshAttached" : "freshInput"
                if withAttachment {
                    FreshAttachedX := p.x-wx, FreshAttachedY := p.y-wy
                } else {
                    FreshInputX := p.x-wx, FreshInputY := p.y-wy
                }
            } else {
                section := withAttachment ? "attachedInput" : "input"
                if withAttachment {
                    AttachedInputX := p.x-wx, AttachedInputY := p.y-wy
                } else {
                    InputX := p.x-wx, InputY := p.y-wy
                }
            }
            IniWrite(String(p.x-wx), PrefPath, "coords", section "X")
            IniWrite(String(p.y-wy), PrefPath, "coords", section "Y")
            WriteLog("V4.9.3 已检查编辑框焦点和话语，执行Enter：" p.label)
            return
        }
        throw Error("Gemini话语未聚焦到编辑框，未粘贴也未按Enter；" lastReason ". 请在PDF下方校准Ctrl+Alt+4（新对话Ctrl+Alt+8）。")
    } finally {
        A_Clipboard := oldClipboard
    }
}

; ===== V4.8：上传下一份PDF前多轮检测/清除，无法清理也继续（有混入风险） =====
; 检测范围严格限制在 Gemini 输入框＋号左侧附近的附件卡片区域，
; 不触碰已发出的聊天记录、任务清单或上传说明。

CalibrateCleanupRemove(*) {
    global PrefPath, InFreshComposer, CleanupRemoveX, CleanupRemoveY
    global FreshCleanupRemoveX, FreshCleanupRemoveY
    h := GetChat()
    if !h {
        MsgBox("请先打开并绑定 Gemini 窗口，再把鼠标指向附件卡片右上角的删除×。", "附件清理校准")
        return
    }
    MouseGetPos(&mx, &my)
    WinGetPos(&wx, &wy,,, "ahk_id " h)
    rx := mx-wx, ry := my-wy
    if InFreshComposer {
        FreshCleanupRemoveX := rx, FreshCleanupRemoveY := ry
        key := "freshCleanupRemove"
    } else {
        CleanupRemoveX := rx, CleanupRemoveY := ry
        key := "cleanupRemove"
    }
    IniWrite(String(rx), PrefPath, "coords", key "X")
    IniWrite(String(ry), PrefPath, "coords", key "Y")
    ToolTip("已保存" (InFreshComposer ? "空白新对话" : "已有消息对话") "的残留附件删除×位置")
    SetTimer(() => ToolTip(), -2500)
}

ConfirmSkipCleanupOnce(*) {
    global SkipCleanupOnce
    answer := MsgBox("只有在你已亲眼确认 Gemini 输入框中没有待发送PDF附件时才能跳过。`n这会跳过下一次上传前的残留检测一次，不会清空旧PDF。`n`n确认跳过一次？", "手动跳过检测", "YesNo Icon!")
    if answer = "Yes" {
        SkipCleanupOnce := true
        SetStatus("本次清理检测已由你确认跳过一次；按F8继续，下一份自动恢复检测。")
    }
}

WriteCleanupPowerShell() {
    global PrefDir
    path := PrefDir "\Gemini_附件卡片检测.ps1"
    ps := ""
    ps .= "param(" "`r`n"
    ps .= "    [Int64]$WindowHandle," "`r`n"
    ps .= "    [int]$AnchorX," "`r`n"
    ps .= "    [int]$AnchorY," "`r`n"
    ps .= "    [string]$Action = 'scan'," "`r`n"
    ps .= "    [string]$PriorFile = ''" "`r`n"
    ps .= ")" "`r`n"
    ps .= "$ErrorActionPreference = 'Stop'" "`r`n"
    ps .= "try {" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationClient" "`r`n"
    ps .= "    Add-Type -AssemblyName UIAutomationTypes" "`r`n"
    ps .= "    $root = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$WindowHandle)" "`r`n"
    ps .= "    if ($null -eq $root) { Write-Output 'UNKNOWN|UIA: no window'; exit 0 }" "`r`n"
    ps .= "    $children = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, [System.Windows.Automation.Condition]::TrueCondition)" "`r`n"
    ps .= "    $matches = New-Object 'System.Collections.Generic.List[object]'" "`r`n"
    ps .= "    $buttons = New-Object 'System.Collections.Generic.List[object]'" "`r`n"
    ps .= "    for ($i=0; $i -lt $children.Count; $i++) {" "`r`n"
    ps .= "        try {" "`r`n"
    ps .= "            $el = $children.Item($i)" "`r`n"
    ps .= "            $r = $el.Current.BoundingRectangle" "`r`n"
    ps .= "            if ($r.IsEmpty -or $r.Width -lt 7 -or $r.Height -lt 7) { continue }" "`r`n"
    ps .= "            $cx = ($r.Left + $r.Right) / 2" "`r`n"
    ps .= "            $cy = ($r.Top + $r.Bottom) / 2" "`r`n"
    ps .= "            # Composer PDF chips appear near the + button. Exclude the sent chat bubble higher up / to the right." "`r`n"
    ps .= "            if ($cx -lt ($AnchorX - 95) -or $cx -gt ($AnchorX + 410)) { continue }" "`r`n"
    ps .= "            if ($cy -lt ($AnchorY - 375) -or $cy -gt ($AnchorY - 65)) { continue }" "`r`n"
    ps .= "            $name = [string]$el.Current.Name" "`r`n"
    ps .= "            if ([string]::IsNullOrWhiteSpace($name)) { continue }" "`r`n"
    ps .= "            $typ = [string]$el.Current.ControlType.ProgrammaticName" "`r`n"
    ps .= "            if ($name -match '(?i)^(pdf|pdf file)$' -and $r.Width -le 150 -and $r.Height -lt 100) {" "`r`n"
    ps .= "                $matches.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name;Score=3})" "`r`n"
    ps .= "            } elseif ($name -match '(?i)\.pdf\b' -and $r.Width -le 440 -and $r.Height -lt 115) {" "`r`n"
    ps .= "                $matches.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name;Score=4})" "`r`n"
    ps .= "            } elseif ($PriorFile -and $name.Contains($PriorFile) -and $r.Width -le 440 -and $r.Height -lt 115) {" "`r`n"
    ps .= "                $matches.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name;Score=5})" "`r`n"
    ps .= "            }" "`r`n"
    ps .= "            if ($name -match '(?i)^(remove|remove file|remove attachment|delete|delete file|close|取消附加|移除|移除附件|删除附件|删除文件|移除文件|关闭|×|✕)$' -and $r.Width -le 90 -and $r.Height -le 90) {" "`r`n"
    ps .= "                $buttons.Add([PSCustomObject]@{X=[int]$cx;Y=[int]$cy;Name=$name})" "`r`n"
    ps .= "            }" "`r`n"
    ps .= "        } catch { continue }" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    if ($Action -eq 'remove') {" "`r`n"
    ps .= "        if ($buttons.Count -gt 0) {" "`r`n"
    ps .= "            $chosen = @($buttons | Sort-Object @{Expression={ [Math]::Abs($_.Y - ($AnchorY - 305)) + [Math]::Abs($_.X - ($AnchorX + 140)) }})[0]" "`r`n"
    ps .= "            Write-Output ('REMOVE|{0}|{1}|{2}' -f $chosen.X,$chosen.Y,$chosen.Name)" "`r`n"
    ps .= "        } else { Write-Output 'NO_REMOVE' }" "`r`n"
    ps .= "        exit 0" "`r`n"
    ps .= "    }" "`r`n"
    ps .= "    if ($matches.Count -gt 0) {" "`r`n"
    ps .= "        $chosen = @($matches | Sort-Object -Property Score -Descending)[0]" "`r`n"
    ps .= "        Write-Output ('FOUND|{0}|{1}|{2}' -f $chosen.X,$chosen.Y,$chosen.Name)" "`r`n"
    ps .= "    } else { Write-Output 'EMPTY' }" "`r`n"
    ps .= "} catch {" "`r`n"
    ps .= "    Write-Output ('UNKNOWN|' + ($_.Exception.Message -replace '[|\r\n]',' '))" "`r`n"
    ps .= "}" "`r`n"
    if !FileExist(path)
        FileAppend(ps, path, "UTF-8")
    return path
}

CleanupAnchor() {
    global InFreshComposer, FreshPlusX, FreshPlusY, PlusX, PlusY
    h := ActivateChat()
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " h)
    if InFreshComposer {
        rx := FreshPlusX, ry := FreshPlusY
    } else {
        rx := PlusX, ry := PlusY
    }
    if rx = "" || ry = ""
        throw Error("附件检测需要先校准当前对话的＋按钮位置（旧对话Ctrl+Alt+1，新对话Ctrl+Alt+5）")
    return {h: h, x: wx + Number(rx), y: wy + Number(ry), wx:wx, wy:wy, w:ww, hgt:wh}
}

RunCleanupUIA(action, anchor, priorName := "") {
    ; 与 GeminiUIA 使用同一种隐藏执行方式：检测到残留时也不会弹终端。
    try {
        script := WriteCleanupPowerShell()
        result := GeminiHiddenPowerShellCapture(script,
            "-WindowHandle " anchor.h " -AnchorX " anchor.x " -AnchorY " anchor.y " -Action " action, 10000)
        DiagLog("CLEAN_UIA", "action=" action " response=" result)
        return SubStr(result, 1, 6) = "ERROR|" ? "UNKNOWN|" result : result
    } catch as e {
        return "UNKNOWN|" e.Message
    }
}

ColorDelta(c1, c2) {
    return Abs((c1 >> 16 & 255)-(c2 >> 16 & 255))
        + Abs((c1 >> 8 & 255)-(c2 >> 8 & 255))
        + Abs((c1 & 255)-(c2 & 255))
}

DetectAttachmentPixel(anchor) {
    ; Gemini PDF卡片位于底部＋按钮上方约170~310像素，左边灰色方块在＋按钮右侧。
    ; 同时要求相邻两个采样点颜色近似、并与卡片外部背景明显不同，减少误报。
    bgx := anchor.x + 315
    if bgx >= anchor.wx + anchor.w - 24
        return false
    strongRows := 0
    for height in [175, 195, 215, 235, 255, 275, 295] {
        y := anchor.y-height
        x := anchor.x+76
        if x < anchor.wx+12 || x+46 >= anchor.wx+anchor.w-22
            continue
        if y-14 < anchor.wy+12 || y+14 >= anchor.wy+anchor.hgt-18
            continue
        try {
            c1 := PixelGetColor(x,y,"RGB")
            c2 := PixelGetColor(x+16,y,"RGB")
            c3 := PixelGetColor(x+34,y,"RGB")
            bg1 := PixelGetColor(bgx,y,"RGB")
            bg2 := PixelGetColor(bgx,y+11,"RGB")
            if ColorDelta(c1,c2) <= 33 && ColorDelta(c2,c3) <= 33
                && ColorDelta(c1,bg1) >= 40 && ColorDelta(bg1,bg2) <= 40
                strongRows += 1
        } catch {
            continue
        }
    }
    return strongRows >= 2
}

; 所有UIA坐标在转换前先确认非空、确实为数字：避免Number("")让整个脚本暂停。
CleanupInt(value) {
    value := Trim(String(value))
    return RegExMatch(value,"^-?\d+$") ? Number(value) : ""
}

InspectComposerAttachment(anchor) {
    result := RunCleanupUIA("scan",anchor)
    parts := StrSplit(result,"|")
    if parts.Length >= 3 && parts[1] = "FOUND" {
        cx := CleanupInt(parts[2]), cy := CleanupInt(parts[3])
        if cx != "" && cy != ""
            && cx >= anchor.x-95 && cx <= anchor.x+410
            && cy >= anchor.y-385 && cy <= anchor.y-55
            return {state:"FOUND",x:cx,y:cy,method:"UIA"}
    }
    ; UIA对Gemini的卡片有时不会返回可访问的文字，用视觉二次确认。
    if DetectAttachmentPixel(anchor)
        return {state:"FOUND",x:anchor.x+90,y:anchor.y-235,method:"像素多点"}
    if parts[1] = "EMPTY"
        return {state:"EMPTY",method:"UIA及像素"}
    return {state:"UNKNOWN",reason:result}
}

GetCalibratedRemovePoint(anchor) {
    global InFreshComposer, CleanupRemoveX, CleanupRemoveY, FreshCleanupRemoveX, FreshCleanupRemoveY
    if InFreshComposer {
        rx := FreshCleanupRemoveX, ry := FreshCleanupRemoveY
    } else {
        rx := CleanupRemoveX, ry := CleanupRemoveY
    }
    if rx = "" || ry = ""
        return false
    x := anchor.wx+Number(rx), y := anchor.wy+Number(ry)
    ; 坐标必须落在输入框附件所在的小区域，禁止误按到聊天历史或导航。
    if x < anchor.x-85 || x > anchor.x+315 || y < anchor.y-375 || y > anchor.y-65
        throw Error("保存的附件删除×坐标不在输入框附件区域，请重新悬停在×上按Ctrl+Shift+Alt+R")
    return {x:x, y:y}
}

CleanupPendingAttachments() {
    global SkipCleanupOnce
    if SkipCleanupOnce {
        SkipCleanupOnce := false
        WriteLog("V4.8：用户跳过一次残留检测，继续发送")
        return true
    }
    ; 不要因检测失败而中断整个批次：用户要求残留清理尽力而为，最后继续上传。
    try {
        anchor := CleanupAnchor()
        DiagLog("CLEAN_START", "anchor=" anchor.x "," anchor.y " window=" anchor.w "x" anchor.hgt)
    } catch as e {
        WriteLog("V4.8：无法取得附件检查区域，已跳过清理并继续：" e.Message)
        return false
    }
    cleanCount := 0, unknownCount := 0, foundCount := 0, removalCount := 0
    ; 同一轮内至少二次确认EMPTY，避免Gemini界面短暂变化造成一次漏检。
    ; 有残留则多轮尝试；最多7轮，避免被清理卡住而无法执行后续PDF。
    Loop 7 {
        try {
            pending := InspectComposerAttachment(anchor)
            DiagLog("CLEAN_SCAN", "round=" A_Index " state=" pending.state " method=" (pending.HasOwnProp("method") ? pending.method : "unknown") " extra=" (pending.HasOwnProp("reason") ? pending.reason : ""))
        } catch as e {
            pending := {state:"UNKNOWN",reason:e.Message}
        }
        if pending.state = "EMPTY" {
            cleanCount += 1
            if cleanCount >= 2 {
                WriteLog("V4.8：连续两次未检测到残留附件，继续上传；删除尝试=" removalCount)
                return true
            }
            Sleep(380)
            continue
        }
        cleanCount := 0
        if pending.state = "UNKNOWN" {
            unknownCount += 1
            ; 检测程序无法访问 Gemini 时最多重试三次，不再执行7次完整轮询。
            ; 依照用户原有要求：记录警告后继续上传，不因清理失败暂停。
            if unknownCount >= 3 && foundCount = 0 {
                WriteLog("V4.9.4：附件状态连续3次无法识别，跳过本次清理继续上传：" pending.reason)
                return false
            }
            Sleep(440)
            continue
        }
        foundCount += 1
        SetStatus("V4.8：检测到可能的旧PDF，自动第" foundCount "次清理并复查（总共至多7轮）……")
        try {
            ActivateChat()
            MouseMove(pending.x,pending.y,0)
            Sleep(550) ; 让附件卡片右上角隐藏的×出现
            output := RunCleanupUIA("remove",anchor)
            parts := StrSplit(output,"|")
            chosen := false
            if parts.Length >= 3 && parts[1] = "REMOVE" {
                rx := CleanupInt(parts[2]), ry := CleanupInt(parts[3])
                if rx != "" && ry != ""
                    && Abs(rx-pending.x) <= 240 && Abs(ry-pending.y) <= 175
                    && rx >= anchor.x-95 && rx <= anchor.x+410
                    && ry >= anchor.y-390 && ry <= anchor.y-60
                    chosen := {x:rx,y:ry,source:"UIA"}
            }
            ; UIA不能找到×时，使用用户校准的专属删除坐标；位置验证失败也不暂停。
            if !IsObject(chosen) {
                try chosen := GetCalibratedRemovePoint(anchor)
                catch as e {
                    WriteLog("V4.8：校准删除位置不可用：" e.Message)
                    chosen := false
                }
                if IsObject(chosen)
                    chosen.source := "校准点"
            }
            if IsObject(chosen) {
                Click(chosen.x,chosen.y)
                removalCount += 1
                WriteLog("V4.8：第" removalCount "次尝试点击旧附件删除×（" chosen.source "）")
                Sleep(1050)
            } else {
                WriteLog("V4.8：发现疑似旧附件，但本轮未获得可用删除×；继续复查")
                Sleep(550)
            }
        } catch as e {
            WriteLog("V4.8：本轮附件清理出现异常但不会暂停：" e.Message)
            Sleep(450)
        }
    }
    ; 最终多核一次：结果不确定或清理不了，记录警告但不throw、不修改进度。
    try {
        last := InspectComposerAttachment(anchor)
        if last.state = "EMPTY" {
            Sleep(380)
            last2 := InspectComposerAttachment(anchor)
            if last2.state = "EMPTY" {
                WriteLog("V4.8：最终复查两次均无旧附件，继续上传")
                return true
            }
        }
        WriteLog("V4.8 警告：清理后可能还有旧PDF（" last.state "），已尝试删除" removalCount "次，按不中断要求继续上传下一份PDF")
    } catch as e {
        WriteLog("V4.8 警告：附件复查异常；按不中断要求继续上传：" e.Message)
    }
    return false
}

 ; ===== V4.9.8 点击与文件选择窗口诊断：不写任务、不写进度 =====
GeminiVisibleDialogs() {
    seen := Map()
    for d in WinGetList("ahk_class #32770") {
        try {
            if DllCall("User32\IsWindowVisible", "Ptr", d, "Int")
                seen[d] := true
        }
    }
    return seen
}

GeminiWaitNewPicker(geminiHwnd, prior, timeoutMs := 4500) {
    ; 只认可点击后新出现的公共文件选择窗口，不能将已存在的其他应用对话框误认作成功。
    started := A_TickCount
    geminiPID := WinGetPID("ahk_id " geminiHwnd)
    Loop {
        for d in WinGetList("ahk_class #32770") {
            try {
                if prior.Has(d) || !DllCall("User32\IsWindowVisible", "Ptr", d, "Int")
                    continue
                dialogPID := WinGetPID("ahk_id " d)
                ; 原生Windows文件选择窗口通常归Gemini进程所有；跨进程时还须真正位于前台。
                if (dialogPID != geminiPID && !WinActive("ahk_id " d))
                    continue
                DiagLog("PICKER_DISCOVERED", "hwnd=" d " pid=" dialogPID " gemini_pid=" geminiPID)
                return d
            }
        }
        if A_TickCount - started >= timeoutMs
            break
        Sleep(170)
    }
    return 0
}

GeminiWindowGeometry(hwnd) {
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    dpi := "unknown"
    try dpi := DllCall("User32\GetDpiForWindow", "Ptr", hwnd, "UInt")
    DiagLog("WINDOW_GEOMETRY", "hwnd=" hwnd " x=" wx " y=" wy " w=" ww " h=" wh " dpi=" dpi " screen=" A_ScreenWidth "x" A_ScreenHeight)
    return {x:wx,y:wy,w:ww,h:wh}
}

GeminiPointBelongsToWindow(hwnd, x, y) {
    ; MouseGetPos 的坐标与 CoordMode Mouse Screen 完全一致；越界坐标不点击。
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    if x < wx+2 || y < wy+2 || x >= wx+ww-2 || y >= wy+wh-2
        return false
    ; 位置可能被其他置顶软件遮挡，尽量不要误点击它。
    MouseMove(x, y, 0)
    Sleep(100)
    MouseGetPos(, , &hoveredHwnd)
    if !hoveredHwnd
        return false
    try {
        if hoveredHwnd = hwnd || WinGetPID("ahk_id " hoveredHwnd) = WinGetPID("ahk_id " hwnd)
            return true
        ; 允许 WebView 子窗口（进程不同但顶层祖先仍属于Gemini窗口）。
        root := DllCall("User32\GetAncestor", "Ptr", hoveredHwnd, "UInt", 2, "Ptr")
        if root = hwnd
            return true
    }
    return false
}

GeminiMenuPixelSignature(x, y) {
    ; 取菜单文字附近多点颜色，仅用于辅助诊断，不用颜色结果冒险猜新的点击位置。
    values := []
    for dy in [-25,-8,8,25] {
        for dx in [-60,-25,10,45,80] {
            try {
                values.Push(PixelGetColor(x+dx, y+dy, "RGB"))
            } catch {
                values.Push("")
            }
        }
    }
    return values
}

GeminiPixelDifferences(before, after) {
    different := 0, available := 0
    Loop Min(before.Length, after.Length) {
        i := A_Index
        if before[i] != "" && after[i] != "" {
            available += 1
            if ColorDelta(before[i], after[i]) >= 42
                different += 1
        }
    }
    return {changed:different,total:available}
}

GeminiClickUploadAndWait(hwnd, x, y, label) {
    global InFreshComposer, FreshUploadX, FreshUploadY, UploadX, UploadY, LastUploadProbe
    LastUploadProbe := "点击前"
    DiagLog("UPLOAD_PLUS_BEFORE", "point=" x "," y " candidate=" label " target=" hwnd)
    ActivateChat()
    geom := GeminiWindowGeometry(hwnd)
    rx := InFreshComposer ? FreshUploadX : UploadX
    ry := InFreshComposer ? FreshUploadY : UploadY
    if !GeminiCoordSet(rx, ry) {
        DiagLog("UPLOAD_MENU_NOT_CALIBRATED", "profile=" (InFreshComposer ? "fresh" : "old"))
        return 0
    }
    mx := geom.x + Number(rx), my := geom.y + Number(ry)
    if mx < geom.x+4 || my < geom.y+4 || mx >= geom.x+geom.w-4 || my >= geom.y+geom.h-4
        throw Error("上传菜单校准坐标已超出Gemini窗口。窗口移动/尺寸改变后请核对当前布局的校准点。")
    DiagLog("UPLOAD_MENU_TARGET", "rel=" rx "," ry " abs=" mx "," my " delta_from_plus=" mx-x "," my-y)
    prior := GeminiVisibleDialogs()
    ; 优先先消除旧弹层，后检查目标处于当前Gemini窗口，而不是盲目点击。
    SendEvent("{Esc}")
    Sleep(230)
    ActivateChat()
    if !GeminiPointBelongsToWindow(hwnd, x, y) {
        DiagLog("UPLOAD_PLUS_BLOCKED", "plus=" x "," y " 当前点不属于已绑定Gemini窗口")
        throw Error("附件＋位置被其他窗口遮挡或坐标已失效；已中止点击，保护任务。")
    }
    pre := GeminiMenuPixelSignature(mx, my)
    ; SendEvent 释放热键修饰键并逐次投递鼠标动作；部分Electron页面对SendInput点击不敏感。
    SendEvent("{Click " x " " y "}")
    Sleep(950)
    DiagLog("UPLOAD_PLUS_AFTER", "point=" x "," y " source=" label " active=" DiagActiveWindow())
    post := GeminiMenuPixelSignature(mx, my)
    delta := GeminiPixelDifferences(pre, post)
    LastUploadProbe := "菜单附近像素变化 " delta.changed "/" delta.total
    DiagLog("UPLOAD_MENU_APPEARANCE", "pixel_changed=" delta.changed "/" delta.total " (参考诊断，不能单凭像素证明菜单已打开)")
    if !WinActive("ahk_id " hwnd) {
        DiagLog("UPLOAD_FOCUS_LOST", "after_plus=" DiagActiveWindow())
        return GeminiWaitNewPicker(hwnd, prior, 800)
    }
    ; 多点像素均不变时，可能根本没打开菜单。此时不盲点已保存位置。
    ; 像素只作为保护性启发式；不宣称绝对识别了Gemini菜单。
    if delta.total >= 12 && delta.changed = 0 {
        DiagLog("UPLOAD_MENU_UNCHANGED", "校准菜单位置附近未发现显著变化；跳过可能误击")
    } else if !GeminiPointBelongsToWindow(hwnd, mx, my) {
        DiagLog("UPLOAD_MENU_BLOCKED", "target=" mx "," my " 非Gemini窗口")
        return 0
    } else {
        DiagLog("UPLOAD_MENU_MANUAL", "rel=" rx "," ry " abs=" mx "," my)
        SendEvent("{Click " mx " " my "}")
        dialog := GeminiWaitNewPicker(hwnd, prior, 5000)
        if dialog {
            DiagLog("UPLOAD_DIALOG_MANUAL", "dialog_hwnd=" dialog)
            return dialog
        }
        DiagLog("UPLOAD_NO_DIALOG_MANUAL", "point=" mx "," my " active=" DiagActiveWindow())
    }
    ; 人工菜单未命中时再重新展开 +，仅查找一次可访问菜单，不乱点周边图标。
    try {
        ActivateChat()
        SendEvent("{Esc}")
        Sleep(220)
        if GeminiPointBelongsToWindow(hwnd, x, y) {
            SendEvent("{Click " x " " y "}")
            Sleep(650)
            p := GeminiUIAPoint("upload", hwnd)
            if IsObject(p) && GeminiPointBelongsToWindow(hwnd, p.x, p.y) {
                DiagLog("UPLOAD_MENU_UIA_FALLBACK", "point=" p.x "," p.y)
                SendEvent("{Click " p.x " " p.y "}")
                dialog := GeminiWaitNewPicker(hwnd, prior, 4500)
                if dialog
                    return dialog
            } else
                DiagLog("UPLOAD_MENU_UIA_MISS", "未找到菜单，停止盲点")
        }
    } catch as e {
        DiagLog("UPLOAD_MENU_UIA_ERROR", e.Message)
    }
    return 0
}

GeminiPlusCandidates(hwnd, useUIA := false) {
    global InFreshComposer, PlusX, PlusY, FreshPlusX, FreshPlusY
    WinGetPos(&wx, &wy, &ww, &wh, "ahk_id " hwnd)
    points := [], seen := Map()
    ; 旧版保存的+按钮优先，UIA识别按钮兜底，避免触摸菜单外的错误位置。
    rx := InFreshComposer ? FreshPlusX : PlusX
    ry := InFreshComposer ? FreshPlusY : PlusY
    if rx != "" && ry != "" && RegExMatch(String(rx), "^-?\d+$") && RegExMatch(String(ry), "^-?\d+$") {
        x := wx+Number(rx), y := wy+Number(ry)
        ; 空白新对话输入区通常位于页面中部，不能套用旧对话“下半屏55%”过滤。
        minY := InFreshComposer ? wy+wh*0.22 : wy+wh*0.50
        if x >= wx+5 && x <= wx+ww*0.80 && y >= minY && y <= wy+wh-8 {
            points.Push({x:x,y:y,label:"人工校准+"})
            seen[x "|" y] := true
        }
    }
    if useUIA || points.Length = 0 {
        p := GeminiUIAPoint("plus", hwnd)
        if IsObject(p) && !seen.Has(p.x "|" p.y) {
            points.Push({x:p.x,y:p.y,label:"UIA定位+"})
            seen[p.x "|" p.y] := true
        }
    }
    ; 不能跨布局借用坐标：新对话的＋在另一位置，旧坐标导致点不到附件。
    ; 特别禁止 fresh=yes 时把旧 PlusX 当作候选。（用户日志证实此错误。）
    DiagLog("PLUS_CANDIDATES", "count=" points.Length " window_pos=" wx "," wy " size=" ww "x" wh)
    for p in points
        DiagLog("PLUS_CANDIDATE", "source=" p.label " point=" p.x "," p.y)
    return points
}

; 保持原任务文件和坐标字段不变；只是避免在新对话借用旧坐标。
GeminiCoordSet(x, y) {
    return x != "" && y != "" && RegExMatch(String(x), "^-?\d+$") && RegExMatch(String(y), "^-?\d+$")
}

GeminiValidateUploadCalibration() {
    global InFreshComposer, FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY
    global PlusX, PlusY, UploadX, UploadY, Stage, Jobs, JobIndex
    ; 只有当前任务真的需要上传时检查；不影响已附加附件的 upload_ready 重试。
    if Stage != "upload" || JobIndex > Jobs.Length || Jobs[JobIndex].path = ""
        return true
    if InFreshComposer {
        if !GeminiCoordSet(FreshPlusX, FreshPlusY) || !GeminiCoordSet(FreshUploadX, FreshUploadY) {
            DiagLog("CALIBRATION_MISSING", "fresh=yes freshPlus=" GeminiCoordSet(FreshPlusX, FreshPlusY) " freshUpload=" GeminiCoordSet(FreshUploadX, FreshUploadY))
            throw Error("当前是【空白新对话】，但未完整保存新对话的附件坐标。`n请把鼠标放在新对话＋号上按 Ctrl+Alt+5；手动点开＋菜单，鼠标移到【上传文件】按 Ctrl+Alt+6。`n然后在高级设置点击【测试上传按钮】，成功后按F8。`n不会使用旧对话坐标冒险点击，也不会清空PDF任务。")
        }
    } else if !GeminiCoordSet(PlusX, PlusY) || !GeminiCoordSet(UploadX, UploadY) {
        DiagLog("CALIBRATION_MISSING", "fresh=no plus=" GeminiCoordSet(PlusX, PlusY) " upload=" GeminiCoordSet(UploadX, UploadY))
        throw Error("当前是【已有消息的旧对话】，请先分别按 Ctrl+Alt+1 校准附件＋、Ctrl+Alt+2 校准【上传文件】菜单，再测试上传按钮。")
    }
    return true
}

; 可检测是否真的打开 Windows 文件选择框；测试会自行关闭对话框，绝不上传PDF，不修改41份任务。
TestGeminiUploadPicker(*) {
    global Busy, Running, InFreshComposer, StartProfileBox, MainGui, AdvancedGui
    global FreshPlusX, FreshPlusY, FreshUploadX, FreshUploadY
    global PlusX, PlusY, UploadX, UploadY, LastUploadProbe, TestResultText
    if Running || Busy {
        SetStatus("请先按 F9 暂停，再测试附件菜单；不会清除任务或进度。")
        return
    }
    oldProfile := InFreshComposer
    Busy := true
    try {
        InFreshComposer := StartProfileBox.Value = 2
        ; 点击测试前暂时隐藏两个置顶脚本窗口，避免它们挡住 Gemini ＋按钮和上传菜单。
        AdvancedGui.Hide()
        MainGui.Hide()
        Sleep(180)
        ; 不通过UIA或者另一种布局的备用坐标；只使用本布局的校准点。
        h := ActivateChat()
        if InFreshComposer {
            if !GeminiCoordSet(FreshPlusX, FreshPlusY) || !GeminiCoordSet(FreshUploadX, FreshUploadY)
                throw Error("新对话缺少专属＋/上传菜单校准。请按 Ctrl+Alt+5 和 Ctrl+Alt+6。")
            px := Number(FreshPlusX), py := Number(FreshPlusY)
        } else {
            if !GeminiCoordSet(PlusX, PlusY) || !GeminiCoordSet(UploadX, UploadY)
                throw Error("旧对话缺少＋/上传菜单校准。请按 Ctrl+Alt+1 和 Ctrl+Alt+2。")
            px := Number(PlusX), py := Number(PlusY)
        }
        WinGetPos(&wx, &wy,,, "ahk_id " h)
        dialog := GeminiClickUploadAndWait(h, wx+px, wy+py, "校准测试")
        if !dialog
            throw Error("没有打开文件选择窗口。诊断：" LastUploadProbe "。请核对实际弹出的菜单位置；仅在位置确实改变时重新校准上传菜单。")
        DiagLog("CALIBRATION_TEST_OK", "dialog=" dialog " profile=" (InFreshComposer ? "fresh" : "old"))
        ; 测试只开文件窗口，按 Escape 退出，不选择或发送任何文件。
        WinActivate("ahk_id " dialog)
        Sleep(220)
        SendEvent("{Esc}")
        if !WinWaitClose("ahk_id " dialog, , 3)
            throw Error("文件选择窗口已成功打开，但测试未能自动取消；请手动按Esc关闭后再测试。")
        SetStatus("✓ 已实测打开并取消文件选择窗口；没有上传PDF，也没有修改任务与进度。")
        TestResultText.Text := "测试成功：文件选择窗口确实出现且已取消。可以在现有任务上继续。"
    } catch as e {
        DiagLog("CALIBRATION_TEST_FAIL", e.Message)
        SetStatus("⚠ 附件校准测试失败：" e.Message)
        TestResultText.Text := "测试失败：" SubStr(e.Message, 1, 150)
    } finally {
        InFreshComposer := oldProfile
        Busy := false
        MainGui.Show()
        AdvancedGui.Show()
    }
}

AttachPDF(path) {
    global LastUploadProbe
    SplitPath(path, &pdfName)
    DiagLog("UPLOAD_BEGIN", "pdf=" pdfName " exists=" (FileExist(path) ? "yes" : "no"))
    if !FileExist(path)
        throw Error("PDF文件不存在：" path)
    GeminiValidateUploadCalibration()
    h := ActivateChat()
    points := GeminiPlusCandidates(h)
    if points.Length = 0
        throw Error("无法定位Gemini附件＋按钮，请先校准 Ctrl+Alt+1（空白新对话 Ctrl+Alt+5）。")
    dialog := 0
    ; 先使用现有手工坐标；失败后才扩充一次UIA + 号候选。
    ; 当前对话与新对话坐标分别保存，避免 UIA 始终阻断人工已校准路径。
    Loop 2 {
        round := A_Index
        ; 当前 Gemini.exe 的 UIA 对 +/菜单始终返回 NOPOINT：无须第二轮反复调用PowerShell。
        ; 只对用户校准过的准确坐标重试一次。
        DiagLog("UPLOAD_ROUND", "round=" round " candidates=" points.Length)
        for p in points {
            dialog := GeminiClickUploadAndWait(h, p.x, p.y, p.label)
            if dialog
                break
        }
        if dialog
            break
        Sleep(550)
    }
    if !dialog {
        DiagLog("UPLOAD_FAIL", "校准点击和一次UIA检查均未打开文件窗口；" LastUploadProbe)
        throw Error("没有打开Gemini文件选择窗口：" LastUploadProbe "。请先使用【测试上传按钮】确认实际菜单是否展开，再核对本布局＋/上传菜单位置。未上传PDF，未推进进度。")
    }
    DiagLog("UPLOAD_FILE_DIALOG", "dialog_hwnd=" dialog " pdf=" pdfName)
    target := "ahk_id " dialog
    WinActivate(target)
    if !WinWaitActive(target, , 3)
        throw Error("文件选择窗口未取得焦点，已停止以防PDF路径进入Gemini文本框")
    ; Windows 11 / Electron通用文件窗口的文件名栏可能不是 Edit1，优先Alt+N。
    ; 用户指定文件的绝对路径在对话框前台粘贴，不直接操作聊天编辑框。
    oldClipboard := ClipboardAll()
    try {
        SendEvent("!n")
        Sleep(350)
        A_Clipboard := path
        if !ClipWait(3)
            throw Error("写入PDF路径到剪贴板失败")
        SendEvent("^a")
        SendEvent("^v")
        Sleep(350)
        if !WinActive(target)
            throw Error("文件选择窗口意外失去焦点，取消后续提交")
        SendEvent("{Enter}")
    } finally {
        A_Clipboard := oldClipboard
    }
    if !WinWaitClose(target, , 16) {
        DiagLog("UPLOAD_FAIL", "文件选择窗口没有在16秒内关闭")
        throw Error("文件选择窗口未关闭，未确认PDF已附加")
    }
    DiagLog("UPLOAD_DIALOG_CLOSED", "文件选择窗口关闭；此处尚不能证明Gemini已接收附件")
    Sleep(12000) ; 保留原有上传准备时间，适合较大的PDF。
}

ToChinese(n) {
    chars := ["零","一","二","三","四","五","六","七","八","九"]
    if (n < 10)
        return chars[n+1]
    if (n < 20)
        return "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 100)
        return chars[Floor(n/10)+1] "十" (Mod(n, 10) ? chars[Mod(n, 10)+1] : "")
    if (n < 1000) {
        r := Mod(n, 100)
        return chars[Floor(n/100)+1] "百" (r = 0 ? "" : (r < 10 ? "零" chars[r+1] : ToChinese(r)))
    }
    return String(n)
}

ParseQuestions(spec, lineNo) {
    result := []
    seen := Map()
    for item in StrSplit(StrReplace(spec, "，", ","), ",") {
        item := Trim(item)
        if item = ""
            continue
        item := StrReplace(StrReplace(item, "—", "-"), "–", "-")
        if RegExMatch(item, "^\d+$") {
            n := Number(item)
            if (n < 1 || n > 9999)
                throw Error("第" lineNo "行题号超出范围")
            if !seen.Has(n) {
                result.Push(n)
                seen[n] := true
            }
        } else if RegExMatch(item, "^\d+\s*-\s*\d+$") {
            segments := StrSplit(item, "-")
            a := Number(Trim(segments[1]))
            b := Number(Trim(segments[2]))
            if (a < 1 || a > b || b > 9999 || b-a > 500)
                throw Error("第" lineNo "行题号范围无效或过大：" item)
            Loop b-a+1 {
                n := a+A_Index-1
                if !seen.Has(n) {
                    result.Push(n)
                    seen[n] := true
                }
            }
        } else
            throw Error("第" lineNo "行的题号格式错误：" item)
    }
    if !result.Length
        throw Error("第" lineNo "行没有有效题号")
    return result
}

ManifestId(src) {
    ; 用于防止任务清单变更后误用旧进度。轻量非安全哈希。
    h := 2166136261
    Loop Parse src {
        h := Mod(((h ^ Ord(A_LoopField)) * 16777619), 4294967296)
    }
    return Format("{:08X}", h)
}

ReloadJobs(*) {
    global Jobs, TaskPath, Signature, Running, Busy, CountText, Mode, UploadIntroGui, StatePath
    if Running || Busy {
        MsgBox("请先按 F9 暂停，并等待当前发送操作结束，再刷新任务。")
        return
    }
    raw := FileRead(TaskPath, "UTF-8")
    freshJobs := []
    lineNo := 0
    for line in StrSplit(raw, "`n") {
        lineNo++
        line := Trim(line, " `t`r`n")
        if (line = "" || SubStr(line, 1, 1) = "#")
            continue
        msgs := []
        if Mode = "questions" {
            parts := StrSplit(line, "|")
            if (parts.Length != 2)
                throw Error("任务清单第" lineNo "行须用 | 分隔PDF路径和题号")
            path := Trim(parts[1], " `t`r`n" Chr(34))
            if !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            qs := ParseQuestions(Trim(parts[2]), lineNo)
            SplitPath(path, &name)
        } else if (Mode = "custom" || Mode = "together") {
            parts := StrSplit(line, "|")
            if parts.Length < 2
                throw Error("自定义任务第" lineNo "行缺少话语。请用【管理每份PDF的话语】编辑。")
            path := UnescapeCustomField(parts[1])
            if path = "@NO_PDF"
                path := ""
            if path != "" && !FileExist(path)
                throw Error("找不到第" lineNo "行的PDF：" path)
            if Mode = "together" && path = ""
                throw Error("功能三必须指定真实PDF：第" lineNo "行")
            name := "当前对话（无需上传PDF）"
            if path != ""
                SplitPath(path, &name)
            Loop parts.Length - 1 {
                message := UnescapeCustomField(parts[A_Index + 1])
                if Mode = "custom" && parts.Length = 2 && (parts[2] = "%00" || parts[2] = "")
                    continue  ; 功能二无后续话语的明确空白状态，兼容早期结尾|

                if Trim(message) = ""
                    throw Error("自定义任务第" lineNo "行有空话语")
                msgs.Push(message)
            }
            if Mode = "together" && msgs.Length != 1
                throw Error("功能三第" lineNo "行必须恰好设置一句话")
            qs := []
            Loop msgs.Length
                qs.Push(A_Index)
        } else {
            ; 功能一：固定话语，每份PDF只发送同一句。
            if line = "@NO_PDF" {
                path := ""
                name := "当前对话（无需上传PDF）"
            } else {
                path := Trim(line, " `t`r`n" Chr(34))
                if !FileExist(path)
                    throw Error("找不到第" lineNo "行的PDF：" path)
                SplitPath(path, &name)
            }
            qs := [1]
        }
        freshJobs.Push({path: path, name: name, qs: qs, msgs: msgs})
    }
    newSignature := ManifestId(raw)
    oldSignature := IniRead(StatePath, "progress", "task_id", "")
    if (oldSignature != "" && newSignature != oldSignature) {
        ; V4.9.2：选定并加入PDF或保存修改后的任务直接生效，无“是/否”二次确认。
        ; 新清单与已有发送进度不同，自动从第一条重新开始，避免使用旧断点。
        ResetState(newSignature)
        try WriteLog("任务清单已更新；自动重置当前模式的发送进度，无需二次确认。")
    }
    Jobs := freshJobs
    Signature := newSignature
    RestoreProgress()
    total := 0
    for job in Jobs
        total += job.qs.Length
    CountText.Text := "已载入：" Jobs.Length " 份任务，共 " total " 条" (Mode = "questions" ? "逐题提问" : "话语") "。当前模式：" (Mode = "together" ? "PDF+一句同时发送" : Mode = "custom" ? "每PDF自定义" : Mode = "single" ? "固定话语" : "原版逐题")
    ShowProgress()
    if Mode = "custom" || Mode = "together"
        RefreshCustomManager()
    if IsObject(UploadIntroGui)
        RefreshUploadIntroManager()
}


; 【重新载入任务】按钮：清空当前模式的任务清单并重置当前模式的断点。
; ReloadJobs 保持原样：脚本启动和添加PDF时仍然读取任务，不会误清空。
ClearTaskList(*) {
    global TaskPath, Running, Busy
    if (Running || Busy) {
        MsgBox("先按 F9 暂停，等当前上传或发送结束后再清空任务。", "任务正在运行")
        return
    }
    try {
        ; 保留一份旧清单备份，以免误点后无法找回任务路径。
        oldContent := FileRead(TaskPath, "UTF-8")
        backup := ""
        if RegExMatch(oldContent, "m)^\s*[^#\s].*$") {
            backup := A_ScriptDir "\Gemini_PDF任务清单_备份_" FormatTime(A_Now, "yyyyMMdd_HHmmss") "_" A_TickCount ".txt"
            FileCopy(TaskPath, backup)
        }
        ; 只保留格式说明。原PDF文件、计时与校准设置不会被删除。
        starter := TaskTemplate()
        temp := TaskPath ".new"
        if FileExist(temp)
            FileDelete(temp)
        FileAppend(starter, temp, "UTF-8")
        FileMove(temp, TaskPath, 1)

        ; 写入新空清单的标识，重置进度，再按旧逻辑重新读取。
        ResetState(ManifestId(FileRead(TaskPath, "UTF-8")))
        ReloadJobs()
        msg := "✓ 旧PDF任务已清空，发送进度已重置。`n点击【添加 PDF 任务】录入新PDF即可。原PDF和时间/坐标设置未改变。"
        if (backup != "")
            msg .= "`n已自动备份原任务清单：" backup
        SetStatus(msg)
    } catch as e {
        MsgBox("清空任务失败：" e.Message, "错误")
        SetStatus("⚠ 清空任务失败。请检查任务文件是否被占用；旧任务可能未更改。")
    }
}

AddPdfJob(button := 0, *) {
    global TaskPath, Running, Mode, Busy, Jobs, EditorOpen
    ; AHK v2 的 +OwnDialogs 必须在本次按钮事件线程内启用；
    ; 选择PDF窗口和题号对话框保持在置顶脚本窗口前面。
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    if Running || Busy || EditorOpen {
        MsgBox("请先F9暂停并结束编辑，再添加PDF。")
        return
    }
    chosen := Mode = "questions" ? FileSelect(1, , "选择要上传的PDF", "PDF 文件 (*.pdf)") : FileSelect("M1", , "可按 Ctrl 多选PDF，依次加入任务", "PDF 文件 (*.pdf)")
    if !chosen
        return
    if Mode = "questions" {
        box := InputBox("输入这份PDF要提问的题号。例如：8-10,12,15-17", "设置题号", "w460 h150", "8-10")
        if box.Result != "OK"
            return
        try ParseQuestions(box.Value, 1)
        catch as e {
            MsgBox(e.Message, "题号格式错误")
            return
        }
        FileAppend(chosen "|" box.Value "`r`n", TaskPath, "UTF-8")
        ReloadJobs()
        return
    }
    files := chosen is Array ? chosen : [chosen]
    if Mode = "custom" || Mode = "together" {
        for pdf in files {
            SplitPath(pdf, &name)
            Jobs.Push({path: pdf, name: name, qs: [1], msgs: [DefaultCustomMessage()]})
        }
        try {
            SaveCustomJobs()
            OpenCustomManager()
        } catch as e
            MsgBox("添加PDF失败：" e.Message)
    } else {
        for pdf in files
            FileAppend(pdf "`r`n", TaskPath, "UTF-8")
        ReloadJobs()
    }
}

EditJobs(*) {
    global TaskPath, Mode
    if Mode = "custom" || Mode = "together" {
        OpenCustomManager()
        return
    }
    Run('notepad.exe "' TaskPath '"')
}

ResetState(sig) {
    global StatePath, StartProfileBox
    IniWrite(sig, StatePath, "progress", "task_id")
    IniWrite("1", StatePath, "progress", "job")
    IniWrite("1", StatePath, "progress", "question")
    IniWrite("upload", StatePath, "progress", "stage")
    IniWrite("", StatePath, "progress", "until")
    IniWrite("1", StatePath, "progress", "chat_group_start")
    IniWrite("0", StatePath, "progress", "awaiting_new_chat")
    IniWrite(String(StartProfileBox.Value = 2 ? 1 : 0), StatePath, "progress", "fresh_profile")
}

ResetProgress(button := 0, *) {
    global Running, Busy, Signature, Jobs
    try {
        if IsObject(button)
            button.Gui.Opt("+OwnDialogs")
    }
    if Running || Busy {
        MsgBox("先按 F9 暂停并等待当前上传或发送完全结束，才能重置进度。")
        return
    }
    if MsgBox("确定把发送进度清零吗？注意：重置后会重新上传第一份PDF、重新发送话语或题目。", "重置进度", "YesNo Icon!") != "Yes"
        return
    ResetState(Signature)
    RestoreProgress()
    ShowProgress()
}

RestoreProgress() {
    global StatePath, JobIndex, QuestionIndex, Stage, WaitUntil, ChatGroupStartJob, NeedManualNewChat, InFreshComposer, StartProfileBox
    JobIndex := GeminiSafeInteger(IniRead(StatePath, "progress", "job", "1"), 1, 1, 100000)
    QuestionIndex := GeminiSafeInteger(IniRead(StatePath, "progress", "question", "1"), 1, 1, 100000)
    Stage := IniRead(StatePath, "progress", "stage", "upload")
    WaitUntil := IniRead(StatePath, "progress", "until", "")
    ChatGroupStartJob := GeminiSafeInteger(IniRead(StatePath, "progress", "chat_group_start", "1"), 1, 1, 100000)
    NeedManualNewChat := IniRead(StatePath, "progress", "awaiting_new_chat", "0") = "1"
    InFreshComposer := IniRead(StatePath, "progress", "fresh_profile", StartProfileBox.Value = 2 ? "1" : "0") = "1"
}

SaveProgress() {
    global StatePath, Signature, JobIndex, QuestionIndex, Stage, WaitUntil, ChatGroupStartJob, NeedManualNewChat, InFreshComposer
    IniWrite(Signature, StatePath, "progress", "task_id")
    IniWrite(String(JobIndex), StatePath, "progress", "job")
    IniWrite(String(QuestionIndex), StatePath, "progress", "question")
    IniWrite(Stage, StatePath, "progress", "stage")
    IniWrite(WaitUntil, StatePath, "progress", "until")
    IniWrite(String(ChatGroupStartJob), StatePath, "progress", "chat_group_start")
    IniWrite(NeedManualNewChat ? "1" : "0", StatePath, "progress", "awaiting_new_chat")
    IniWrite(InFreshComposer ? "1" : "0", StatePath, "progress", "fresh_profile")
}

SetStatus(info) {
    global StatusText
    StatusText.Text := info
}

ShowProgress() {
    global Jobs, JobIndex, QuestionIndex, Stage, WaitUntil, Running, Mode
    if (Stage = "done") {
        SetStatus("✓ 全部PDF及对应提问已经发送完毕。注意这只代表脚本完成发送，不代表回答已结束。")
        return
    }
    if Jobs.Length = 0 {
        SetStatus("还没有任务。请点击【添加PDF任务】；功能一、二可选择只发文字。")
        return
    }
    if (JobIndex > Jobs.Length) {
        SetStatus("进度超出任务数量，请重置进度。")
        return
    }
    j := Jobs[JobIndex]
    qText := Mode = "together" ? "PDF与话语同发" : (QuestionIndex <= j.qs.Length ? (Mode = "questions" ? "第" j.qs[QuestionIndex] "题" : "第" QuestionIndex "/" j.qs.Length "条话语") : "无后续话语/等待切换")
    msg := (Running ? "运行中" : "未运行/已暂停") "｜PDF " JobIndex "/" Jobs.Length "：" j.name
        . "`n当前阶段：" Stage "｜" qText
    if (Stage = "upload_wait" || Stage = "question_wait" || Stage = "pdf_wait") {
        secs := WaitUntil != "" ? Max(0, DateDiff(WaitUntil, A_Now, "Seconds")) : 0
        msg .= "｜剩余约" secs "秒"
    }
    SetStatus(msg)
}

ValidateTimers() {
    global QBox, PBox, UBox, QWait, PDFWait, UploadWait, PrefPath
    qText := Trim(QBox.Value)
    pText := Trim(PBox.Value)
    uText := Trim(UBox.Value)
    if !RegExMatch(qText, "^\d+$") || !RegExMatch(pText, "^\d+$") || !RegExMatch(uText, "^\d+$")
        throw Error("等待时间请输入整数")
    q := Number(qText), p := Number(pText), u := Number(uText)
    if (q < 1 || q > 120 || p < 1 || p > 120 || u < 15 || u > 3600)
        throw Error("每题及PDF间隔为1~120分钟；上传后的等待为15~3600秒")
    QWait := q, PDFWait := p, UploadWait := u
    IniWrite(String(q), PrefPath, "timing", "question_minutes")
    IniWrite(String(p), PrefPath, "timing", "pdf_minutes")
    IniWrite(String(u), PrefPath, "timing", "upload_seconds")
}

StartRun() {
    global Running, Jobs, Stage, ChatHwnd, Busy, Mode, Msg1Box, SendMsg1, NeedManualNewChat, ChatGroupStartJob, JobIndex, InFreshComposer, UploadIntroGui, MainGui
    if Busy {
        SetStatus("正在完成上一条上传或发送操作。请等当前操作结束后再按 F8。")
        return
    }
    try MainGui.Opt("+OwnDialogs")
    if IsObject(UploadIntroGui) {
        MsgBox("请先关闭【每份PDF上传说明】管理窗口，然后按F8开始。")
        return
    }
    if Running {
        ShowProgress()
        return
    }
    if !Jobs.Length {
        MsgBox("先添加至少一份PDF任务。", "没有任务")
        return
    }
    if Stage = "done" {
        MsgBox("任务已经完成。若要从头来，请使用‘重置发送进度’。")
        return
    }
    try {
        ValidateTimers()
        SaveConversationOptions()
        SaveMessageSettings()
        SendMsg1 := Trim(Msg1Box.Value)
        if Mode = "single" && SendMsg1 = ""
            throw Error("功能一请填写固定话语")
        if Mode = "together" {
            for job in Jobs {
                if job.path = "" || job.msgs.Length != 1 || Trim(job.msgs[1]) = ""
                    throw Error("功能三有PDF没有设置唯一的话语：" job.name)
            }
        }
        if NeedManualNewChat {
            answer := MsgBox("此处必须开始一个全新的Gemini对话。`n`n请先在Gemini中手动点击【新建聊天】，确认页面空白；必要时按Ctrl+Alt+0绑定窗口。`n`n已经进入新的空白对话了吗？", "确认切换新对话", "YesNo Icon?")
            if answer != "Yes"
                return
            NeedManualNewChat := false
            ChatGroupStartJob := JobIndex
            InFreshComposer := true
            SaveProgress()
        }
        ; V4.9.7：首份PDF在上传阶段按界面下拉框确定新旧对话，不再沿用上一轮进度里的过期 fresh 标记。
        ; 仅作用于第一组首份，不干预第11份等自动新建对话时的 fresh 标记。
        if (JobIndex = 1 && Stage = "upload" && ChatGroupStartJob = 1) {
            InFreshComposer := StartProfileBox.Value = 2
            SaveProgress()
        }
        GeminiValidateUploadCalibration()
        ChatHwnd := ActivateChat()
        Running := true
        ShowProgress()
        SetTimer(Tick, 1000) ; 必须保持周期定时器，避免只发一次就停止
        Tick()
    } catch as e {
        Running := false
        MsgBox(e.Message, "无法开始")
    }
}

PauseRun() {
    global Running
    Running := false
    ShowProgress()
}

FastForward() {
    global Running, Stage, WaitUntil
    if (Stage != "upload_wait" && Stage != "question_wait" && Stage != "pdf_wait") {
        SetStatus("当前不在等待阶段，F10不会跳过PDF或题目。")
        return
    }
    if !Running
        StartRun()
    if !Running
        return
    WaitUntil := A_Now
    SaveProgress()
    SetTimer(Tick, 1000)
    Tick()
}

BeginWait(nextStage, seconds) {
    global Stage, WaitUntil
    Stage := nextStage
    WaitUntil := DateAdd(A_Now, seconds, "Seconds")
    SaveProgress()
}

; 功能三PDF+一句同发，或功能二后续话语为零时：直接进入下一PDF等待。
FinishOnePDF() {
    global Jobs, JobIndex, Running, Stage, WaitUntil, PDFWait
    if JobIndex < Jobs.Length
        BeginWait("pdf_wait", PDFWait*60)
    else {
        Stage := "done"
        WaitUntil := ""
        SaveProgress()
        Running := false
    }
}

Tick(*) {
    global Running, Busy, Jobs, JobIndex, QuestionIndex, Stage, WaitUntil, Mode, SendMsg1
    global UploadWait, QWait, PDFWait, InFreshComposer, ChatGroupStartJob, NeedManualNewChat
    global MaxPDFBox, AutoSwitchBox, NewChatX, NewChatY
    if !Running || Busy
        return
    if !Jobs.Length || Stage = "done"
        return
    Busy := true
    try {
        if (Stage = "upload_wait" || Stage = "question_wait" || Stage = "pdf_wait") {
            if (WaitUntil != "" && DateDiff(WaitUntil, A_Now, "Seconds") > 0) {
                ShowProgress()
                return
            }
            WaitUntil := ""
            if Stage = "upload_wait"
                Stage := "question"
            else if Stage = "question_wait"
                Stage := "question"
            else {
                JobIndex += 1
                QuestionIndex := 1
                Stage := "upload"
            }
            SaveProgress()
        }

        if (JobIndex > Jobs.Length) {
            Stage := "done"
            SaveProgress()
            Running := false
            ShowProgress()
            return
        }
        job := Jobs[JobIndex]
        if (Stage = "upload") {
            limit := Number(Trim(MaxPDFBox.Value) = "" ? "0" : MaxPDFBox.Value)
            if limit > 0 && JobIndex > 1 && Mod(JobIndex-1, limit) = 0 && ChatGroupStartJob != JobIndex {
                ; 在下一份PDF上传之前切换新聊天，避免把第11份误发到已满的旧聊天。
                if AutoSwitchBox.Value && NewChatX != "" && NewChatY != "" {
                    SetStatus("已达" limit "份PDF：尝试自动新建Gemini对话（请不要操作窗口）")
                    ClickChat("new_chat")
                    Sleep(2600)
                    ChatGroupStartJob := JobIndex
                    InFreshComposer := true
                    SaveProgress()
                    WriteLog("已点击新建Gemini对话，后续按新对话布局发送第" JobIndex "份PDF")
                } else {
                    NeedManualNewChat := true
                    Running := false
                    SaveProgress()
                    SetStatus("⏸ 已完成前" (JobIndex-1) "份PDF；请在Gemini手动新建空白聊天、Ctrl+Alt+0绑定并按F8。`n不会重发先前的PDF，也不会清空任务。")
                    return
                }
            }
            if (Mode = "questions" || job.path != "") {
                SetStatus("正在上传PDF " JobIndex "/" Jobs.Length "：" job.name "`n不要操作鼠标或键盘……")
                ; V4.7：只有准备上传下一份时才清理。upload_ready表示本份已附加待重试，绝不清它。
                DiagLog("JOB_UPLOAD_START", "准备扫描残留并上传下一份PDF")
                if (InFreshComposer && JobIndex = ChatGroupStartJob) {
                    ; 当前刚进入全新的空白会话，尚未添加本组PDF，不必重复调用耗时的旧附件检测。
                    DiagLog("CLEAN_SKIP_FRESH_FIRST", "新建空白对话的首份PDF，无旧附件清理步骤；直接进入上传")
                } else {
                    try CleanupPendingAttachments()
                    catch as cleanupErr {
                        DiagLog("CLEAN_ERROR", cleanupErr.Message)
                        WriteLog("V4.8：清理函数意外异常，但按照设定继续：" cleanupErr.Message)
                    }
                }
                DiagLog("JOB_CLEAN_FINISHED", "开始附件上传尝试")
                AttachPDF(job.path)
                Stage := "upload_ready"
                SaveProgress() ; PDF已附加，若文字发送失败，F8只重试话语，不重复附加PDF。
                if Mode = "together"
                    SendChatText(job.msgs[1], true) ; 与PDF一起送出，只发一次，跳过独立说明+后续提问
                else
                    SendChatText(GetUploadIntro(job), true)
                InFreshComposer := false
                if Mode = "together" || (Mode = "custom" && job.msgs.Length = 0)
                    FinishOnePDF()
                else
                    BeginWait("upload_wait", UploadWait)
                WriteLog("已发送PDF：" job.path)
            } else {
                ; 当前对话已有资料时可不再次上传PDF、不发介绍语。
                BeginWait("upload_wait", 1)
                WriteLog("纯文字任务准备开始")
            }
        } else if (Stage = "upload_ready") {
            ; 上一次PDF已经成功添加，但话语没有通过焦点验证时，可安全恢复。
            SetStatus("PDF已附加，正在重试发送附件消息：" job.name)
            if Mode = "together"
                SendChatText(job.msgs[1], true)
            else
                SendChatText(GetUploadIntro(job), true)
            InFreshComposer := false
            if Mode = "together" || (Mode = "custom" && job.msgs.Length = 0)
                FinishOnePDF()
            else
                BeginWait("upload_wait", UploadWait)
            WriteLog("重试后按Enter发送PDF消息：" job.path)
        } else if (Stage = "question") {
            if Mode = "questions" {
                q := job.qs[QuestionIndex]
                msg := "这份PDF第" ToChinese(q) "题没懂"
            } else if Mode = "single"
                msg := SendMsg1
            else
                msg := job.msgs[QuestionIndex]
            SetStatus("正在发送：" job.name " → " msg)
            SendChatText(msg)
            InFreshComposer := false
            WriteLog("已发送提问：" job.name "：" msg)
            if (QuestionIndex < job.qs.Length) {
                QuestionIndex += 1
                BeginWait("question_wait", QWait*60)
            } else if (JobIndex < Jobs.Length) {
                BeginWait("pdf_wait", PDFWait*60)
            } else {
                Stage := "done"
                WaitUntil := ""
                SaveProgress()
                Running := false
            }
        }
        ShowProgress()
    } catch as e {
        Running := false
        DiagLog("JOB_FAIL", "error=" e.Message " extra=" e.What " line=" e.Line)
        WriteLog("失败：" e.Message)
        SetStatus("⚠ 已暂停：" e.Message "`n请检查Gemini是否正常、PDF是否上传成功、消息是否已发送。排查后按F8恢复；必要时重置进度。")
    } finally {
        Busy := false
    }
}

WriteLog(info) {
    global LogPath
    FileAppend(FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " " info "`r`n", LogPath, "UTF-8")
}
